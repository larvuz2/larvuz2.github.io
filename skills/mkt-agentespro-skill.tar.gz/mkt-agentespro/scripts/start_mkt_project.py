#!/usr/bin/env python3
from __future__ import annotations
import argparse
from datetime import datetime, timezone
from pathlib import Path
TASKS=[('MKT','Clarify objective, audience, offer, channels, approval gates, and success metrics.'),('Brand','Define core message, objections, proof needs, and safe claims.'),('SEO','Create keyword cluster or page brief tied to buyer intent.'),('Content','Draft core content assets and repurposing variants.'),('Social','Adapt assets by channel, strengthen hooks, and define cadence.'),('Growth','Define funnel path, CTA, lead magnet/experiment, and KPI.'),('Analytics','Define tracking, UTM plan, dashboard/reporting readout.'),('Ops','Create calendar, asset checklist, approval status, and publishing checklist.')]
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('objective',nargs='+'); ap.add_argument('--out',default='.hermes/mkt-project-brief.md'); args=ap.parse_args(); objective=' '.join(args.objective).strip(); out=Path(args.out).expanduser().resolve(); out.parent.mkdir(parents=True,exist_ok=True)
 lines=['# MKT-agentespro Project Brief','',f'Created: {datetime.now(timezone.utc).isoformat()}',f'Objective: {objective}','','## Default operating loop','','Objective → Audience → Offer/message → Channel plan → Asset production → Approval → Publish/ship → Measure → Iterate','','## Task board','']
 for i,(role,task) in enumerate(TASKS,1):
  status='In Progress' if i==1 else 'Blocked until MKT scope is clear'; lines += [f'### {i}. {role}-agentespro',f'- Status: {status}',f'- Task: {task}','- Evidence/outputs:','- Approval needed:','']
 out.write_text('\n'.join(lines),encoding='utf-8'); print(f'created: {out}'); return 0
if __name__=='__main__': raise SystemExit(main())
