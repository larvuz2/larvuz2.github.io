#!/usr/bin/env python3
from __future__ import annotations
import argparse, os, shutil, subprocess, sys, time
from pathlib import Path
SKILL_NAME="mkt-agentespro"; SKILL_CATEGORY="marketing"
TEAM_PROFILES={
"mkt-agentespro":"Marketing-team orchestrator for agentesPRO. Turns objectives into brand/content/SEO/social/growth/analytics/ops tasks with approval gates.",
"cmo-agentespro":"Executive marketing lead alias for MKT-agentespro. Owns brand, demand generation, SEO, social, content, growth, analytics, and responsible approvals.",
"brand-agentespro":"Positioning and voice specialist. Owns brand clarity, claims, objections, and campaign angle.",
"content-agentespro":"Content producer. Drafts posts, scripts, articles, newsletters, case studies, and repurposing packs.",
"seo-agentespro":"SEO strategist. Creates keyword clusters, page briefs, metadata, FAQ, and internal linking plans.",
"social-agentespro":"Social growth specialist. Adapts content per channel, improves hooks, cadence, replies, and distribution.",
"growth-agentespro":"Growth/funnel specialist. Designs lead magnets, experiments, conversion paths, and approval-based outreach support.",
"analytics-agentespro":"Marketing analytics specialist. Reads performance, UTMs, buyer signals, tracking gaps, and next tests.",
"ops-agentespro":"Marketing operations specialist. Manages calendar, asset library, approval gates, publishing checklist, and archives."}
ROLE_BODIES={name:f"# {name}\n\nLoad skill: mkt-agentespro.\n\nRole: {desc}\n\nNever send external emails/DMs, publish public content, spend ad budget, invent metrics/testimonials, or use client names/logos without explicit approval.\n" for name,desc in TEAM_PROFILES.items()}

def eprint(m): print(m,file=sys.stderr)
def run(cmd,dry_run=False,env=None):
 print('$',' '.join(cmd));
 if dry_run: return 0
 try: return subprocess.call(cmd,env=env)
 except FileNotFoundError: eprint(f"missing command: {cmd[0]}"); return 127
def profile_root(home,target): return home if target=='default' else home/'profiles'/target
def skill_dest(root): return root/'skills'/SKILL_CATEGORY/SKILL_NAME
def validate_source(src):
 if not src.exists(): raise SystemExit(f"source does not exist: {src}")
 if not (src/'SKILL.md').is_file(): raise SystemExit(f"source is not a Hermes skill directory; missing SKILL.md: {src}")
def install_skill(src,dest,force=False,dry_run=False):
 src=src.resolve(); dest=dest.expanduser().resolve(); validate_source(src)
 if src==dest: print(f"already installed: {dest}"); return
 print(f"source: {src}"); print(f"destination: {dest}")
 if dry_run: print('dry-run: no files copied'); return
 dest.parent.mkdir(parents=True,exist_ok=True); tmp=dest.with_name(f".{dest.name}.tmp-{int(time.time())}"); backup=dest.with_name(f"{dest.name}.backup-{int(time.time())}")
 shutil.copytree(src,tmp,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.DS_Store'))
 if dest.exists(): shutil.rmtree(dest) if force else dest.rename(backup)
 tmp.rename(dest); print(f"installed skill: {dest}")
def append_or_replace_role(profile_dir,name,dry_run=False):
 soul=profile_dir/'SOUL.md'; body=ROLE_BODIES.get(name,f"# {name}\n\nLoad skill: {SKILL_NAME}\n")
 start="\n<!-- MKT-AGENTESPRO-ROLE-START -->\n"; end="\n<!-- MKT-AGENTESPRO-ROLE-END -->\n"; block=f"{start}{body.rstrip()}\n{end}"
 if dry_run: print(f"dry-run: would update {soul}"); return
 profile_dir.mkdir(parents=True,exist_ok=True); existing=soul.read_text(encoding='utf-8') if soul.exists() else ''
 new=(existing.split(start,1)[0].rstrip()+block+existing.split(end,1)[1]) if start in existing and end in existing else existing.rstrip()+"\n"+block+"\n"
 soul.write_text(new,encoding='utf-8'); print(f"updated profile role: {soul}")
def create_or_update_team_profiles(home,src,clone_from='default',force=False,dry_run=False):
 hermes=shutil.which('hermes')
 if not hermes: eprint('Hermes CLI not found; cannot create profiles.'); return 127
 failures=0; env=dict(os.environ); env['HERMES_HOME']=str(home)
 for name,desc in TEAM_PROFILES.items():
  pdir=home/'profiles'/name
  if not pdir.exists():
   code=run([hermes,'profile','create',name,'--clone','--clone-from',clone_from,'--description',desc,'--no-alias'],dry_run=dry_run,env=env)
   if code!=0: eprint(f"failed to create profile {name} (exit {code})"); failures+=1; continue
  else:
   print(f"profile exists: {pdir}"); run([hermes,'profile','describe',name,'--text',desc],dry_run=dry_run,env=env)
  append_or_replace_role(pdir,name,dry_run=dry_run); install_skill(src,skill_dest(pdir),force=force,dry_run=dry_run)
 return 1 if failures else 0
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--hermes-home',default=os.environ.get('HERMES_HOME','~/.hermes')); ap.add_argument('--target-profile',default='default'); ap.add_argument('--install-root',default=None); ap.add_argument('--create-team-profiles','--create-profiles',action='store_true'); ap.add_argument('--clone-from',default='default'); ap.add_argument('--source',default=None); ap.add_argument('--force',action='store_true'); ap.add_argument('--dry-run',action='store_true'); args=ap.parse_args()
 home=Path(args.hermes_home).expanduser().resolve(); src=Path(args.source).expanduser().resolve() if args.source else Path(__file__).resolve().parents[1]; validate_source(src)
 target=Path(args.install_root).expanduser().resolve() if args.install_root else profile_root(home,args.target_profile); install_skill(src,skill_dest(target),force=args.force,dry_run=args.dry_run)
 return create_or_update_team_profiles(home,src,clone_from=args.clone_from,force=args.force,dry_run=args.dry_run) if args.create_team_profiles else 0
if __name__=='__main__': raise SystemExit(main())
