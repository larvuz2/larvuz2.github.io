# Weekly Content Calendar

Week of:
Goal:
Primary offer:

## Monday
- Channel:
- Asset:
- Pillar:
- Status:

## Tuesday
- Channel:
- Asset:
- Pillar:
- Status:

## Wednesday
- Channel:
- Asset:
- Pillar:
- Status:

## Thursday
- Channel:
- Asset:
- Pillar:
- Status:

## Friday
- Channel:
- Asset:
- Pillar:
- Status:

## Measurement
- KPI:
- UTM campaign:
- Review date:
