# Campaign Brief

Campaign name:
Goal:
Audience:
Offer:
Core message:
Channels:
Assets:
CTA:
Timeline:
Approval gates:
KPIs:
Risks:
