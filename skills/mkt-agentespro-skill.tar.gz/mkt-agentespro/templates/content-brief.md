# Content Brief

Objective:
Audience:
Channel:
Content pillar:
Core message:
Business pain:
Proof/example:
CTA:
Approval needed:
Claim risks:
Assets needed:
