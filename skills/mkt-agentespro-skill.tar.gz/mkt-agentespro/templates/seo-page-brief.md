# SEO Page Brief

Page title:
Target buyer:
Search intent:
Primary keyword:
Secondary keywords:
H1:
Meta title:
Meta description:
Page promise:
Sections:
FAQ:
Internal links:
CTA:
Proof needed:
Claim risks:
