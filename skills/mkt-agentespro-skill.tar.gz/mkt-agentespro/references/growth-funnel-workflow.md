# Growth Funnel Workflow

## Starter funnel

```txt
LinkedIn / SEO / demo video
→ clear agentesPRO landing page
→ concrete wedge offer
→ free 30-minute consultation
→ scoped diagnostic
→ Proposal + Quote Factory / Mission Control install
→ monthly optimization retainer
```

## Strong lead magnets

- “Chatbot vs Agent: Business Workflow Checklist”
- “Proposal + Quote Factory Audit”
- “AI Agent Readiness Map for Agencies”
- “5 Workflows Your Company Can Delegate to Agents This Month”

## Experiment design

Each experiment needs:

- hypothesis
- audience
- asset
- channel
- CTA
- success metric
- runtime
- stop/continue rule

## Conversion metrics

- profile visits → site visits
- site visits → consultation clicks
- consultation clicks → booked calls
- calls → diagnostics
- diagnostics → paid install
- install → retainer

## Rule

Growth should amplify trust. No spam scraping, fake urgency, or automated outreach without approval.
