# MKT-agentespro Team Architecture

## Core idea

One umbrella skill: `mkt-agentespro`. The specialist profiles are roles under the marketing system, not separate top-level skills.

## Default team

- **MKT-agentespro** — orchestrator / marketing lead. Owns objective, audience, channel plan, task breakdown, approvals, measurement.
- **Brand-agentespro** — positioning, voice, offer narrative, objections, claim discipline.
- **Content-agentespro** — content assets: posts, articles, scripts, carousels, case studies, newsletters.
- **SEO-agentespro** — keyword clusters, page briefs, metadata, internal linking, search intent.
- **Social-agentespro** — platform adaptation, hooks, cadence, replies, distribution.
- **Growth-agentespro** — funnel experiments, lead magnets, outreach support, conversion paths.
- **Analytics-agentespro** — KPIs, UTMs, reporting, readouts, next-test recommendations.
- **Ops-agentespro** — calendar, asset library, approval gates, publishing checklist, archival.

## Operating sequence

```txt
MKT clarifies objective
→ Brand frames message
→ SEO/Growth choose demand path
→ Content creates assets
→ Social adapts/distributes drafts
→ Ops checks approvals/assets
→ Analytics measures and recommends next iteration
```

## Starter Kanban states

```txt
Backlog → Ready → In Progress → Brand Review → Approval Needed → Scheduled/Published → Measured → Done
Blocked
```

## Human approval points

- public publishing
- external emails/DMs
- use of client names/logos/testimonials
- paid ad spend
- claims about ROI, security, compliance, or client results
