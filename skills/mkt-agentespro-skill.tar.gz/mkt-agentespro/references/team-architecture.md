# MKT-agentespro Team Architecture

## Core idea

One umbrella skill: `mkt-agentespro`. The specialist profiles are roles under the marketing system, not separate top-level skills.

## Reporting fabric

```txt
Gus
↓
Larvuz / Chief-of-Staff-agentesPRO
↓
CMO-agentespro / MKT-agentespro
├─ Brand-agentespro
├─ Content-agentespro
├─ SEO-agentespro
├─ Social-agentespro
├─ Growth-agentespro
├─ Analytics-agentespro
└─ Ops-agentespro
```

- CMO/MKT owns marketing direction, task decomposition, brand safety, approvals, and measurement.
- Brand, Content, SEO, Social, Growth, Analytics, and Ops report to CMO/MKT-agentespro.
- Specialist agents execute CMO/MKT-assigned work or CMO/MKT-created Kanban cards.
- Specialist agents may report blockers and recommendations, but do not own final publishing, external sending, paid spend, or company-wide direction.
- Marketing specialists do not route software, repo, database, QA, deployment, or DevOps work; they hand it back to Larvuz/Chief-of-Staff or CTO.
- Ops-agentespro is marketing workflow/approval/asset ops. DevOps-agentespro is technical infrastructure and reports to CTO.

## Default team

- **MKT-agentespro / CMO-agentespro** — orchestrator / executive marketing lead. Owns objective, audience, channel plan, task breakdown, approvals, measurement.
- **Brand-agentespro** — positioning, voice, offer narrative, objections, claim discipline.
- **Content-agentespro** — content assets: posts, articles, scripts, carousels, case studies, newsletters.
- **SEO-agentespro** — keyword clusters, page briefs, metadata, internal linking, search intent.
- **Social-agentespro** — platform adaptation, hooks, cadence, replies, distribution.
- **Growth-agentespro** — funnel experiments, lead magnets, outreach support, conversion paths.
- **Analytics-agentespro** — KPIs, UTMs, reporting, readouts, next-test recommendations.
- **Ops-agentespro** — calendar, asset library, approval gates, publishing checklist, archival.

## Operating sequence

```txt
MKT clarifies objective
→ Brand frames message
→ SEO/Growth choose demand path
→ Content creates assets
→ Social adapts/distributes drafts
→ Ops checks approvals/assets
→ Analytics measures and recommends next iteration
```

## Starter Kanban states

```txt
Backlog → Ready → In Progress → Brand Review → Approval Needed → Scheduled/Published → Measured → Done
Blocked
```

## Human approval points

- public publishing
- external emails/DMs
- use of client names/logos/testimonials
- paid ad spend
- claims about ROI, security, compliance, or client results
