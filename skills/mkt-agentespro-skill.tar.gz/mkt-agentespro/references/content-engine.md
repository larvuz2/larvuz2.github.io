# Content Engine

## Default weekly rhythm

- 2 founder POV posts
- 2 practical education posts
- 1 proof/demo/case-study style post
- 1 short-form video script
- 1 SEO/public-memory article draft or page brief

## Pillars

1. **Agent clarity** — what agents do beyond chat.
2. **Business function wedges** — proposal factory, follow-up desk, reporting, knowledge base.
3. **Mission Control** — owner visibility and approval queue.
4. **Before/after workflows** — messy current state vs cleaner agent-supported flow.
5. **Build-in-public** — safe behind-the-scenes, no private client data.
6. **Buyer objections** — cost, control, security, readiness, team adoption.
7. **Creative technical edge** — cinematic/product-quality demos that make agents feel real.

## Asset ladder

One idea becomes:

- LinkedIn text post
- carousel outline
- short video script
- SEO article section
- outreach proof snippet
- website FAQ / objection block

## Quality checklist

- One clear audience.
- One business pain.
- One useful distinction or example.
- No fake metrics.
- No generic AI hype.
- Concrete next step.
