# Social Growth Workflow

## Primary channel

LinkedIn first. It matches the buyer and allows founder-led trust building.

## Secondary channels

- Short-form video: simple demos and explanations.
- X/Twitter: founder/build POV when relevant.
- YouTube Shorts/Reels/TikTok: visual “before/after workflow” demos.

## Post types

1. **Contrast post** — chatbot vs agent, manual chaos vs operating layer.
2. **Practical example** — “An agent that turns a messy WhatsApp/client brief into a scoped quote draft.”
3. **Buyer objection** — why this is not replacing the team; it removes operational drag.
4. **Mini case study** — only with real approved data.
5. **Founder POV** — Gus's direct perspective on agents, production, and AI-native companies.
6. **Demo script** — one tiny workflow visualized in 20–45 seconds.

## Distribution checklist

- Strong first line.
- Plain business example by line 3.
- No AI hype words.
- CTA asks for conversation, not vague engagement.
- If repurposed, adapt to the channel instead of copy-pasting.

## Reply/comment behavior

Be helpful. Do not hard sell in comments. Invite DM only when there is clear fit.
