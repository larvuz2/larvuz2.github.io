# SEO Workflow

## Purpose

Build search visibility for companies already looking for help with AI agents, proposal automation, sales follow-up, reporting dashboards, knowledge bases, and AI operations.

## Keyword cluster starter map

### High-intent service pages

- AI agents for businesses
- AI agents for marketing agencies
- proposal automation for agencies
- quote automation system
- AI sales follow up assistant
- AI reporting dashboard for clients
- AI operations consultant
- business process automation with AI

### Educational clusters

- chatbot vs AI agent
- what can AI agents do for a business
- examples of AI agents in companies
- how to use AI agents for sales follow up
- how to automate proposals with AI
- AI agents vs automation tools

### Spanish/Mexico clusters

- agentes de IA para empresas
- automatización de propuestas con IA
- agentes de IA para agencias de marketing
- chatbot vs agente de IA
- automatización de reportes con IA
- consultoría de agentes de IA México

## Page brief requirements

Every SEO page brief needs:

- target buyer
- search intent
- primary keyword
- secondary keywords
- title/H1/meta description
- page promise
- sections
- FAQ
- internal links
- CTA
- proof needed
- claim risk notes

## SEO quality rule

Do not write keyword mush. Every page must sell a concrete business outcome.
