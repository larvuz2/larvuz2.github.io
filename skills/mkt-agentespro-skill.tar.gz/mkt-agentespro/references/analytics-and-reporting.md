# Analytics + Reporting

## Weekly readout

Keep reports decision-oriented:

1. What grew?
2. What converted?
3. What underperformed?
4. What did we learn?
5. What should we test next?

## Core KPIs

### Visibility
- impressions
- profile visits
- search clicks
- page views
- video views / retention

### Engagement quality
- saves
- comments from target buyers
- replies/DMs
- consultation clicks

### Pipeline
- booked calls
- diagnostics started
- proposals sent
- closed installs
- retainers

## UTM standard

Use lowercase source/medium/campaign.

Example:

```txt
utm_source=linkedin
utm_medium=social
utm_campaign=chatbot-vs-agent
utm_content=founder-post-01
```

## Reporting rule

Do not celebrate vanity metrics if there is no buyer signal. Recommend the next test.
