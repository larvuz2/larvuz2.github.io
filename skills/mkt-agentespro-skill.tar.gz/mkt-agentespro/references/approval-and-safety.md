# Approval + Safety Rules

## Requires explicit approval

- Sending emails or DMs externally.
- Publishing public posts/pages if no auto-publish rule exists.
- Paid ad spend.
- Using client names/logos/testimonials/results.
- Public claims about ROI, compliance, security, legal, or financial results.
- Scraping or importing lead lists.

## Never do

- Invent metrics or case studies.
- Expose private inbox/client/project/financial details.
- Publish credentials or private URLs.
- Use copyrighted media without permission.
- Promise guaranteed outcomes.

## Safer claim language

Use:

- “designed to help”
- “can reduce manual follow-up”
- “built to make proposals faster and clearer”
- “keeps humans in the approval loop”

Avoid:

- “guaranteed to double revenue”
- “fully autonomous replacement”
- “compliance-ready” unless validated
- “secure by default” without specifics
