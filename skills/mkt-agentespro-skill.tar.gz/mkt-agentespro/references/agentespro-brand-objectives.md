# agentesPRO Brand + Objectives

## Brand promise

agentesPRO installs practical AI agent systems inside companies so work moves without the owner chasing every task.

## Sharpest message

```txt
Chatbots contestan. Agentes operan.
```

## What agentesPRO sells first

Prioritize business functions companies already understand and already spend money on:

1. **Proposal + Quote Factory** — faster quotes, cleaner scopes, fewer lost deals.
2. **Sales Follow-up Desk** — reminders, context, draft messages, pipeline visibility.
3. **Reporting Dashboard** — weekly client/owner reports from messy inputs.
4. **SOP + Knowledge System** — company brain that answers and routes work.
5. **Mission Control** — owner dashboard + specialist agents + approval queue.

## Buyer language

Use:

- “system of agents that moves work”
- “AI operations layer”
- “proposal/quote workflow”
- “owner visibility”
- “fewer forgotten follow-ups”
- “client-ready reports”
- “installed around your existing workflow”

Avoid:

- “AI transformation”
- “revolutionary”
- “autonomous company”
- “replace your team”
- “guaranteed ROI”
- vague “automate everything”

## Tone

Direct. Useful. Slightly cinematic. Not corporate.

Spanish line style:

- “No necesitas otro chatbot. Necesitas agentes que operen.”
- “Tu empresa no necesita más respuestas. Necesita seguimiento, propuestas, reportes y decisiones claras.”
- “Los chatbots contestan. Los agentes avanzan trabajo.”

English line style:

- “Not another chatbot. A system of agents that moves work.”
- “AI agents for proposals, follow-ups, reports, and owner visibility.”
- “Built around your current workflow, not a forced migration.”

## Main objective

Convert attention into qualified conversations for AI operations installations and retainers.

Marketing should create:

- trust
- clarity
- practical demand
- proof
- repeatable content assets
- lead paths
