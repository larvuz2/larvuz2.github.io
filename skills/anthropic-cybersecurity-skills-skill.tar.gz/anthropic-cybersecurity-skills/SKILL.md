---
name: anthropic-cybersecurity-skills
description: "Use for authorized cybersecurity work: defensive security, vulnerability management, incident response, threat detection, cloud/app/API/mobile/security testing, DFIR, AI security, and security governance. This is a patched Hermes wrapper around mukul975/Anthropic-Cybersecurity-Skills with explicit authorized-use boundaries."
version: 1.2.0-hermes-phase1
author: mahipal + Larvuz patch
license: Apache-2.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [cybersecurity, defensive-security, vulnerability-management, incident-response, threat-detection, authorized-testing]
    source_repo: https://github.com/mukul975/Anthropic-Cybersecurity-Skills
    source_commit: 04450304b12645cb2b974ab96d28c0664758a88d
    phase1_patch: authorized-use-boundary-in-all-imported-skills
---

# Anthropic Cybersecurity Skills — Hermes Wrapper

This installs the `mukul975/Anthropic-Cybersecurity-Skills` corpus as a Hermes-compatible wrapper skill instead of registering 754 individual skills into the global skill prompt.

## Phase-1 Safety Patch

Every imported `references/cybersecurity-skills/*/SKILL.md` file has an added **Authorized-use Boundary** section.

Default behavior:
- Use only for systems Gus owns or has explicit written authorization to assess.
- Keep testing non-destructive and evidence-based.
- Use synthetic accounts, synthetic tokens, lab targets, screenshots, and logs instead of real data theft or harm.
- If a request asks for stealth, persistence, credential theft, real exfiltration, malware deployment, evasion, destructive impact, or unauthorized targeting, refuse that part and redirect to defensive alternatives: scoping, detection, hardening, logging, recovery, or safe lab simulation.

## How to Use

1. Identify the security domain or vulnerability class.
2. Search the linked corpus under `references/cybersecurity-skills/` for the closest skill.
3. Load/read that skill file directly when needed.
4. Apply the authorized-use boundary before following any workflow.

Useful corpus files:
- `references/README.md` — upstream overview.
- `references/index.json` — upstream skill index.
- `references/ATTACK_COVERAGE.md` — MITRE ATT&CK coverage.
- `references/cybersecurity-skills/<skill-name>/SKILL.md` — individual skill playbooks.
- `references/hermes-local-security-hardening.md` — low-risk Hermes security hardening quick pass for Gus: redaction flags, destructive confirmations, file permissions, exposed API ports, backup/verify pattern.

## Fast Search Examples

```bash
python ~/.hermes/skills/cybersecurity/anthropic-cybersecurity-skills/scripts/search_cyber_skills.py jwt
python ~/.hermes/skills/cybersecurity/anthropic-cybersecurity-skills/scripts/search_cyber_skills.py "incident response" --limit 20
```

```bash
find ~/.hermes/skills/cybersecurity/anthropic-cybersecurity-skills/references/cybersecurity-skills -maxdepth 2 -name SKILL.md | wc -l
```
