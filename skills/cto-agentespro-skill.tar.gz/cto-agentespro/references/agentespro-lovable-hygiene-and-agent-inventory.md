# agentesPRO Lovable hygiene + VPS agent inventory pattern

Use this when continuing the agentesPRO Lovable/Supabase dashboard integration after the connector/RLS/privacy hardening work.

## Hygiene Round 2 verification pattern

Before accepting a Lovable implementation that touches tenant security, raw payloads, cron cleanup, or connector endpoints, require real proof for these gates:

1. REDACTION_SALT is installed and endpoint output proves HMAC redaction works.
2. Migrations applied cleanly and schema changed as expected.
3. Cross-tenant seed exists: Company A/B, User A/B, one agent/activity/health/raw/token per company.
4. User A can read only Company A safe rows; User B can read only Company B safe rows.
5. Authenticated users cannot read raw sibling tables or connect_tokens.
6. Super-admin/service-role can read/write admin data where intended.
7. Connector health endpoint derives tenant from bearer secret and ignores spoofed body tenant fields.
8. Activity/health redaction is tested with long bodies, emails, sensitive keys, and summary-only PII fallback.
9. cleanup_expired_rows() is actually executed on old seeded rows; reports remain untouched.
10. Rate limit test proves 61st-ish request returns 429.

Do not accept "policy visible" as proof for cleanup. Cleanup deletes data; ask for before/after counts.

## Safe cleanup rule

Reports and durable user-facing outputs are never auto-deleted. Operational logs can expire. Cleanup must be an explicit allowlist: one DELETE per approved table, no broad loops or pattern matching.

## VPS agent inventory current pattern

The connector source of truth is `/root/agentespro-connector/sync_workforce.py`.

It sends protocol v2 payloads:

```json
{
  "connector_protocol_version": 2,
  "connector_protocol_name": "ai_workforce_observability_v1",
  "profiles": []
}
```

Current dashboard payload class:

- safe org chart / workforce metadata
- profile_name, source_name, source_role, source_description, archetype
- tools_summary
- installed_status, runtime_status, last_seen_at, last_activity
- parent_profile_name / is_area_leader
- email access metadata only where relevant
- recurring_jobs assigned by name heuristics
- task counters, currently often placeholder zeroes

Never sync secrets, env values, email bodies, raw logs, memory contents, session transcripts, profile DBs, auth locks, credentials, or full skill/persona files.

## Known pending work after safe metadata sync

When Gus asks what is left, the next practical items are usually:

1. Connector Status dashboard widget using health backend: healthy/degraded/down, last seen, recent warning/error.
2. Better recurring job ownership mapping or an unassigned jobs section.
3. Real agent metrics instead of zero counters.
4. Real runtime status and last useful activity, not just sync timestamp.
5. Role gating and invites before client teams self-manage access.
6. Decide whether profiles such as `signal-cruncher` should be dashboard-visible.

## Handoff style

For Gus, keep this operational and concise:

- what data exists on VPS
- what the dashboard currently receives
- what is intentionally not sent
- what is pending / recommended next
- whether it is a blocker or just product polish
