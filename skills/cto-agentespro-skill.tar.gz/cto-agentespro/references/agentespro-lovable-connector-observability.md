# agentesPRO Lovable dashboard connector observability

Use this reference when Gus asks to continue the agentesPRO user-facing dashboard/Lovable integration, especially Agents / AI Workforce Observability.

## Operating pattern

1. Treat the VPS as the source of truth for Hermes workforce metadata.
2. Treat Lovable/Supabase as the dashboard/state store.
3. Do not ask Lovable/browser code to read the VPS filesystem directly.
4. Build or update a VPS-side connector that pushes safe metadata to `/api/public/connector/*`.
5. Verify with real endpoint output before telling Gus the dashboard should update.
6. If the UI does not reflect data, split the problem clearly:
   - connector payload generated locally
   - endpoint reachable / auth accepted
   - sync response confirms writes
   - database child rows exist
   - `listAgentWorkforce` returns hierarchy
   - deployed `/agents` route renders the live implementation, not a placeholder/stale build

## Current connector shape

The dashboard expects protocol v2 payloads:

```json
{
  "connector_protocol_version": 2,
  "connector_protocol_name": "ai_workforce_observability_v1",
  "profiles": []
}
```

Each top-level profile should include:

- `profile_name`
- `status`
- `agent` with `source_name`, `source_role`, `source_description`, `archetype`, `tools_summary`, `email_access`, `installed_status`, `runtime_status`, `last_seen_at`, metrics
- `team_members[]`
- `recurring_jobs[]`

## Expected hierarchy

Area leaders:

- `gus-hermie` / Larvuz
- `cto-agentespro`
- `cmo-agentespro`
- `ops-agentespro`
- `growth-agentespro`
- `ai-production-director`

CTO team:

- `builder-agentespro`
- `reviewer-agentespro`
- `qa-agentespro`
- `devops-agentespro`

CMO team:

- `mkt-agentespro`
- `growth-agentespro`
- `seo-agentespro`
- `social-agentespro`
- `content-agentespro`
- `brand-agentespro`
- `analytics-agentespro`

AI Production team:

- `movie-maker`
- `christmas-witch`

## Email visibility rule

For the authenticated internal agentesPRO dashboard, show full email addresses in cards/drawers because operators need to know exactly which inboxes are connected.

Do not expose email bodies, credentials, raw logs, or private message content. Sync metadata only:

```json
{
  "provider": "google_workspace",
  "email": "gus@metazooie.com",
  "access_type": "read_summary",
  "status": "connected",
  "last_checked_at": "ISO_DATE",
  "privacy_level": "metadata_only"
}
```

## Verification checklist

When asked to finish/fix this integration:

1. Generate the connector payload and count leaders/team/jobs/email locally.
2. POST heartbeat and sync with the Bearer instance secret.
3. Confirm endpoint output, ideally including counts:
   - `leaders_upserted`
   - `team_members_upserted`
   - `recurring_jobs_upserted`
   - `unassigned_jobs`
4. Visit the deployed `/agents` route.
5. If it still shows a placeholder/WIP page, tell Lovable the backend accepted sync but the deployed frontend route is stale or not wired to `listAgentWorkforce`.
6. Give Gus a copy-paste Lovable message with exact observed outputs and next checks.

## Common diagnostic split

- `HTTP 403 / error code 1010`: hosting/bot-protection blocked machine-to-machine connector POSTs. Ask Lovable to make `/api/public/connector/*` accept server clients with `Authorization: Bearer INSTANCE_SECRET` and no browser challenge.
- `200 {"ok":true}` but no UI hierarchy: endpoint accepts payload, but either team member upsert is broken, query does not return children, or deployed UI route is stale.
- `/agents` shows “WORK IN PROGRESS / Real agents integration coming next”: the live route is still placeholder/stale even if backend sync works.

## Handoff style for Gus

Gus expects action first, then a Lovable-ready message. Report:

- what was done on VPS
- real command/API result
- what still blocks the visible dashboard
- exact message to send Lovable

Keep it concise and operational.