# agentesPRO Safe Mirror Hygiene Review Notes

Use when reviewing Lovable/Supabase hygiene plans for the agentesPRO client dashboard connector.

## Core architecture

- Supabase is the client-safe operating mirror.
- Hermes/VPS remains the operational brain/source.
- Dashboard reads tenant-safe mirror state, not raw Hermes files/logs.
- Reports and user-visible outputs are durable by default; operational logs can expire.

## RLS and raw payload pitfall

RLS is row-level, not field-level. If a company member can `SELECT` a row, do not assume `detail_raw` / `payload_raw` is protected just because the UI does not render it.

Safer patterns:

1. Split raw payloads into admin-only tables:
   - `activity_event_raw`
   - `connector_health_event_raw`
2. Or expose member-readable safe views only:
   - `activity_events_safe`
   - `connector_health_events_safe`
3. Or use column privileges very carefully, then verify with real non-admin roles.

Never rely on frontend hiding as a security control.

## `connect_tokens` policy

Do not grant normal company-member `SELECT` on `connect_tokens` if the table contains token values, hashes, invite codes, or other sensitive handshake data.

Preferred:

- `service_role` only
- super-admin only
- later: owner/admin via explicit scoped policy if needed

If the UI needs token state, expose a safe status view with no token material:

- id
- company_id
- created_at
- expires_at
- used_at
- status
- label

## Connector endpoint scoping

For machine-to-machine connector endpoints authenticated by an instance secret:

1. Authenticate the bearer instance secret.
2. Look up the `hermes_instance` row.
3. Derive `company_id` and `hermes_instance_id` server-side.
4. Ignore/reject client-supplied `company_id` or `hermes_instance_id` for insertion scope.

A compromised/misconfigured connector should not be able to write into another company by changing the request body.

## Service-role server functions

Service-role bypasses RLS. Every service-role server function must explicitly enforce tenant scope:

- derive or require `company_id`
- filter every query by that `company_id`
- never return cross-tenant data because “RLS will handle it”

Dev bypass paths are useful, but they should not become an excuse to skip company filtering.

## Connector health design

`detail_summary` should usually be optional with default `{}`. Heartbeats should stay tiny and not require fake detail objects.

Define connector status thresholds explicitly:

- `healthy`: `last_seen_at` fresh, no recent error
- `degraded`: recent warn/error but connector still fresh
- `down`: stale `last_seen_at` or repeated missed heartbeats
- precedence: down > degraded > healthy

Suggested starting thresholds:

- healthy: `last_seen_at` within 5 minutes and no error in last 15 minutes
- degraded: `last_seen_at` within 15 minutes with recent warn/error, or recent missed heartbeat followed by recovery
- down: `last_seen_at` older than 15 minutes, or 3 consecutive missed heartbeats

## Privacy/redaction review points

Redaction should happen before storage and again before display.

Prefer HMAC/salted hashes for email identity tokens, not plain hashes, because emails are guessable.

Expand summary stripping/redaction keys beyond obvious body fields:

- `body`, `message`, `content`, `text`, `html`
- `snippet`, `description`, `transcript`, `notes`
- `raw`, `payload`, `thread`, `conversation`
- `headers`, `authorization`, `cookie`, `set_cookie`
- `access_token`, `refresh_token`, `id_token`, `api_key`, `secret`, `password`
- `body_html`, `raw_mime`, `attachments`

Rule: summaries are safe display surfaces; raw detail belongs only in admin-only storage.

## Verification checklist

When reviewing/approving a hygiene migration, require real cross-tenant tests:

1. Create Company A + Company B.
2. Create User A member of Company A.
3. Create User B member of Company B.
4. Verify User A sees only Company A rows.
5. Verify User A cannot read Company B rows.
6. Verify members cannot access `detail_raw`, `payload_raw`, or `connect_tokens`.
7. Verify super-admin can read both companies.
8. Verify service-role connector writes still work.
9. Verify Connector A's token cannot write events for Company B.
10. Run cleanup and confirm only allowlisted operational log tables are affected.

## Approval stance

Approve safe-mirror hygiene plans only after these are handled:

- raw payloads are not exposed through member-readable rows
- `connect_tokens` is not member-readable if it contains sensitive material
- connector endpoints derive tenant scope from authenticated instance secrets
- service-role paths explicitly filter by company
- cross-tenant tests are real, not hypothetical
