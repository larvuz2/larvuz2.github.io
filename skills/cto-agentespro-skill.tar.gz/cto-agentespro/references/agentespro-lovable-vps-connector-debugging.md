# agentesPRO Lovable ↔ VPS connector debugging

Use when the agentesPRO dashboard/Lovable app does not show synced Hermes agents, team members, recurring jobs, email access, or status metrics.

## Durable lessons

### 1. Verify the deployed connector, not just Lovable's editor state
Lovable may report that code is complete while the public/custom-domain endpoint still serves an older build. Always test the live endpoint the VPS actually uses.

Check response shape after `/api/public/connector/sync`:

```json
{
  "ok": true,
  "connector_protocol_version": 2,
  "counts": { ... },
  "per_profile": [ ... ],
  "received_top_level_keys": [ ... ],
  "received_first_profile_keys": [ ... ]
}
```

If the response is only:

```json
{"ok": true, "synced": [...]}
```

then the deployed API is still old, even if the repo/editor has newer code.

### 2. Distinguish API success from data visibility
`200 {"ok":true}` only proves the request was accepted. It does **not** prove:

- `team_members[]` were parsed
- child `agents` rows were written
- `parent_agent_id` was set
- leader rows have `is_area_leader=true`
- the frontend is reading the same `company_id`
- the custom domain has the latest route build

Ask for or add debug counts:

```json
{
  "counts": {
    "leaders_received": 6,
    "leaders_upserted": 6,
    "team_members_received": 12,
    "team_members_upserted": 12,
    "recurring_jobs_received": 14,
    "recurring_jobs_upserted": 14
  },
  "per_profile": [
    {"profile_name": "cto-agentespro", "team_members_received": 4}
  ]
}
```

### 3. Check the active company boundary
If the UI says "No agents yet" after a successful sync, verify that the connector instance's `company_id` matches the active workspace/company selected by the user. The app can have demo/Acme/default company state while the connector writes to Larvuz or another tenant.

### 4. Use defensive payload compatibility during schema transitions
When Lovable is transitioning from flat cards to hierarchy, send both shapes:

Primary v2 nested shape:

```json
{
  "profile_name": "cto-agentespro",
  "agent": {"is_area_leader": true},
  "team_members": [
    {"profile_name": "builder-agentespro", "source_name": "Builder-agentesPRO"}
  ],
  "recurring_jobs": []
}
```

Compatibility fallback shape:

```json
{
  "profile_name": "builder-agentespro",
  "agent": {
    "is_area_leader": false,
    "parent_profile_name": "cto-agentespro"
  },
  "team_members": [],
  "recurring_jobs": []
}
```

This lets old deployed connector code use the existing `parent_profile_name → parent_agent_id` path even if nested `team_members[]` parsing/debug is stale.

### 5. Required dashboard visibility checks
For the Agents page to show hierarchy:

- leaders must have `is_area_leader=true`
- child rows must have `parent_agent_id=<leader agent id>`
- `listAgentWorkforce` must filter leaders by `is_area_leader` and group children by `parent_agent_id`
- RLS/company scope must allow the signed-in user to read the same company rows
- the deployed `/agents` route must be the live observability UI, not the old WIP placeholder

### 6. Machine-to-machine endpoint access
If POSTs return Cloudflare/Lovable 1010/403, the connector endpoint is blocked for server clients. Lovable should expose `/api/public/connector/*` for Bearer-token machine calls without browser cookies or interactive challenge, or move connector ingestion to Supabase Edge Functions/another API surface.

### 7. Normalize datetimes for Lovable/Zod
Hermes cron output may produce Python-style ISO timestamps with offsets:

```text
2026-06-05T15:03:23.660487+00:00
```

Some Lovable/Zod schemas using `z.string().datetime()` reject offsets unless configured. Before sending `last_run_at` / `next_run_at`, normalize to strict UTC `Z`:

```text
2026-06-05T15:03:23.660487Z
```

Treat missing/non-ISO timestamps as `null`, not as raw strings like `never` or partial dates. If the sync suddenly fails after recurring jobs are added, run it manually and read the first `invalid_body` path; one invalid recurring job can reject the whole payload before team members are written.

### 8. Do not nest leaders under leaders in a single-parent hierarchy
The agentesPRO dashboard currently models hierarchy with one `parent_agent_id` and one `is_area_leader` flag per `agents` row. In that model, do **not** send CTO/CMO/Ops/Growth/AI Production as `team_members[]` under Larvuz, because the team-member upsert path may set:

```text
parent_agent_id = Larvuz
is_area_leader = false
```

on those same rows, causing leader cards to disappear or move under Larvuz. Keep area leaders top-level. If the product needs “Larvuz supervises CTO/CMO/etc.”, ask Lovable for a separate relationship such as `reports_to_agent_id` instead of reusing `parent_agent_id`.

Use this safer payload split:

```text
Larvuz: team_members=[]
CTO: team_members=[Builder, Reviewer, QA, DevOps]
CMO: team_members=[MKT, SEO, Social, Content, Brand, Analytics]
Growth: top-level leader, not nested under CMO unless schema supports leader-with-parent
AI Production: team_members=[Movie-maker, Christmas-witch]
```

## Good message to Lovable when blocked

```text
The VPS connector is posting connector_protocol_version=2 and returns HTTP 200, but the deployed endpoint still returns the old synced-only envelope. Please confirm the public/custom-domain connector endpoint is running the latest build and return debug counts for leaders/team_members/recurring_jobs. Also verify the connector company_id matches the active company shown in the Agents page and that the six leader rows are is_area_leader=true.
```
