# agentesPRO Agent Tasks + Activity Emitter Pattern

Use this reference when working on the agentesPRO Lovable dashboard, VPS connector, or Hermes-side instrumentation for agent metrics, activity logs, task tables, and subtasks.

## Core product principle

The dashboard must answer:

> What did my agents do today?

Do not stop at uptime, last seen, or static agent cards. Clients need visible work history: task names, completed work counts, recent logs, and expandable subtasks.

## Data truth hierarchy

Until the structured `tasks` table is genuinely populated, use `activity_events` as the operational task history.

- `reports` = durable user-facing artifacts; count `reports_delivered` from the reports table.
- `activity_events` = operational work/log/task stream; use for Work completed, latest task, recent logs, and task table v1.
- raw sibling tables = admin-only debugging; never use for normal UI detail.

## Agent card UX

Keep cards executive-glance only:

- agent name
- role
- status
- last meaningful activity / fallback muted last seen
- latest completed task name
- 2–3 range-scoped KPIs: Work completed, Reports delivered, Errors / Needs review

Move everything else to the drawer/detail panel: active days, success rate, recurring jobs, total events, tools, email access, team roster, full logs.

## Latest completed task logic

Use latest meaningful completed work in the selected range:

```sql
status = 'success'
kind in ('agent.work.completed','task.completed','report.created','cron.job.completed')
source not in ('connector','system')
order by occurred_at desc
limit 1
```

Display name rule:

```text
task_name = payload_summary.task_title ?? summary
```

If none exists in the selected range, show `No completed task in this range.`

## Tasks section v1

Add a read-only Tasks section/table, sourced from `activity_events`:

Columns:

- time
- task name
- status
- agent
- task_type
- source
- related report link

Click/expand a row to show safe subtasks:

- subtask title
- agent that tackled it
- status
- optional short summary

Subtasks source:

```text
payload_summary.subtasks
```

Never query or expose `activity_event_raw`.

## Recommended server functions

Add `listAgentTasks`:

```ts
listAgentTasks({
  company_id,
  range,
  from?,
  to?,
  agent_id?,
  status?,
  source?,
  task_type?,
  cursor?,
  limit = 50
})
```

Return:

- id
- occurred_at
- agent_id
- agent_name
- task_name
- task_type
- status
- source
- summary
- related_report_id
- subtasks_count
- has_subtasks

Add `getAgentTaskDetail({ company_id, id })` returning only safe fields:

- task_name
- summary
- payload_summary
- subtasks[]

Always filter by `company_id` and `id`, even with admin/service-role clients.

## Activity emitter payload shape

Hermes-side emitters should send task-friendly fields through the safe activity endpoint:

```json
{
  "profile_name": "cmo-agentespro",
  "agent_profile_name": "cmo-agentespro",
  "kind": "agent.work.completed",
  "status": "success",
  "source": "agent",
  "task_type": "public_memory_post",
  "summary": "CMO completed a public-memory post task",
  "payload_summary": {
    "task_title": "Draft public-memory layer post for gusgarza.com",
    "project": "gusgarza.com",
    "output_type": "post",
    "subtasks": [
      { "title": "Define post angle", "agent_profile_name": "cmo-agentespro", "status": "success" },
      { "title": "Write public-memory draft", "agent_profile_name": "cmo-agentespro", "status": "success" },
      { "title": "Prepare git publish handoff", "agent_profile_name": "cmo-agentespro", "status": "success" }
    ],
    "subtasks_count": 3
  }
}
```

Compatibility note: if endpoint versions differ, send both `profile_name`/`agent_profile_name` and both `external_id`/`external_run_id`.

## Meaningful activity vs presence

Store both when available:

- `last_activity` / `last_seen` = latest event of any kind, including heartbeat/sync/info.
- `last_meaningful_activity_at` = latest real work event only.

UI should show meaningful activity as `Last activity`; fallback to raw last seen with a muted `Last seen` label.

Ignore connector/system heartbeat and pure sync events for meaningful work.

## Visual QA seed pattern

Temporary super-admin seed endpoints are acceptable for UI verification only if:

- super-admin gated
- scoped to one explicit `company_id`
- rows are tagged with `payload_summary.seed = true` and `seed_batch`
- clear/delete endpoint removes only tagged rows for that company
- no raw payloads are seeded
- endpoint is disabled/removed once real ingestion exists

## Public-memory dashboard test pitfall

If Gus asks for a dummy CMO/agent task that mentions writing a public-memory post and pushing to Git, do not actually publish or push unless he explicitly asks for a real website change and the publishing repo/config is verified. For dashboard visual QA, emit a simulated safe activity event tagged as test/seed data.

## Verification checklist

- Latest task appears on correct agent card.
- `/tasks` shows the task in the selected date range.
- Expanding row shows subtasks and agent names.
- Date filters change task rows/counts.
- Cross-tenant user cannot see other company tasks.
- Task detail never queries raw sibling tables.
- Reports delivered counts from reports table, not activity events.
