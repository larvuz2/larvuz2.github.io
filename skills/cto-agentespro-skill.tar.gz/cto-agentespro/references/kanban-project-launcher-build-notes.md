# Kanban Project Launcher Build Notes

Use these notes when evolving CTO-agentespro or building a similar plug-and-play Hermes software team skill.

## Durable pattern

A software-team skill should not stop at docs + profile prompts. Make it operational:

1. Install one umbrella skill.
2. Create/update specialist Hermes profiles.
3. Bootstrap repo context files (`AGENTS.md`, `.hermes/project-brief.md`).
4. Create a real Hermes Kanban board from the user's objective.
5. Seed a staged task graph:
   - CTO plan / scope first
   - Builder implementation blocked until scope is clear
   - Reviewer blocked until Builder output exists
   - QA blocked until implementation is testable
   - DevOps blocked until deploy/CI/DB work is relevant
6. Run `hermes kanban dispatch --dry-run` before real dispatch.
7. Keep human approval for merge, production deploy, destructive DB migration, and repo deletion.

## Launcher script behavior

A good `start_cto_project.py` should:

- call `hermes kanban init`
- create or reuse a board, then switch to it
- set board default workdir when a repo path is provided
- create idempotent cards with `--idempotency-key`
- assign specialist profiles explicitly
- attach the umbrella skill with `--skill cto-agentespro`
- default expensive/ambiguous worker cards to `blocked`
- print watch and dispatch commands at the end

## Installer pitfalls fixed

- `hermes profile describe` requires `--text` for non-interactive description updates.
- When creating profiles under a target Hermes home, pass `HERMES_HOME` into the subprocess environment; otherwise profile commands may affect the wrong home.
- Avoid deleting the source when installing from an already-installed skill path; detect same source/destination and skip or require `--force` safely.
- Package artifacts should be deterministic and rebuilt by script, not hand-copied.

## Why staged Kanban beats spawning everyone

Do not dispatch Builder/Reviewer/QA/DevOps all at once. Scope must harden first. The staged board gives the user an instant cockpit while preventing token waste and confused work.