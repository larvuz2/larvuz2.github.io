# agentesPRO Agent Metrics + Activity Logs

Use this reference when the agentesPRO/Lovable dashboard needs live operational metrics, activity feeds, or date-scoped agent performance.

## Core principle

The dashboard cannot count work that was never emitted into safe operational tables.

If agent cards show `0` for work completed, failed runs, success rate, or reports, first inspect whether `activity_events` and `reports` actually contain rows for the company/date range before assuming a UI bug.

## Date-scoped metrics

Agent metrics should be range-scoped, not static profile metadata.

Required ranges:

- `last_hour`
- `today`
- `week`
- `month`
- `all_time`
- custom `from`/`to` later

Default range can be `week` for overview dashboards or `today` for operations pages.

Logs should always be paginated, even for `all_time`.

## Status/source schema

Prefer explicit columns on `activity_events`:

- `status`: `success`, `warning`, `error`, `needs_review`, `running`, `info`, `unknown`
- `source`: `manual`, `cron`, `connector`, `email`, `dashboard`, `system`, `agent`, `api`, `unknown`
- `task_type`
- `external_run_id`
- `related_report_id`

Keep `kind` as the semantic event name, not the main filter mechanism.

Use fallback parsing for legacy rows:

```sql
status_for_metrics = coalesce(status, derive_status_from_kind(kind), 'unknown')
source_for_metrics = coalesce(source, derive_source_from_kind(kind), 'unknown')
```

Derive examples:

- `*.completed`, `*.success`, `report.created`, `sync.completed` -> `success`
- `*.failed`, `*.error`, `error.*` -> `error`
- `*.warning`, `warn.*` -> `warning`
- `review.needed`, `*.needs_review` -> `needs_review`
- `*.running`, `started`, `in_progress` -> `running`
- `heartbeat`, `sync`, `info` -> `info`

Source examples:

- `cron.*`, `schedule.*`, `recurring.*` -> `cron`
- `connector.*`, `sync.*`, `heartbeat.*` -> `connector`
- `email.*`, `inbox.*`, `gmail.*` -> `email`
- `dashboard.*`, `user.*` -> `dashboard` or `manual`
- `system.*`, `cleanup.*` -> `system`
- `agent.*`, `task.*`, `report.*` -> `agent`

## Tasks table vs activity events

If `tasks` is empty, do not show a misleading “Tasks completed” metric.

Use label:

```text
Work completed
```

Counting rule:

1. If `tasks` has rows for that agent/date range, count structured task statuses from `tasks`.
2. If `tasks` has zero rows, fall back to `activity_events`:
   - completed work: success events with task/report/output completion kinds
   - failed runs: error/failed events
   - needs review: `needs_review` events
   - open tasks: `0` or unknown until tasks are populated

## Reports delivered

`reports_delivered` should count from `reports`, not from `activity_events`.

Activity events may have `related_report_id` for linking, but reports remain the durable artifact source of truth.

## Success rate

Use:

```text
success / (success + warning + error + needs_review)
```

If denominator is 0, show `—` / null, not 100%.

Unknown events should count in an unknown bucket but should not affect success rate.

## Activity log feed

Rows should show:

- timestamp
- agent name
- kind / task type
- resolved status
- resolved source
- summary
- related report link, if any
- privacy level
- expandable safe detail

Filters:

- agent
- status
- source
- kind prefix/search
- date range

Pagination:

- default limit 50
- cursor on `(occurred_at, id)`

Detail endpoint must filter by both `company_id` and `id`. It should return only `payload_summary` from the safe table and must never query raw sibling tables.

## Security rules

- Normal users read only safe `activity_events` via RLS/company scope.
- `activity_event_raw` remains super-admin/admin-only.
- UI expansion shows safe `payload_summary` only.
- Never expose raw payloads, email bodies, headers, cookies, auth tokens, or secrets.
- If service-role functions are used, every query must explicitly filter by `company_id`.

## Debugging zero metrics

When metrics show zero:

1. Count `activity_events` by company/date/agent/status/source/kind.
2. Count `reports` by company/date/agent.
3. Confirm agent IDs/profile mappings match the workforce sync output.
4. Confirm `occurred_at` is inside the selected range.
5. Confirm fallback status/source derivation works for legacy rows.
6. Confirm RLS/company scope is not hiding the rows.
7. Only then inspect UI aggregation.

Likely cause in early agentesPRO dashboard work: Hermes has not yet emitted real activity events for chat/session work, so the dashboard has no operational data to count.

## Temporary seed endpoint for visual QA

A temporary seed endpoint is acceptable before real Hermes event emission exists:

```text
POST /api/public/admin/seed-activity
```

Requirements:

- super-admin only
- no anon and no normal company member
- explicit target `company_id`
- safe `payload_summary` only
- no raw payload insertion
- tag every row with `seeded: true` and `seed_batch`, e.g. `metrics-v1-visual-qa`
- provide a cleanup path like `clear-seeded-activity` or `clear_existing_seed: true`
- remove/disable after real event ingestion is online

Seed about 30 realistic events across agents, statuses, sources, and date ranges so the UI can be visually verified.

## Verification checklist

- Seed explicit `status`/`source` rows and legacy null rows.
- Verify last hour/today/week/month/all-time change the numbers.
- Verify `reports_delivered` comes from `reports` only.
- Verify User A cannot read Company B rows or details.
- Verify row expansion never touches raw tables.
- Verify unknown rows are visible but excluded from success rate.
- Verify activity logs paginate at 50 rows.
