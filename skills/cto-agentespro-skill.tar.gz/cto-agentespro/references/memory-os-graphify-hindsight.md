# Memory OS: Obsidian + Graphify + Hindsight

Use this reference when implementing a reusable memory layer for agentesPRO, Hermes agents, client VPS deployments, or multi-agent websites.

## Core model

- **Obsidian is the library**: official human-readable source of truth, SOPs, project notes, prompts, decisions.
- **Graphify is the map**: project/code/document relationship graph for repos, websites, skills, docs, and workflows.
- **Hindsight is the memory**: agent learning layer for durable preferences, corrections, outcomes, and lessons.
- **agentesPRO is the interface**: the website/dashboard/agent product that exposes the memory layer.

## Recommended implementation sequence

### Phase 1 — Graphify + structure first

1. Create a project Memory OS root, usually `/root/memory-os` for internal agentesPRO work.
2. Create a project manifest: `projects/<project-id>/memory-manifest.yaml`.
3. Create reusable templates for client/VPS installs.
4. Sync selected project sources into a safe corpus folder, excluding `.git`, `node_modules`, `dist`, binaries/media, caches, and env files.
5. Run Graphify for code-only AST graphs where no LLM key is available.
6. If no Graphify semantic LLM key is available, create a deterministic source graph fallback so the project still has a relationship map.
7. Add a healthcheck script that verifies manifests, corpus, source graph, and graph JSON outputs.
8. Save the human-readable source-of-truth note into Obsidian.

### Phase 2 — Hindsight later

1. Define Hindsight memory banks before deployment.
2. Use central Hindsight for Gus/internal company systems.
3. Use isolated Hindsight per client VPS for privacy and client boundaries.
4. Deploy only after Docker/runtime and provider key are confirmed.
5. Add retain/recall/reflect hooks only after Phase 1 retrieval structure is stable.

## Manifest pattern

Every serious agent website/client VPS should have a manifest with:

- project id/name/type/owner
- Obsidian vault path and scoped folders
- repo/source paths
- Graphify corpus/output paths
- Hindsight API/UI and memory bank names
- agent-specific scopes
- retrieval order
- conflict rules

Recommended retrieval order:

```txt
hindsight_recall -> obsidian_source -> graphify_query -> live_files -> action -> verification -> hindsight_retain
```

## Conflict rules

When systems disagree:

1. Live repo/files win for actual implementation state.
2. Obsidian wins for official company/project knowledge.
3. Hindsight wins for preferences, corrections, outcomes, and behavior lessons.
4. Graphify wins for structural file/code/document relationships.

## Graphify pitfall

`graphify extract` can build code-only AST graphs with no LLM key, but full semantic extraction for docs/markdown/media needs a provider key such as `GEMINI_API_KEY`, `GOOGLE_API_KEY`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, etc. Do not block the whole Memory OS if keys are absent: build AST graphs plus a deterministic source graph fallback, then mark semantic graphing as pending.

## Reusable comandos

Internal agentesPRO prototype paths:

```bash
/root/memory-os/scripts/run_graphify_project.sh agentespro
/root/memory-os/scripts/memory_healthcheck.sh
```

Expected useful artifacts:

```txt
/root/memory-os/projects/<project>/memory-manifest.yaml
/root/memory-os/projects/<project>/graphify/source-graph.json
/root/memory-os/projects/<project>/graphify/SOURCE_GRAPH_REPORT.md
/root/memory-os/projects/<project>/graphify/code-graphs/*/graphify-out/graph.json
```

## Productization rule

For agentesPRO client tiers:

- Small site: Markdown + simple search.
- Medium site: Markdown + vector/RAG.
- Large agent site: Obsidian/Markdown + Graphify + Hindsight.

Never present Graphify as something that must be visible inside the public website. It is normally an internal intelligence layer for agents.
