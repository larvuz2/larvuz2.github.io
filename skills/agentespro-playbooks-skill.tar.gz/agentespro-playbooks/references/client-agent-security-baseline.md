# Client Agent Security Baseline

Use this when packaging or installing a new agentesPRO client/company agent from a template.

## Goal

Make the client agent safe enough to turn on without over-engineering the setup.

Default posture: low-complexity, high-impact hardening only. Do not break working client workflows.

## Baseline checklist

- Install/load a defensive cybersecurity skill set such as `anthropic-cybersecurity-skills`.
- Keep all cybersecurity skills behind an authorized-use boundary: owned/authorized systems only; no stealth, credential theft, real exfiltration, malware deployment, destructive impact, or evasion.
- Verify sensitive files are private:
  - `~/.hermes/config.yaml` → `600`
  - `~/.hermes/.env` → `600`
  - `~/.hermes/auth.json` → `600`
  - git credentials → `600`
  - Hermes directories → `700`
- Keep `security.redact_secrets = true`.
- Set `privacy.redact_pii = true` unless the client explicitly needs raw IDs in session context.
- Set `approvals.destructive_slash_confirm = true`.
- Keep `security.allow_private_urls = false` unless a private-network workflow is explicitly scoped.
- Check exposed ports with `ss -ltnp`.
- Avoid API/webhook services bound to `0.0.0.0` unless there is a real external integration need.
- If an API server or webhook must be public, route through Caddy/HTTPS, require an API key/secret, and restrict CORS to known client domains.
- Verify after changes with `hermes config check` and `hermes status --all`.

## Safe patch sequence

1. Back up `~/.hermes/config.yaml`.
2. Apply only one or two low-risk config changes first.
3. Verify Hermes still starts and the gateway still runs.
4. Only then consider network exposure changes.

## Do not do by default

- Do not disable working gateways without a rollback path.
- Do not bind everything to localhost if a known public integration depends on direct access.
- Do not rotate credentials unless the task explicitly calls for it.
- Do not perform a broad hardening sweep when Gus asked for simple, low-risk patches.
