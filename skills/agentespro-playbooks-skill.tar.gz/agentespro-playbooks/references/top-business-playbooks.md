# Top Business Playbooks

Use this reference when Gus asks for the most useful agentesPRO Playbooks for businesses, marketplace seeding, default templates, or what to build first.

## Ranked default list

1. **Lead Generation + Outreach** — direct revenue creation; finds qualified leads, drafts outreach, follows up, and books meetings.
2. **Inbound Lead Qualification** — turns forms, DMs, and inbox messages into scored opportunities and routed replies.
3. **Weekly Content Engine** — creates a repeatable content batch from business updates, trends, offers, and founder ideas.
4. **Client Onboarding** — turns a signed client into folders, docs, kickoff agenda, task board, welcome email, and missing-asset tracker.
5. **Meeting → Actions** — converts transcripts/notes into summaries, decisions, tasks, owners, deadlines, and follow-ups.
6. **Customer Support Triage** — classifies tickets, drafts replies, escalates urgent issues, and reports recurring problems.
7. **SEO Blog + Knowledge Base** — turns expertise into search articles, support docs, internal links, and CMS-ready drafts.
8. **Proposal + Quote Builder** — converts discovery calls/briefs into scope, pricing options, timeline, risk flags, and proposal drafts.
9. **Finance Follow-up + Cashflow** — tracks invoices, flags late payments, drafts follow-ups, and summarizes cashflow actions.
10. **Hiring + Candidate Screening** — screens applicants, ranks fit, drafts interview questions, shortlists, and schedules next steps.

## First three to build

1. **Lead Generation + Outreach** — highest perceived ROI and easiest sales story.
2. **Meeting → Actions** — universal, low-risk, high-retention utility.
3. **Client Onboarding** — strong for agencies/service businesses and makes agentesPRO feel like an operating system.

## Marketplace categories

Sales:
- Lead Generation + Outreach
- Inbound Lead Qualification
- Proposal + Quote Builder

Marketing:
- Weekly Content Engine
- SEO Blog + Knowledge Base

Operations:
- Client Onboarding
- Meeting → Actions
- Finance Follow-up + Cashflow

Support:
- Customer Support Triage

People:
- Hiring + Candidate Screening

## Product framing

Use this sentence when positioning the set:

> agentesPRO Playbooks help businesses install ready-made agent teams for common goals: getting leads, replying faster, creating content, onboarding clients, managing meetings, collecting payments, and running operations.

## Default selection heuristic

When ranking business Playbooks, prioritize:

1. Direct revenue impact.
2. Universality across business types.
3. Frequency of use.
4. Clear before/after value.
5. Low permission risk for v1.
6. Easy demo with common tools like email, calendar, docs, CRM, and forms.
