---
name: creative-media-generation
description: "Generate and manipulate creative media across AI image/video/audio tools, ComfyUI workflows, model-specific helpers, segmentation, and delivery packaging."
version: 1.0.0
author: Hermes Agent
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [creative, media, image-generation, comfyui, audio, segmentation]
---

# Creative Media Generation

Use this umbrella when a task asks for AI-generated or AI-assisted media: images, video/image workflows, audio/music/sound, ComfyUI pipelines, masks/segmentation, prompt iteration, provider delivery, or model/workflow setup.

## Workflow

1. Clarify the deliverable only when the output modality or constraints are genuinely ambiguous.
2. Choose the execution path:
   - Hermes `image_generate` / `video_generate` for quick user-facing generations.
   - ComfyUI when the task needs local workflows, nodes, model management, or repeatable JSON workflow execution.
   - AudioCraft/MusicGen-style tools for local audio/music generation.
   - segmentation/masking helpers when the image task needs object masks, cutouts, or region-specific editing.
3. Preserve references, prompts, seeds, provider/model names, and generated artifact paths in the final response.
4. Verify artifact existence or URL accessibility before claiming completion.

## References and absorbed playbooks

Detailed subsection summaries live under `references/<skill-name>.md`; complete original narrow packages were archived intact during umbrella consolidation and can be restored if their support files are needed. Session-specific patterns live in `references/`.

- `references/money-making-agent-marketplace-ui.md`: UI prompt pattern for Hermes/AI money-machine marketplaces with outcome-machine cards, cost/yield metrics, and verification notes.
- `references/gus-personal-site-static-blog-publishing.md`: Gus personal website static blog publishing pattern: `staticBlogPosts.ts`, `public/blog/<slug>.png`, local preview, production cache-bust verification, and push/rebase workflow.
- `references/gus-static-blog-post-publishing.md`: compact current pattern for publishing static blog posts to `/root/work/gus`: write post in `staticBlogPosts.ts`, store hero under `public/blog/`, add sitemap URL, build, local-check, push, and production-verify canonical route.
- `references/hermes-profile-fal-image-generation-setup.md`: Target-profile FAL image generation setup: copy `FAL_KEY`, add `image_gen` config/plugin blocks, restart gateway/new session, and verify with a real target-profile `image_generate` call.
- `references/article-tldraw-explainer-workflow.md`: Article/X essay to TLDraw-style infographic workflow: source fallback, deterministic HTML/SVG/CSS board, Playwright PNG render, vision QA, overflow patch loop.
- `references/perception-natural-pattern-image-prompts.md`: Gus-specific image direction for brain/nature/perception/weird-wonder visuals — prefer microscopic/macro natural pattern continuity over literal fantasy forests or human silhouettes.
- `ai-image-generation-workflows`: FAL/image-generation prompting, edits, logo/text pitfalls, media delivery.
- `comfyui`: ComfyUI install/launch/workflow execution, REST/WebSocket API, node/model troubleshooting, reusable scripts.
- `audiocraft-audio-generation`: local AudioCraft/MusicGen audio generation procedures.
- `segment-anything-model`: SAM object segmentation via points, boxes, masks.

## Text-heavy whiteboard / tldraw infographics

When Gus asks for an explanation of a term, concept, process, system, strategy, or workflow, proactively complement the text with a casual TLDraw/Excalidraw-style visual when it will make the idea easier to grasp. Do not make it feel like a formal extra deliverable; send it naturally alongside the answer. Choose detail level by topic: broad concept map for strategic/simple questions, detailed flow diagram for process/system/workflow questions.

When the user asks for a clean tldraw-style plan, schedule, workout card, checklist, or other text-heavy image:

1. Use a white background, hand-drawn/excalidraw/tldraw-style boxes, minimal pastel accents, and simple line icons.
2. Keep copy short and structured; image models handle concise bullets better than dense paragraphs.
3. Put the exact hierarchy in the prompt: title, subtitle, layout, cards/sections, bottom notes.
4. Explicitly request readable high-contrast typography and no UI/logos/clutter.
5. After generation, verify visual legibility before delivery. If text is gibberish or crowded, regenerate with fewer words and larger sections.

See `references/tldraw-plan-infographics.md` for a reusable prompt structure.

## Browser-native creative coding prototypes

When turning a creative prompt into a small Vite/React/Canvas/Web MIDI prototype:

1. Build the working artifact, not just a prompt/spec: scaffold files, install dependencies, and run `npm run build`.
2. Include live-performance fallbacks: Web MIDI where available, keyboard controls for non-MIDI verification, and a clean capture/hide-UI mode.
3. For canvas clips, add a `canvas.captureStream()` + `MediaRecorder` export button when the brief asks for a 20–30 second capture; this avoids requiring external screen-recording setup for first review.
4. Verify in-browser behavior with the browser tool: load the local Vite server, press a few fallback keys, inspect console errors, and visually confirm the canvas renders the intended aesthetic before reporting completion.
5. Keep the first prototype scoped to the visual mechanic and constraints; avoid adding dashboards, unrelated 3D rooms, UI labels, or extra systems that flatten the concept.

## Blog / website hero image workflow

When Gus asks to generate an image for an existing article/blog post and add it to the site:

1. Generate a visually explanatory hero image, not just decoration. For concept/strategy posts, prefer clean editorial diagrams, dashboard metaphors, or tldraw-style system maps that make the thesis easier to understand.
2. Inspect the generated image with `vision_analyze` before using it. Check: concept fit, legibility, no broken/watermark text, no unwanted logos, no distracting mascots unless requested.
3. Store the asset in the website repo under a stable public path such as `public/blog/<slug>.png` or `public/blog/<slug>.webp`.
4. Wire the post data to the asset path. On Gus’s site this may mean updating `src/data/staticBlogPosts.ts` `image_url` for static posts; inspect the post renderer/data source first instead of guessing.
5. Build locally, run the site locally, open the exact blog URL, and verify the hero image appears with a nonzero natural size.
6. Push to the live site repo and wait for deployment. Then open the canonical `gusgarza.com` URL in browser, check the image source/natural dimensions, and inspect console errors before reporting done.

## Cross-profile image generation setup

When Gus asks to make another Hermes profile generate images with the same FAL/GPT-image behavior, do not stop at writing usage rules into that profile's skill. Configure the target profile runtime too: `.env` must contain `FAL_KEY`, `config.yaml` must include the `image_gen` provider/model/plugin block, the gateway/session must restart, and success must be verified by running a real image generation from that target profile. See `references/hermes-profile-fal-image-generation-setup.md` for the exact checklist.

## Quality checks

- For files: `test -s <path>` or inspect metadata before delivery.
- For generated visuals: review with `vision_analyze` when visual correctness matters, especially text-heavy images.
- For website/blog hero images: verify both local render and live canonical URL; include image path, commit SHA, build result, deployment state, and browser verification in the final report.
- For browser-native creative prototypes: verify both build output and live browser render/console state; include the repo/path/commit and commands run in the final report.
- For ComfyUI: health-check the server, validate workflow JSON integrity, and monitor queued jobs rather than assuming success.
- For provider APIs: report real returned URLs/paths and any rate-limit/provider failure honestly.
