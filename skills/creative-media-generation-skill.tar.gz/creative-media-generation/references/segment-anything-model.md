# segment-anything-model

Absorbed into `creative-media-generation` during the 2026-06-19 umbrella consolidation pass.

Original description: SAM: zero-shot image segmentation via points, boxes, masks.

The complete original skill package, including any support files and relative links, was archived intact at:

`.archive/curator-umbrella-20260619/creative-media-generation/segment-anything-model`

Package inventory before archive: references/ (2 files).

Use the parent umbrella workflow first. Restore or inspect the archived package only when this subsection's detailed provider/tool-specific recipes are needed.
