# Gus personal site static blog publishing

Use when adding a generated blog post to Gus's personal website.

Observed repo/pattern:
- Repo: `/root/work/gus`
- Static blog source: `src/data/staticBlogPosts.ts`
- Static images: `public/blog/<slug>.png`
- Route: `/blog/:id`; static posts resolve by `id` or `slug`.
- Homepage writing section reads `staticBlogPosts` first and shows the newest entries before remote Supabase duplicates.

Workflow:
1. Inspect `src/data/staticBlogPosts.ts` and `src/pages/BlogPost.tsx` before editing; do not assume schema.
2. Generate or choose a hero image when the post benefits from it. For concept essays, prefer clean TLDraw/scientific whiteboard diagrams over decorative art.
3. Download the image into `public/blog/<slug>.png`; verify with `test -s` and `file`.
4. Insert the post near the top of `staticBlogPosts` with stable `id`, `slug`, `title`, `image_url`, `published: true`, timestamps, metadata, and full `content` as a template literal.
5. Run `npm run build`.
6. Run a local preview (`npm run preview -- --host 127.0.0.1 --port 4173`) and open `/blog/<slug>` in browser.
7. Verify with DOM/console checks: title, H1, hero `naturalWidth > 0`, a distinctive body sentence, and no JS errors.
8. Commit and push. If push is rejected because remote moved, `git pull --rebase origin main`, rebuild, then push.
9. Production can briefly serve the previous asset bundle. Check the live HTML references the new `assets/index-*.js` or includes the slug; if not, wait/retry. Use a cache-busting query like `/blog/<slug>?verify=<sha>` for browser verification.
10. Final report should include live URL, build result, commit SHA, and production verification.

Pitfalls:
- Do not stop at committing; verify production actually serves the post.
- Do not harden transient deployment lag into a tool failure. The useful pattern is wait/retry and cache-bust.
- If the writing request was corrected toward “more scientific,” depersonalize the post before publishing; avoid making it mainly about Gus's own projects.
