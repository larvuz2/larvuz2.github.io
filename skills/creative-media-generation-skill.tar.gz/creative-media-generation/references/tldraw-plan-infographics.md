# tldraw-style plan infographic prompt pattern

Use when generating a clean visual plan, weekly schedule, checklist, or routine card in a tldraw / excalidraw whiteboard style.

## Prompt structure

```text
Create a clean full-page [topic] infographic in the style of a hand-drawn tldraw whiteboard.
Pure white background, simple black sketch lines, subtle pastel accent blocks, neat handwritten-looking labels, clean spacing, minimal line icons.
No logos, no UI, no clutter.

Title at top: [TITLE]
Subtitle: [short useful framing]

Layout: [number] cards/sections, organized like a clean tldraw board.
Each card has a small icon and concise bullet list.

[SECTION 1]
[short bullets]

[SECTION 2]
[short bullets]

Bottom small section: [daily notes / totals / supplements]
[short bullets]

Make the typography readable, high contrast, balanced, clean, tldraw/excalidraw-style imperfect hand-drawn boxes and arrows, white background.
```

## Legibility rules

- Prefer portrait for full weekly plans.
- Use short bullets, not paragraphs.
- Avoid too much text per card.
- Ask for exact title/subtitle/section labels.
- Validate the generated image before delivery; if text is broken, regenerate with fewer words.

## Common fit for Gus

- Weekly health plans.
- Simple AI system diagrams.
- Founder operating maps.
- Creative-tech workflow explainers.
- White-background deck-ready diagrams.
