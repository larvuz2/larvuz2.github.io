# Gus static blog post publishing pattern

Use when Gus asks to create/publish a blog post on his website from a current conversation or concept.

## Repo and data path

- Website repo: `/root/work/gus`
- Static posts live in `src/data/staticBlogPosts.ts`
- Blog hero images should live under `public/blog/<slug>.png`
- The canonical route is usually `https://gusgarza.com/blog/<slug>`
- Add blog routes to `public/sitemap.xml` when publishing durable static posts.

## Workflow

1. Shape the post in Gus/Larvuz voice: direct, founder/creative-technical, no corporate padding.
2. Generate or choose a blog hero that explains the thesis visually, not just decoration.
3. Inspect the hero image before committing it. Check for clear concept, readable main labels, no broken text/watermarks/logos.
4. Download/store the asset at `public/blog/<slug>.png`.
5. Add a new `staticBlogPosts` entry near the top of `src/data/staticBlogPosts.ts` so it appears first in Writing/Browse.
6. Use stable fields: `id`, `slug`, `title`, `image_url`, `published`, `created_at`, `updated_at`, `metadata`, `content`.
7. Run `npm run build`.
8. Preview locally and verify:
   - route loads
   - `h1` matches
   - hero `img` resolves with real dimensions or is visually visible
   - `.blog-content` contains the expected ending text
   - no console errors
9. Commit and push to `main`.
10. Production-verify on the clean canonical URL. If Netlify/browser cache shows old JS or “Post not found,” retry with a cache-busting query once, then reload the clean URL.
11. Use browser vision if DOM image dimensions look stale but the image URL is reachable; visual confirmation is the final check.

## Pitfalls

- Do not stop after adding text locally. Gus expects the live website pushed and verified.
- Do not leave the hero image remote-only; store it in the repo under `public/blog/`.
- Do not rely only on DOM `naturalWidth` during cache/transient reload states. Also check the asset URL with HTTP/file metadata and inspect visually.
- The blog article body uses the site’s dark background and white text; if screenshots look partly white, scroll/inspect actual content before assuming a rendering bug.

## Example post thesis from session

Creative Partner positioning:

- Not an OS publicly; “OS” sounds too technical.
- The system leads; the user steers.
- AI has agency without authority.
- The human is the creative director, not the operator.
- Entertainment at the front, workspace underneath.
- Taste becomes memory; worlds become projects.
