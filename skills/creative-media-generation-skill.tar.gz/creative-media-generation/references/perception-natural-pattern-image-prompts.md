# Perception / Nature / Microscopic-Macro Pattern Image Direction

Use when Gus asks for visuals around brain, nature, perception, weird wonder, neuroaesthetics, hidden systems, or natural pattern intelligence.

## Session lesson

A first-pass cinematic forest/neural scene with a human silhouette felt too literal/fantasy. Gus preferred the later direction when it became:

- more microscopic;
- more macro-natural-pattern;
- more intrinsic and interwoven;
- less scene, more hidden grammar of nature across scales.

## Strong direction

Frame the image as **scale ambiguity**: impossible to tell whether it is a microscope slide, satellite image, organism, neural tissue, river delta, fungal web, coral, ice fracture, or cosmic structure.

Use motifs like:

- cellular membranes;
- mycelium threads;
- neural/capillary branching;
- leaf venation;
- coral growth;
- lichen/mineral surfaces;
- pollen/spores;
- river deltas;
- ice fractures;
- tree rings;
- wave interference;
- turbulence and growth fronts.

The key thesis: **one hidden natural pattern repeating across scales.**

## Visual language

Prefer:

- extreme macro / microscope perspective;
- tactile wet/mineral/organic surfaces;
- translucent layered membranes;
- fine interwoven filaments;
- soft internal glow;
- muted moss green, teal, indigo, amber-gold, pearlescent whites, rust/mineral accents;
- dense but elegant composition;
- quiet awe / soft fascination.

Avoid:

- human silhouettes;
- literal forests;
- glowing portals;
- obvious brain icons;
- skulls;
- clipart neurons;
- generic sci-fi/cyberpunk;
- mandala clichés;
- oversaturated neon;
- medical diagram aesthetics;
- fake spiritual symbolism.

## Reusable prompt core

```text
Create a sophisticated 16:9 art-science image about microscopic and macro natural patterns. No humans, no faces, no text, no logos, no UI.

Show a seamless scale-shift where cellular membranes become river deltas, mycelium becomes neural branching, leaf veins become coral growth, lichen becomes mineral crystal, pollen becomes stars, ice fractures become vascular networks, and tree rings become wave interference. Everything should feel like one hidden grammar of nature: self-similarity, branching, spirals, lattices, membranes, veins, filaments, pores, turbulence, growth fronts, and capillary flow.

Make it extreme macro / microscope-like, but with hints of landscapes inside the details. Dense but elegant. A woven diagonal flow crosses the frame, with nested pattern islands of crystalline geometry, fungal threads, plant veins, neural/capillary webs, soft cellular bubbles, eroded river channels, and tiny bioluminescent spores. Soft depth-of-field, tactile wet mineral surfaces, translucent layers, quiet internal glow.

Palette: deep moss green, muted teal, dark indigo, amber-gold bioelectric accents, pearlescent membrane whites, subtle rust and mineral tones. Mature, strange, beautiful, scientific wonder. Avoid literal forests, human silhouettes, portals, cyberpunk, cheap fractal art, medical diagrams, and obvious spiritual symbols. It should be impossible to tell whether this is a microscope slide, satellite image, living organism, or universe.
```
