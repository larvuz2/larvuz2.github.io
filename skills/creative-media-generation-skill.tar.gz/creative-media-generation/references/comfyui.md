# comfyui

Absorbed into `creative-media-generation` during the 2026-06-19 umbrella consolidation pass.

Original description: Generate images, video, and audio with ComfyUI — install, launch, manage nodes/models, run workflows with parameter injection. Uses the official comfy-cli for lifecycle and direct REST/WebSocket API for execution.

The complete original skill package, including any support files and relative links, was archived intact at:

`.archive/curator-umbrella-20260619/creative-media-generation/comfyui`

Package inventory before archive: references/ (4 files), scripts/ (11 files).

Use the parent umbrella workflow first. Restore or inspect the archived package only when this subsection's detailed provider/tool-specific recipes are needed.
