# Money-Making Agent Marketplace Visual Prompts

Use this when Gus asks for UI images around agents that make money, agent marketplaces, or “money machines.”

## Stronger concept frame

Avoid generic “lead generation” cards unless Gus explicitly asks. The sharper frame is outcome machines: agents that directly create, collect, recover, negotiate, sell, license, build, or compound revenue.

Useful card names:

- Deal Taker — monitors marketplaces and claims profitable arbitrage opportunities.
- Offer Machine — turns existing skills, files, workflows, templates, or media into small paid offers.
- Upsell Engine — expands current clients into higher-value packages.
- Invoice Collector — follows up, negotiates, and recovers unpaid invoices.
- Price Raiser — detects underpriced services and rewrites them into premium tiers.
- Asset Licenser — packages unused media, prompts, loops, templates, characters, or IP for licensing.
- Micro-SaaS Builder — turns repeated workflows into tiny paid tools.
- Sponsorship Closer — packages projects, audiences, communities, or IP into sponsor-ready deals.

## Metrics to show on UI cards

- Money Action
- Estimated Cost / Est. Cost
- Time to First Dollar
- Expected Monthly Yield
- Human Approval
- Automation Level
- Risk
- ROI Estimate
- Best Margin
- Does it deserve more fuel?

Example values:

- Est. Cost: `$3–$45/run`
- Time to First Dollar: `2h`, `24h`, `3 days`, `7 days`
- Expected Monthly Yield: `$300–$2k`, `$1k–$8k`, `$5k–$25k`
- Human Approval: `Required`, `Optional`, `Auto`
- Automation Level: `72%`, `88%`, `94%`
- Risk: `Low`, `Medium`

## Visual direction

Use a premium SaaS / AI command center aesthetic:

- Clean white editorial dashboard.
- Dark navy glass panels as accents, not heavy dark mode.
- Electric green for revenue.
- Blue for automation.
- Small amber risk chips.
- Dense but elegant.
- Shopify App Store + Bloomberg terminal + AI operating system.

Avoid:

- Cartoon mascots.
- Fake 3D characters.
- Generic “AI assistant” cards.
- Lead-gen-heavy positioning when Gus asks for money machines.
- Logo/watermark clutter.

## Verification

After generating, inspect the image with vision when visual correctness matters. Specifically check whether the UI reads as a marketplace dashboard, whether the agent cards are visible, and whether text labels/metrics are at least partially legible.
