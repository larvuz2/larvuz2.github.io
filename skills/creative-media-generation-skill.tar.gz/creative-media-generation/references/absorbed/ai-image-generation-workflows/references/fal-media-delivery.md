# FAL Media Delivery Pattern

Session signal: Gus explicitly corrected FAL image delivery. He wants generated images delivered as actual Telegram media/photos so they are saved in chat, not as URL-only markdown links.

## Pattern

1. Call `image_generate` or the relevant FAL-backed image/edit tool.
2. If the tool returns an HTTPS URL, download the file to a local path:

```bash
python - <<'PY'
import urllib.request
url = 'https://...returned-image.png'
out = '/tmp/descriptive-image-name.png'
urllib.request.urlretrieve(url, out)
print(out)
PY
```

3. Final response should include:

```text
Done.

MEDIA:/tmp/descriptive-image-name.png
```

This makes Telegram upload it as native media/photo.

## Avoid

- Do not send only `![image](url)` for FAL outputs unless Gus asks for link-only delivery.
- Do not paste only the raw FAL URL.
- Do not over-explain the prompt in the final reply unless requested.

## Tldraw explainer checklist

When Gus asks for a tldraw-style explainer image:

- 16:9 landscape.
- White background.
- Hand-drawn marker lines.
- Rounded boxes, arrows, sticky notes.
- Pastel fills by semantic category.
- Big readable text.
- Central loop/system map when explaining architecture.
- Include a concise formula sticky note if helpful.
- Negative constraints: no 3D, no logos, no corporate infographic, no tiny unreadable text, no photorealistic rendering.

## Example final delivery

```text
Done.

MEDIA:/tmp/hermes-secret-sauce-tldraw.png
```
