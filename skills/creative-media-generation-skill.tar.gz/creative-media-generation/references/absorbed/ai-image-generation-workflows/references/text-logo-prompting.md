# Text / Logo Prompting Notes for Gus

Use this reference when Gus asks for logos, wordmarks, posters, interface labels, titles, or any image where readable text matters.

## Core rule

Use the GPT/GPT-2 image workflow/model when available. Default image models often produce attractive visuals but weak typography. For text/logo work, legibility and exact spelling beat visual richness.

## Prompt structure

1. State the output type clearly: `wordmark exploration board`, `logo grid`, `typography sheet`, etc.
2. Put the text rule near the top:
   - `Every visible word must read exactly: gusgarza`
   - `lowercase only, one word, no spaces, no accents, no alternate spelling`
3. If the user wants the full word, explicitly ban initials:
   - `Do not make initials, monograms, isolated letters, or separate icons.`
   - `Every concept must use the full word.`
4. Lock the layout:
   - `4 columns x 3 rows, 12 total concepts`
   - `landscape 16:9 widescreen canvas`
5. Define taste:
   - `modern minimalist, premium, clean typography, strong negative space`
   - `flat vector, black/charcoal, warm off-white background`
6. Add negatives:
   - `no extra captions, no watermark, no 3D, no mockups, no shadows, no gradients, no illegible small text, no misspellings`

## Reusable prompt skeleton

```text
Widescreen wordmark exploration board for the personal brand [EXACT_NAME].

CRITICAL TEXT RULE: Every design must use the full word exactly: [EXACT_NAME]. [case rule]. One word. No spaces. No accents. No alternate spelling. No extra words. Do not make initials, monograms, isolated letters, or separate icons.

Layout: [COLUMNS] columns x [ROWS] rows grid, [TOTAL] total concepts, landscape 16:9 canvas, warm off-white background, generous spacing. Each cell contains one full-word logo reading exactly “[EXACT_NAME]”.

Design direction: top-notch modern minimalist wordmarks, elegant personal brand, creative technologist / cinematic founder / design studio energy. Simple but premium. Custom typography, refined spacing, subtle cuts, clean lowercase geometry, quiet confidence.

Visual rules: flat vector only, black/charcoal ink, warm gray, optional muted copper accent. Lots of whitespace. Crisp typography. Balanced proportions. No icons separate from the word. No initials. No 3D. No mockups. No gradients. No shadows. No texture. No captions. No watermark. No illegible micro text. No misspellings.
```

## Pitfalls from session

- A grid of logo examples can drift into `GG` monograms even when Gus wants the full word. Ban initials explicitly.
- Text/logo requests should not be treated like normal image generation. Model choice matters.
- If Gus says “again,” preserve the corrected constraints from the prior failed attempt and strengthen them, instead of just making the style adjectives stronger.
