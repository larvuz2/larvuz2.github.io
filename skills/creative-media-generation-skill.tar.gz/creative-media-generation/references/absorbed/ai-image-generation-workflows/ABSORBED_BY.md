# Absorbed package

Original top-level skill `ai-image-generation-workflows` was consolidated into umbrella `creative-media-generation`. This directory preserves the complete package contents for reference after archival.
