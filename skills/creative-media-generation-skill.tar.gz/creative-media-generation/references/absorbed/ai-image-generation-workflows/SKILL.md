---
name: ai-image-generation-workflows
description: Generate, edit, and deliver AI images for creative/technical work, including FAL image generations, reference-based edits, cinematic prompt crafting, tldraw-style explainers, and chat-native media delivery.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [image-generation, fal, creative-direction, tldraw, delivery]
    created_by: agent
---

# AI Image Generation Workflows

Use this skill when Gus asks to generate, edit, improve, or deliver AI images, especially via FAL or for cinematic / diagrammatic / tldraw-style visuals.

## Core workflow

1. **Infer the image goal fast.** If the request is clear, do not ask follow-up questions.
2. **Write the prompt with production direction.** Include subject hierarchy, composition, style, lighting, camera/framing, constraints, and negative instructions.
3. **Call the image generation/edit tool.** Use the configured provider; do not invent model names or fake outputs.
4. **Deliver the actual generated asset into chat.** For FAL-generated images, download the returned image URL to a local file and respond with `MEDIA:/absolute/path/to/file` so Telegram saves it as a photo/media item. Do not send URL-only delivery unless Gus explicitly asks for a link.
5. **Keep the final reply minimal.** Usually: `Done.` plus the `MEDIA:` attachment. Avoid extra explanation unless the user asked for prompt details.

## Gus-specific delivery rule

- FAL image generations must be delivered as actual chat media/photos, not just markdown image links or bare URLs.
- If the tool returns only a URL, download it first, save it under `/tmp/` or a relevant project folder, then include `MEDIA:/path/to/image.png` in the final response.

## Text and logo generation rule

When Gus asks for image generation containing readable text, typography, wordmarks, or logos, route to the GPT/GPT-2 image workflow/model when available instead of the default image workflow. Text accuracy is the priority.

For logo/wordmark explorations:

- If Gus asks for the whole word/name, do **not** make initials, monograms, isolated letters, or separate icons unless he asks for them.
- Repeat the exact required spelling in the prompt as a hard constraint.
- For personal-brand wordmarks like `gusgarza`, specify lowercase, one word, no spaces, no accents, no alternate spelling, no extra captions.
- If he requests a grid, obey the exact grid and aspect ratio, e.g. `4 columns x 3 rows`, `landscape 16:9`.
- Favor modern minimalist, premium, clean typography over decorative logo marks.

See `references/text-logo-prompting.md` for reusable prompt patterns and pitfalls.

## Tldraw / whiteboard explainer images

For requests like “same style,” “tldraw,” “whiteboard,” “explain this visually,” or “diagram style”:

- Use 16:9 landscape by default unless specified otherwise.
- Ask for clean hand-drawn rounded boxes, arrows, sticky notes, black marker outlines, pastel fills, and white background.
- Keep text large and legible; avoid tiny labels.
- Structure the image as a clear system map: title, central idea, layers, arrows, comparison boxes, formula sticky note when useful.
- Avoid corporate infographic, 3D render, logos, photorealism, glossy UI, and dense unreadable text.

See `references/fal-media-delivery.md` for the exact FAL media delivery pattern and a reusable tldraw explainer prompt checklist.

## Verification

Before finalizing:

- Confirm the image tool returned success.
- If the result is a URL and the platform is Telegram, download the image to a local file.
- Ensure the final response includes `MEDIA:/absolute/path` for the image file.
- Do not claim delivery succeeded if the download failed; report the blocker and provide the URL as fallback only if necessary.
