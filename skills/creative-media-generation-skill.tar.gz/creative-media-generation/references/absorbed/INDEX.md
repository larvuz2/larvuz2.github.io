# Absorbed skill packages for `creative-media-generation`

Each subdirectory is a preserved package copied before archival. Use the umbrella SKILL.md as the entry point.

- `ai-image-generation-workflows/` — copied from `creative/ai-image-generation-workflows`

- `comfyui/` — copied from `creative/comfyui`

- `audiocraft-audio-generation/` — copied from `mlops/models/audiocraft`

- `segment-anything-model/` — copied from `mlops/models/segment-anything`
