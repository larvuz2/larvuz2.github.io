# Hermes profile FAL image-generation setup

Use when Gus asks to make another Hermes profile (for example `agentespro-hq`) generate images with the same FAL / GPT-image / Nano Banana Pro behavior as the current Larvuz profile.

## Lesson

Do not only add prompting rules to a skill. If the profile says `FAL_KEY environment variable is not set`, the runtime itself is missing provider configuration/credentials. Fix the profile environment and config, then verify with a real `image_generate` call from that profile.

## Setup checklist

1. Check the source/default profile has a FAL key in its `.env` without printing the value.
2. Copy the key into the target profile `.env` as `FAL_KEY=<secret>`.
3. Ensure the target profile `config.yaml` includes the image generation provider block:

```yaml
image_gen:
  model: fal-ai/nano-banana-pro
  use_gateway: false
  text_model: fal-ai/gpt-image-2
  route_text_requests: true
  provider: fal
plugins:
  enabled:
  - image_gen/fal
  - video_gen/fal
  disabled: []
video_gen:
  provider: fal
  fal:
    model: pixverse-v6
  model: pixverse-v6
```

4. Restart the target gateway/profile so env/config changes load. If running from inside a gateway and direct restart is blocked, schedule a detached restart from a separate process, then verify service activity.
5. Verify with a real target-profile one-shot:

```bash
hermes --profile <profile-name> chat -q "Generate one simple test image using the image_generate tool. Reply only with the generated image URL/path and provider if available." --toolsets image_gen,vision --quiet
```

6. Only report success after the command returns a real image URL/path and provider.

## Pitfall

A skill rule like “use `image_generate`” is not enough. The target profile needs `FAL_KEY`, `image_gen` config, plugin enablement, gateway restart/new session, and a real generation test.