# Article → TLDraw-style explainer workflow

Use when Gus asks for a TLDraw/Excalidraw-style image explaining an article, X article, LinkedIn post, essay, or long argument.

## Pattern from session

1. **Resolve the source first.** If an X API/MCP call fails or the X post points to an inaccessible article, search by tweet ID/title/author and use accessible mirrors or canonical reposts such as LinkedIn/article pages. Do not fabricate the article content.
2. **Extract the argument into a visual hierarchy:**
   - title / thesis
   - why now
   - upside
   - risks
   - proposed mechanism
   - step-by-step process
   - tension / open question
   - bottom-line interpretation
3. **Prefer deterministic HTML/SVG/CSS for text-heavy TLDraw-style explainers** instead of direct image generation. This preserves readable text and allows precise patching.
4. **Render to PNG with Playwright** when browser file navigation is blocked:
   - create `/root/artifacts/<slug>.html`
   - use Playwright `page.goto(Path(...).as_uri())`
   - set a large viewport matching the board size
   - `page.screenshot(path=..., full_page=True)`
5. **Always visually verify and patch.** Use vision inspection to check for overlap, cropped text, too-small text, or weak hierarchy. Patch the HTML and rerender until good enough.
6. **Keep final delivery simple:** send the PNG as `MEDIA:/absolute/path.png` and mention it was verified.

## Design notes

- White background, thick hand-drawn black borders, pastel cards, subtle shadows, big readable type.
- Use short text per card; long article nuance belongs in the layout, not dense paragraphs.
- For complex governance/strategy articles, a strong board shape is:
  `left = context/upside/risks`, `center = proposed answer`, `right = institution/political design`, `bottom = process + deep read`.
- If text overflows in step cards, shorten the words rather than shrinking the whole board.

## Pitfalls

- Direct image generation often mangles text; use deterministic rendering for text-heavy explainers.
- Do not stop after one render. Text overflow is common. Inspect, patch, rerender.
- If the original social URL is inaccessible, state/follow the fallback source internally, but do not clutter the final delivery unless provenance matters.