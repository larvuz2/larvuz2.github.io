# audiocraft-audio-generation

Absorbed into `creative-media-generation` during the 2026-06-19 umbrella consolidation pass.

Original description: AudioCraft: MusicGen text-to-music, AudioGen text-to-sound.

The complete original skill package, including any support files and relative links, was archived intact at:

`.archive/curator-umbrella-20260619/creative-media-generation/audiocraft-audio-generation`

Package inventory before archive: references/ (2 files).

Use the parent umbrella workflow first. Restore or inspect the archived package only when this subsection's detailed provider/tool-specific recipes are needed.
