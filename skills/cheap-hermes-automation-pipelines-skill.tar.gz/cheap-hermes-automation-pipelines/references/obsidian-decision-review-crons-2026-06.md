# Obsidian Drift + Decision Debt Cron Pattern — 2026-06

Use this as a reusable pattern for knowledge-base hygiene and decision-debt review jobs.

## Pattern

Prefer a cheap deterministic collector plus a concise human-facing digest:

```txt
no_agent collector script → local output → agent digest with context_from → Telegram
```

This keeps scanning cheap and lets the agent spend reasoning only on summarizing and prioritizing.

## Implemented job shapes

### Obsidian Drift Cleaner

- Collector: `Obsidian Drift Collector`
- Collector schedule: Sunday 17:55 America/Mexico_City / `55 23 * * 0` UTC
- Collector mode: `no_agent=True`, `deliver=local`
- Collector script: `obsidian_drift_collect.py`
- Digest: `Obsidian Drift Cleaner`
- Digest schedule: Sunday 18:00 America/Mexico_City / `0 0 * * 1` UTC
- Digest uses `context_from=<collector_job_id>`
- Category: `Review / Check`
- Collector category: `Sync / Health Check`

Collector signals worth surfacing:

- stale inbox/routing candidates
- recent notes changed
- signal-heavy notes containing TODO/pending/decision/follow-up words
- open markdown tasks
- possible orphan/unlinked notes
- top tags

Digest style:

- one-line vault health summary
- top 3 cleanup moves
- one concrete recommendation
- no note rewriting unless the user explicitly asks

### Decision Debt Review

- Job: `Decision Debt Review`
- Schedule: Friday 16:00 America/Mexico_City / `0 22 * * 5` UTC
- Script: `decision_debt_collect.py`
- Agent consumes script output and sends a short ranked review
- Category: `Review / Check`

Collector signals worth surfacing:

- decide/decision/choose/pending/blocked/stuck/approve/review/follow-up/TBD/todo language
- open `- [ ]` markdown tasks
- project hints from paths and text
- recency and signal score

Digest style:

- short diagnosis
- top 5 decision debts
- each item: `Decision:` + `Move:`
- end with the highest-leverage first decision
- do not invent decisions beyond collector evidence

## Dashboard metadata

When jobs should appear cleanly in agentesPRO/dashboard filters, add safe metadata to the Hermes cron job record:

```json
{
  "job_category": "Review / Check",
  "job_category_slug": "review-check",
  "job_display": {
    "category": "Review / Check",
    "category_slug": "review-check",
    "practical_name": "Decision Debt Review",
    "previous_name": "Decision Debt Review"
  }
}
```

If the dashboard schema cannot yet store arbitrary category fields, add a filter token to `toolsets` in the connector payload:

```txt
category:review-check
```

## Verification loop

1. Run collector script directly once and inspect first ~120 lines.
2. Create collector job with `deliver=local` and `no_agent=True`.
3. Create digest job with `context_from=[collector_job_id]`.
4. Force-run collector first.
5. Force-run digest second.
6. Confirm `last_status: ok` and next scheduled run returns to the intended cadence.
7. If the cron tool schedules but does not immediately execute, trigger with CLI `hermes cron run <job_id>` and wait for the scheduler tick.
8. Sync dashboard connector if recurring jobs are mirrored externally.

## Pitfalls

- Do not make the Obsidian drift digest a giant audit. The value is prioritization.
- Do not rewrite or move notes automatically from a scheduled hygiene job.
- Avoid persisting session-specific paths as universal rules; keep paths in the reference and make the main skill pattern class-level.
- Schedule paired collector/digest jobs a few minutes apart so `context_from` has fresh collector output.
