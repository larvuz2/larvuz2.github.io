# Gus / Larvuz cron optimization pass — 2026-06

Session learning from implementing cheap Hermes automation patterns in Gus's default Larvuz profile.

## Implemented architecture

```txt
Money Radar:
no_agent collector → context_from → focused daily agent brief

Weekly Creative Push:
no_agent creative-reference collector → context_from → focused weekly creative agent

Inbox Sentinel:
wakeAgent gate every 15m → agent wakes only for actionable candidates

Simple reminders:
fixed/calculated no_agent scripts, no model turn

Cron Control Room:
no_agent watchdog, silent when healthy, alerts on real cron/system issues
```

## Durable implementation patterns

### context_from collector pattern

Create a collector with:

- `no_agent=true`
- `script=<collector>.py`
- `deliver=local`
- schedule more frequent than the downstream briefer

Then update the downstream agent job with:

- `context_from=[collector_job_id]`
- a prompt that explicitly says the injected collector output is raw signal, not final truth
- a narrower `enabled_toolsets` list

Useful for money/opportunity scans, creative reference collection, status aggregation, and daily/weekly briefs.

### wakeAgent gate pattern

The gate script should emit exactly one of:

```json
{"wakeAgent": false}
```

```json
{"wakeAgent": true, "context": {"type": "new_actionable_items", "items": []}}
```

A successful `wakeAgent=false` run appears in cron output as:

```txt
Script gate returned `wakeAgent=false` — agent skipped.
```

Testing pitfall: a gate that tracks seen IDs may return `wakeAgent=true` on the first direct test and `wakeAgent=false` on the second because the first run marked items as seen. That is expected.

### no_agent reminder pattern

Convert deterministic reminders to scripts when the message is fixed or computable from date/time. Examples:

- daily supplement reminders
- weekly prep reminders
- payment reminders
- simple operational nudges

This avoids wasting a model turn to emit known text.

### Cron output path

Cron run outputs are stored under a directory per job, not directly as the job ID file:

```txt
/root/.hermes/cron/output/<job_id>/<YYYY-MM-DD_HH-MM-SS>.md
```

Use this path shape when verifying forced runs or inspecting latest output.

### Auditor pattern

A useful `no_agent` system auditor checks:

- `hermes cron status`
- recent `last_status` and `last_delivery_error` in `~/.hermes/cron/jobs.json`
- RAM/disk thresholds
- critical script existence
- repeated identical alert cooldown via a shared guard

Silent empty output means healthy.

## Verification sequence

After changes:

1. Run scripts directly.
2. `chmod +x` any cron scripts.
3. Create/update cron jobs.
4. Force-run key jobs with `cronjob action=run` or `hermes cron run`.
5. Wait for scheduler tick.
6. Confirm `last_status=ok` in cron list/jobs.json.
7. Inspect `/root/.hermes/cron/output/<job_id>/<timestamp>.md`.
8. Confirm `wakeAgent=false` skips the agent when appropriate.

## agentesPRO packaging note

The same class of pattern was packaged for agentesPRO as an installable Playbook at:

```txt
/root/memory-os/projects/agentespro/projects/playbooks/cheap-hermes-automation-pipelines/
```

When installing client automations, default to this pattern unless the client explicitly needs a model on every scheduled run.
