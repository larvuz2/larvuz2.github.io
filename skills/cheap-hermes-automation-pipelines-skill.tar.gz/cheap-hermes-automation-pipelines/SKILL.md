---
name: cheap-hermes-automation-pipelines
description: Design Hermes cron automations using no_agent, wakeAgent gates, and context_from so scheduled jobs stay cheap, quiet, and reliable.
version: 1.0.0
author: Larvuz
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [hermes, cron, automation, no_agent, wakeAgent, context_from, watchdogs]
---

# Cheap Hermes Automation Pipelines

## When to load

Load this skill when the user asks to create, audit, optimize, or troubleshoot Hermes cron jobs, scheduled automations, watchdogs, recurring briefings, collectors, alerts, pipelines, or anything involving `no_agent`, `wakeAgent`, `context_from`, or cost/noise reduction.

## Core principle

Keep the model out of the loop until intelligence is actually needed.

Preferred architecture:

```txt
Cheap sensors → wake gate → focused agent → Telegram/action
```

Avoid:

```txt
Full agent turn every few minutes just to discover nothing changed
```

## Pattern 1 — `no_agent`

Use when a script can fully decide the output.

Behavior:

| Script output | Result |
|---|---|
| empty stdout | silent tick |
| non-empty stdout | delivered verbatim |
| non-zero exit | Hermes sends error alert |

Best for:

- RAM/disk/process watchdogs
- API/site health checks
- CI/build pings
- heartbeat/sync/cleanup jobs
- deterministic publisher jobs

Create via tool or CLI:

```bash
hermes cron create "every 5m" --no-agent --script ram-watch.sh --deliver telegram
```

With the `cronjob` tool, set:

```json
{
  "no_agent": true,
  "script": "ram-watch.sh",
  "schedule": "every 5m"
}
```

## Pattern 2 — `wakeAgent` gate

Use when a cheap script should decide whether the model wakes.

The pre-run script prints JSON:

```json
{"wakeAgent": false}
```

or:

```json
{
  "wakeAgent": true,
  "context": {
    "change": "new actionable item"
  }
}
```

If false, Hermes skips the agent and spends zero model tokens for that tick. If true, Hermes wakes the agent with the context already injected.

Best for:

- new important email/thread
- new lead/opportunity
- new bug report
- file/database count changed
- external flag dropped
- Discord/Telegram/project event that needs triage

Rule: watch constantly, think rarely.

## Pattern 3 — `context_from`

Use to chain jobs without fragile model-managed file handoffs.

Architecture:

```txt
Job 1 — collector
- no_agent=True
- script=collect.py
- deliver=local

Job 2 — briefer
- context_from=<Job 1 ID>
- summarizes latest collector output
- deliver=telegram
```

`context_from` prepends the upstream job’s latest completed output to the downstream prompt at runtime. The model does not need to know paths or remember to read files.

## Audit checklist

For each cron job, ask:

1. Does this need a model every run?
2. Can a script decide “nothing to report”?
3. Can the job be split into collector + briefer/digest?
4. Can `context_from` replace manual file handoffs?
5. If the job is mirrored to a dashboard, does it have practical name/category metadata?
6. Is Telegram delivery only for human-useful output?
7. Are enabled toolsets minimal?
8. Does failure become loud with non-zero exit?
9. Is the prompt focused on one job, not broad exploration?

## Gus / Larvuz defaults

- Default to silence unless something matters.
- Use `no_agent` for watchdogs, heartbeats, syncs, deterministic cleanup/publish.
- Use `wakeAgent` for monitoring leads, inbox, project alerts, bug reports, and external changes.
- Use `context_from` for daily/weekly/monthly briefings that summarize collector output.
- Keep collector jobs local whenever possible.
- Keep model jobs lean and focused.
- For public/publishing jobs, preserve approval gates and privacy rules.

## Verification

After changing jobs:

```bash
hermes cron list
hermes cron status
hermes cron run <job_id>
```

Check:

- expected job is enabled
- next run time is sane
- silent ticks stay silent
- forced run returns expected output
- failure paths alert clearly

## Related human-readable note

Gus’s Obsidian note:

```txt
/root/obsidian-vaults/gus-garza/05 Workflows/Hermes Cheap Automation Pipelines.md
```

## Session implementation reference

Use `references/gus-larvuz-cron-optimization-2026-06.md` for a production-tested implementation pass covering:

- collector + `context_from` pipelines
- `wakeAgent` inbox gate verification
- deterministic `no_agent` reminders
- cron output path shape: `/root/.hermes/cron/output/<job_id>/<timestamp>.md`
- Cron Control Room auditor pattern
- agentesPRO Playbook packaging location

Use `references/obsidian-decision-review-crons-2026-06.md` for the paired collector/digest pattern used by Obsidian Drift Cleaner and Decision Debt Review, including collector signals, dashboard metadata, and first-run verification.
