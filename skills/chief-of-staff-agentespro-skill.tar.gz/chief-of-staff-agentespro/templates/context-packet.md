# Context Packet Template

Use this for every CONSULT or OWNED handoff. Keep it compact. Do not paste the whole session unless the receiving agent truly needs it.

```md
# Context Packet

## Route
DIRECT / CONSULT / OWNED

## Company
[company or agency name]

## Project / Client
[id + display name]

## Owner
[cto-agentespro / cmo-agentespro / mkt-agentespro / ops / creative / specialist]

## User Request
[exact ask or faithful summary]

## Current Session Context
[only the relevant context from this chat]

## Registry Entry
- registry: `[path/to/project_registry.yaml]`
- project_memory_path: `[path]`
- repo(s): `[paths]`
- URL(s): `[links]`
- asset path(s): `[paths]`

## Context To Read First
1. `[company memory doc]`
2. `[project/client PROJECT.md]`
3. `[project/client current-state.md]`
4. `[technical/brand/validation doc depending on lane]`

## Required Skills
- `[skill]`
- `[skill]`

## Rules / Constraints
- approval boundaries
- privacy boundaries
- brand/voice rules
- technical stack rules
- no-go zones

## Task
[what the receiving profile must do]

## Acceptance Criteria
- [specific condition]
- [specific condition]

## Validation Required
- tests / screenshots / logs / analytics / preview URL / approval artifact

## Return Format
- Result
- Artifacts / files changed
- Evidence
- Risk level: low / medium / high
- Blockers / decisions needed
- Recommended next action
```

## CTO variant

Add:

```md
## Technical Context
- repo:
- branch/base:
- stack:
- commands:
- test/build/deploy rules:

## CTO Decision
Should this be direct CTO work, Builder task, Reviewer pass, QA pass, DevOps pass, or Kanban workflow?
```

## CMO/MKT variant

Add:

```md
## Marketing Context
- audience:
- offer:
- channel:
- brand voice:
- existing assets:
- approval/publishing rules:

## CMO Decision
Should this be direct CMO work, Brand pass, Content pass, SEO pass, Social pass, Growth pass, Analytics pass, or Kanban workflow?
```

## Fresh review variant

For review/QA, include only:

```md
- original intent
- diff/artifact location
- acceptance criteria
- known risks
- validation command/URL
```

Do not ask the same agent that built the work to be the only reviewer for meaningful code/site changes.
