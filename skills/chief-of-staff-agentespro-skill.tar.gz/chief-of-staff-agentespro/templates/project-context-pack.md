# Project / Client Context Pack Template

Create one folder per meaningful project or client.

```txt
/memory-os/companies/<company-id>/projects/<project-id>/
# or for agencies:
/memory-os/companies/<company-id>/clients/<client-id>/
```

Minimum files:

```txt
PROJECT.md
current-state.md
repos.md
urls.md
rules.md
assets.md
validation.md
work-log/
```

Optional technical files:

```txt
architecture.md
known-issues.md
deploy.md
api.md
database.md
```

Optional marketing files:

```txt
brand.md
messaging.md
seo.md
campaigns.md
analytics.md
```

## PROJECT.md

```md
# [Project / Client Name]

## Status
emerging / active / paused / archived

## One-liner
[what this project/client is]

## Goals
- [goal]

## Owner / Department Fit
- primary_owner: CTO / CMO / Ops / Creative / Account Lead
- supporting_departments: []

## Key Context
[short durable context]

## Boundaries
- privacy:
- approval:
- brand:
- technical:

## First files to read
- current-state.md
- rules.md
- validation.md
```

## current-state.md

```md
# Current State

## Now
[what is true today]

## Open work
- [item]

## Known blockers
- [item]

## Last meaningful update
YYYY-MM-DD — [summary]
```

## repos.md

```md
# Repos / Local Paths

- name:
  local_path:
  github:
  branch:
  notes:
```

## urls.md

```md
# URLs

- production:
- staging:
- dashboard:
- docs:
```

## rules.md

```md
# Rules

## Approval boundaries
- [rule]

## Privacy boundaries
- [rule]

## Operating rules
- [rule]
```

## assets.md

```md
# Assets

- logos:
- brand files:
- screenshots:
- decks:
- media:
```

## validation.md

```md
# Validation

## For software
- tests:
- build:
- browser checks:
- deploy checks:

## For marketing
- brand check:
- claims check:
- approval check:
- analytics/UTM check:
```

## work-log/YYYY-MM-DD-task.md

```md
# Work Log — [Task]

## Owner
[profile/role]

## Request
[summary]

## Result
[what changed]

## Artifacts
[files, URLs, screenshots, PRs, assets]

## Verification
[real evidence]

## Durable update
[only if useful later]

## Open risks
[risks]
```
