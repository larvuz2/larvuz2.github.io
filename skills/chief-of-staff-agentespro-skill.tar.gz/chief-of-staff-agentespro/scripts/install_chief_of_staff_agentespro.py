#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

SKILL_NAME = "chief-of-staff-agentespro"
CATEGORY = "productivity"


def hermes_home() -> Path:
    return Path.home() / ".hermes"


def profile_root(name: str) -> Path:
    if name == "default":
        return hermes_home()
    return hermes_home() / "profiles" / name


def main() -> int:
    ap = argparse.ArgumentParser(description="Install Chief-of-Staff-agentesPRO router skill into a Hermes profile.")
    ap.add_argument("--target-profile", default="default", help="Hermes profile name, default: default")
    ap.add_argument("--dry-run", action="store_true", help="Print actions without writing files")
    args = ap.parse_args()

    script = Path(__file__).resolve()
    source_skill = script.parents[1]
    target = profile_root(args.target_profile) / "skills" / CATEGORY / SKILL_NAME

    print(f"source: {source_skill}")
    print(f"target: {target}")

    if args.dry_run:
        print("dry-run: no files written")
        return 0

    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        shutil.rmtree(target)
    shutil.copytree(source_skill, target)
    print(f"installed {SKILL_NAME} into profile {args.target_profile}")
    print("next: start a fresh Hermes session or run /reload-skills, then load chief-of-staff-agentespro")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
