#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
import tarfile
from datetime import datetime, timezone
from pathlib import Path

SKILL_NAME = "chief-of-staff-agentespro"
PUBLIC_BASE = "https://larvuz2.github.io/skills"


def build_reader(skill: Path) -> str:
    parts: list[str] = [
        "# Chief-of-Staff-agentesPRO — Portable Public Reader\n",
        f"Updated: {datetime.now(timezone.utc).isoformat()}\n",
    ]
    parts.append("## FIRST INSTRUCTION FOR ANY HERMES AGENT READING THIS\n\n")
    parts.append("If the user pasted this URL and asked to install the agentesPRO operating fabric/router, do **not** install this Markdown reader as the final skill. This reader is the bootstrap instruction file. Install the full package below because the router includes linked references and install tooling.\n\n")
    parts.append(f"Run this command now in the target Hermes environment:\n\n```bash\nset -euo pipefail\ncurl -fL {PUBLIC_BASE}/{SKILL_NAME}-skill.tar.gz -o /tmp/{SKILL_NAME}-skill.tar.gz\nrm -rf /tmp/{SKILL_NAME}\nmkdir -p /tmp/{SKILL_NAME}\ntar -xzf /tmp/{SKILL_NAME}-skill.tar.gz -C /tmp/{SKILL_NAME}\npython3 /tmp/{SKILL_NAME}/{SKILL_NAME}/scripts/install_chief_of_staff_agentespro.py --target-profile default\n```\n\n")
    parts.append("After install, start a fresh Hermes session or run `/reload-skills`, then load/use `chief-of-staff-agentespro`.\n\n")
    parts.append(f"## Simple user instruction\n\nPaste only this URL into another Hermes agent and say: `install this agentesPRO operating router`.\n\n```txt\n{PUBLIC_BASE}/{SKILL_NAME}.md\n```\n\n")
    parts.append("## Core rule\n\nChief-of-Staff-agentesPRO is the thin routing layer above CTO-agentespro and MKT/CMO-agentespro. For company software/site changes, involve CTO by default; for landing/copy/conversion, involve CMO/MKT by default; keep speed with parallel fast team passes.\n\n")
    parts.append(f"## Full package URL\n\n```txt\n{PUBLIC_BASE}/{SKILL_NAME}-skill.tar.gz\n```\n")
    parts.append("\n---\n\n")

    paths = [skill / "SKILL.md"]
    for sub in ["references", "templates", "scripts"]:
        d = skill / sub
        if d.exists():
            paths.extend(sorted(d.glob("*")))
    for p in paths:
        if not p.is_file() or p.name.endswith(".pyc") or "__pycache__" in p.parts:
            continue
        rel = p.relative_to(skill)
        txt = p.read_text(errors="ignore")
        lang = "markdown" if p.suffix == ".md" else "python" if p.suffix == ".py" else "text"
        parts.append(f"# File: `{rel}`\n\n```{lang}\n{txt}\n```\n\n---\n\n")
    return "\n".join(parts)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=None)
    ap.add_argument("--publish-dir", default=None)
    args = ap.parse_args()

    script = Path(__file__).resolve()
    skill = script.parents[1]
    repo = Path(args.repo).expanduser().resolve() if args.repo else script.parents[3]
    dist = repo / "dist"
    dist.mkdir(parents=True, exist_ok=True)
    tar_path = dist / f"{SKILL_NAME}-skill.tar.gz"
    reader_path = dist / f"{SKILL_NAME}.md"

    if tar_path.exists():
        tar_path.unlink()
    with tarfile.open(tar_path, "w:gz") as tf:
        tf.add(skill, arcname=SKILL_NAME, filter=lambda info: None if "__pycache__" in info.name or info.name.endswith(".pyc") else info)
    reader_path.write_text(build_reader(skill), encoding="utf-8")
    print(f"built: {tar_path} ({tar_path.stat().st_size} bytes)")
    print(f"built: {reader_path} ({reader_path.stat().st_size} bytes)")

    if args.publish_dir:
        publish = Path(args.publish_dir).expanduser().resolve()
        publish.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(tar_path, publish / tar_path.name)
        shutil.copyfile(reader_path, publish / reader_path.name)
        print(f"published artifacts to: {publish}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
