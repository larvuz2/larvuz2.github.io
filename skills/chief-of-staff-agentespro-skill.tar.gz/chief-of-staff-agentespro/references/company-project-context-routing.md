# Company / Project Context Routing Pattern

Session-derived operating pattern for multi-agent company harnesses where one company or agency has many projects or clients.

## Core principle

Use **shared role agents** and **project/client context packs**.

```txt
Role agent = how to think / execute
Project or client pack = what context to use
Context packet = what to do now
```

Do **not** create a CTO/CMO per project by default. Create project-specific agents only when the project needs a different behavior/mode of thinking, not merely different context.

## Recommended architecture

```txt
Company / Agency OS
├─ Shared executives
│  ├─ Chief of Staff / Larvuz router
│  ├─ CTO
│  ├─ CMO / MKT
│  ├─ Ops
│  └─ Creative Director / Producer when relevant
├─ Shared specialists
│  ├─ Builder / Reviewer / QA / DevOps
│  ├─ SEO / Social / Content / Analytics
│  └─ Design / Video / Prompt / Research specialists
└─ Project or client context packs
   ├─ client-a or project-a
   ├─ client-b or project-b
   └─ client-c or project-c
```

For a marketing agency with 10 clients: use one shared CMO, one shared CTO, shared specialists, and 10 isolated client context packs. Do not create 10 CMOs and 10 CTOs unless a client is large enough to justify a dedicated role.

For Larvuz/Gus: use shared executives across Capyverse, Merry, agentesPRO, Slopia, audio-reactive systems, etc., plus project-specific leads only where the mode is genuinely different (e.g. `capyverse-game-director`, `merry-film-producer`).

## Project/client registry

Maintain a canonical registry per company:

```txt
/root/memory-os/companies/<company-id>/project_registry.yaml
# or current internal pattern:
/root/memory-os/projects/<company-id>/project_registry.yaml
```

Each project/client record should include:

```yaml
id:
name:
type: project | client | internal_system | campaign
status: emerging | active | paused | archived
owner:
repo:
urls:
memory_path:
primary_skills:
departments:
keywords:
approval_rules:
validation:
assets:
```

New projects can appear during normal conversation. Add a lightweight `status: emerging` entry only when the mention has durable value.

## When to create a new project/client context pack

Create one when at least one is true:

- recurring name or ongoing initiative
- repo/path/URL/assets/logo exist
- client/business context needs isolation
- future tasks are likely
- brand/goals/context/work log are worth preserving

Do **not** create a project pack for every random idea, one-off copy tweak, or tiny mention.

## Context pack shape

```txt
memory-os/.../<project-id>/
  PROJECT.md
  current-state.md
  repos.md
  urls.md
  rules.md
  assets.md
  validation.md
  work-log/
```

Technical projects may add:

```txt
architecture.md
known-issues.md
deploy.md
```

Marketing/client projects may add:

```txt
brand.md
messaging.md
seo.md
pages.md
stakeholders.md
```

## Conservative routing rule

Default: **Larvuz handles directly**.

Use only three routing modes:

```txt
DIRECT  -> Larvuz answers or uses tools directly.
CONSULT -> Larvuz asks a role agent for perspective, then owns final answer.
OWNED   -> CTO/CMO/Ops/etc. owns execution with a context packet.
```

Delegate only if at least 2 of 6 are true:

1. 3+ meaningful steps.
2. Changes code, files, website, database, deployment, or public assets.
3. Needs CTO/CMO/domain ownership beyond Larvuz’s normal answer.
4. Needs verification evidence: tests, screenshots, logs, analytics, deploy URL.
5. Continues beyond this chat turn.
6. Mistake has real cost: broken app, bad public asset, client risk, lost lead, production risk.

Anti-bureaucracy: never route a simple writing/taste/thinking task unless the next agent can produce a concrete artifact, decision, or evidence that justifies the overhead.

## Project detection order

Before routing, identify the project/client context from:

1. explicit user mention
2. current Telegram topic/thread/project channel
3. recent session context
4. known repo/path/URL in request
5. keyword map from registry
6. ask only if ambiguity blocks execution

## Context packet requirements

Every `CONSULT` or `OWNED` task should include a compact packet:

```md
# Context Packet

## Company

## Project / Client

## Route
DIRECT / CONSULT / OWNED

## Owner
CTO / CMO / Ops / Specialist

## User Request

## Current Session Context

## Project Context
- memory_path:
- repo:
- urls:
- assets:
- current_state:
- known_issues:

## Required Skills

## Rules / Constraints

## Acceptance Criteria

## Validation Required

## Return Format
- result / decision
- artifacts or files changed
- evidence
- risks
- blockers
- next action
```

This packet lets the same CTO/CMO operate inside totally different project/client contexts without cloning agents or dumping the entire raw session.

## When to create project-specific agents

Default: do not.

Create a project-specific agent only when one is true:

- unique domain/mode of thinking: game director, film producer, AI video pipeline lead
- constant long-term work with heavy accumulated context
- unique approval/privacy boundaries require hard isolation
- unique voice/taste is so central that a stable specialist is useful

Even then, prefer project-specific **lead/specialist** agents over cloned CTO/CMO profiles.
