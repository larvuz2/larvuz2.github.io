# agentesPRO Memory OS / Client Memory Pack

Session-derived operating pattern for agentesPRO memory architecture.

## Decision

Do not default to Hindsight or Docker for client deployments.

Default memory stack:

```txt
Hermes built-in memory + skills + session_search
Obsidian / Markdown source of truth
Graphify only when useful
Hindsight only for Enterprise / explicit memory-API need
```

Framing:

```txt
Hermes is the brain.
Obsidian/Markdown is the library.
Graphify is the optional map.
Hindsight is Enterprise-only.
agentesPRO is the interface.
```

## Deployment tiers

### Starter

Use for most clients.

- Hermes profile memory
- Hermes skills
- session_search for past conversation recall
- Markdown knowledge pack
- no Docker
- no Hindsight
- no Graphify unless complexity demands it

### Pro

Use when the client has many docs/pages/workflows/agents.

- Starter stack
- Graphify project/document map
- healthcheck/update scripts

### Enterprise

Use only when a real memory infrastructure requirement exists.

- Pro stack
- optional Hindsight or external memory API
- requires explicit infrastructure decision, backup plan, retention policy, and per-client isolation

## Recommended filesystem shape

```txt
/vps-root
  /project
  /memory
    memory-manifest.yaml
    /knowledge
      company.md
      services.md
      faqs.md
      policies.md
      workflows.md
      agents.md
      escalation.md
    /graphify                 # optional Pro only
      /corpus
      /output
  /agents
  /scripts
    memory-healthcheck.sh
    update-graph.sh           # optional Pro only
    backup-memory.sh
  /logs
```

## Retrieval order

```txt
Hermes memory/skills -> session_search when needed -> Markdown/Obsidian source -> Graphify when available -> live files -> act -> verify -> save durable reusable lessons only
```

## Conflict rules

1. Live files win for implementation state.
2. Markdown/Obsidian wins for official company/client knowledge.
3. Hermes memory wins for compact durable preferences and behavior rules.
4. Hermes skills win for reusable procedures.
5. session_search wins for reconstructing old conversations.
6. Graphify wins for structural relationships.
7. Hindsight only wins if explicitly deployed as Enterprise behavioral memory.

## Implementation commands from the session

Internal Memory OS root:

```txt
/root/memory-os
```

Client pack generator:

```bash
/root/memory-os/scripts/init_client_memory_pack.py <client-slug> <output-dir> "Client Name"
```

Internal healthcheck:

```bash
/root/memory-os/scripts/memory_healthcheck.py
```

Graphify rebuild:

```bash
/root/memory-os/scripts/run_graphify_project.sh agentespro
```

Hindsight deploy scripts should guard execution behind explicit approval, e.g. `HINDSIGHT_ENTERPRISE_APPROVED=true`, and should not run for standard clientes.
