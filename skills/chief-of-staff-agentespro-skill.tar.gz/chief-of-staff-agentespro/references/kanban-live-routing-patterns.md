# Kanban live routing patterns for agentesPRO

Use this when Gus wants to see agentesPRO profiles work through Hermes Kanban in real time.

## Recommended flow

1. Classify the request first:
   - direct answer
   - CTO lane
   - CMO/MKT lane
   - cross-functional
2. Create or switch to a dedicated board for the test/project.
3. Create small cards assigned to the actual owner profiles.
4. Dispatch one or a few cards intentionally, then show the board state.
5. Wait/poll until cards complete or block.
6. If a card blocks for review but the work is verified and safe, add a review comment and complete/unblock only when no approval boundary is being crossed.
7. Run final board stats and file/output checks before reporting success.

## Cross-functional pattern

For website/content requests like “add a blog page with SEO posts”:

- MKT/CMO card: content, SEO titles, slugs, metadata, article bodies.
- Builder/CTO card: implement page, navigation, SEO markup, structured data.
- QA card: verify links, browser behavior, console, mobile, and SEO tags.

Keep production deploy as a separate human-approved card.

## Kanban pitfall: forced cross-profile skills

Do **not** force-load a skill from another profile into a worker unless you have verified that skill is available in that worker profile.

Example pitfall:

```bash
hermes kanban create ... --assignee cto-agentespro --skill cto-agentespro --skill mkt-agentespro
```

This can fail if `mkt-agentespro` is not installed/visible inside the `cto-agentespro` profile.

Safer pattern:

- Assign the marketing/content card to `mkt-agentespro` and let that profile load its own umbrella skill.
- Assign the implementation card to `builder-agentespro` / `cto-agentespro` and let that profile load its own software skill.
- Pass artifacts through files, comments, card summaries, or dependencies instead of cross-loading skills.

## Superseded card cleanup

If early test cards were created with bad assumptions:

1. Reclaim running stale/duplicate card if needed.
2. Block it with a clear reason: `Superseded by corrected card <id>`.
3. Create corrected cards without the bad setup.
4. Link downstream QA to the corrected implementation card.
5. Confirm final board has no accidental running/ready duplicates before reporting.

## Final reporting format

```txt
Route: cross-functional / CTO / CMO / direct
Board: <board-slug>
Done cards:
- <id> <profile> <title>
Files changed:
- <path>
Verification:
- <real check output>
Approval boundary:
- no deploy / needs approval / approved by Gus
```
