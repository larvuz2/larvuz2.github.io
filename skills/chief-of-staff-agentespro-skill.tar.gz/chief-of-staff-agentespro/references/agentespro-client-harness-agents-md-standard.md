# agentesPRO client harness / AGENTS.md standard

Session learning from applying the Learn Harness Engineering framing to agentesPRO client installs.

## Core principle

For client installs, `AGENTS.md` is not just a prompt. It is the agent's entry file into the project harness: the shortest path from a fresh session to safe, verified execution.

Strong models still fail when the repo does not tell them:

- what the project is
- where durable context lives
- how to install/run/test
- what files are protected
- what approval boundaries exist
- what counts as done
- where current progress is recorded

## agentesPRO client-install standard

When Gus asks to install or design an agentesPRO harness for a client, treat the deliverable as a full operating harness, not just agent profiles.

Minimum package:

```txt
client harness
├─ AGENTS.md                 # fresh-agent operating map
├─ README.md                 # product/client overview
├─ harness.yaml or client.yaml
├─ docs/state/
│  ├─ current.md
│  ├─ progress.md
│  ├─ decisions.md
│  └─ known-issues.md
├─ memory-pack/
│  ├─ company.md
│  ├─ goals.md
│  ├─ products.md
│  ├─ services.md
│  ├─ workflows.md
│  ├─ approval-rules.md
│  ├─ secrets-policy.md
│  └─ handoff.md
├─ connector/
│  ├─ project_registry.json
│  ├─ env.example
│  └─ cron.example.yaml
└─ profiles/
   ├─ client-<slug>-chief
   ├─ client-<slug>-cto
   ├─ client-<slug>-builder
   ├─ client-<slug>-reviewer
   ├─ client-<slug>-qa
   ├─ client-<slug>-devops
   ├─ client-<slug>-cmo
   ├─ client-<slug>-marketing
   └─ client-<slug>-ops
```

## Root AGENTS.md contents

Use a short operational file. Do not turn it into a giant README.

Recommended sections:

1. Project identity: name, owner, URLs, purpose.
2. What this system does.
3. Read-first order.
4. Repo map.
5. Stack.
6. Commands: install, dev, build, lint, typecheck, test, full check.
7. Working rules.
8. Protected files.
9. Environment and secrets policy.
10. QA / verification.
11. Definition of Done.
12. Long-running task handoff.
13. Human approval boundaries.

## Definition of Done pattern

A task is done only when:

1. Requested behavior is implemented or the plan is complete, depending on the ask.
2. Relevant checks were run, or unavailable checks are explicitly named as unavailable.
3. Changed route/API/workflow was exercised when implementation happened.
4. Docs were updated if structure, workflow, schema, or auth rules changed.
5. No unrelated files changed.
6. Handoff includes changed files, commands run, results, risks, and next exact step.

Do not invent missing test/build success. If a command does not exist, say so.

## Fresh-agent test

After creating or reviewing a harness, test mentally or with a fresh session whether a new agent can answer from repo files alone:

- What is this system?
- What repos/services exist?
- How do I run it?
- How do I verify work?
- What is in progress?
- What needs human approval?
- How do I emit safe Mission Control activity?
- What should never be exposed?

If the answer requires chat history, the harness is incomplete.

## agentesPRO-specific pitfall

Do not clone Gus/Larvuz's full internal SOUL or personal memory into client agents. Client installs need sanitized, client-scoped role identity + company memory pack + approval rules + repo AGENTS.md + connector config. Keep Gus's private universe separate.

## Recommended sequence for agentesPRO itself

Use agentesPRO as the reference implementation before selling the pattern:

1. Add/upgrade `/root/agentesprolrvz/AGENTS.md`.
2. Add `/root/agentesprolrvz/docs/state/*`.
3. Add/upgrade `/root/agentespro-connector/AGENTS.md` and README.
4. Add connector `.env.example`, schemas, healthcheck, and smoke tests.
5. Create reusable `agentespro-client-harness/` templates.
6. Generate client-scoped profiles from templates.

## Planning-only requests

If Gus says "plan first" or "no implementation yet," inspect and evaluate, but do not write files. Return diagnosis, gaps, target structure, and phased implementation plan.