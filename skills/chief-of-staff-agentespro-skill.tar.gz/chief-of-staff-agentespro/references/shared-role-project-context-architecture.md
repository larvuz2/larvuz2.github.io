# Shared Role Agents + Project Context Architecture

Use this as the agentesPRO / Larvuz / client-company harness source of truth for clean multi-agent routing.

## First-principles rule

```txt
Agents are roles. Projects are memory.
```

Do not create a CTO/CMO clone per project or per client by default. Use shared executive role agents and summon them into a project/client context pack.

```txt
Company OS
├─ Shared role agents: Chief of Staff, CTO, CMO/MKT, Ops, Creative Director
├─ Shared specialists: Builder, Reviewer, QA, DevOps, Brand, Content, SEO, Social, Growth, Analytics
└─ Project/client context packs: goals, brand, repos, URLs, assets, rules, current state, work log
```

## Default architecture

```txt
Gus / client user
↓
Chief of Staff / front-door router
↓
Company context
↓
Project/client registry lookup
↓
Context packet
↓
Shared department owner: CTO / CMO / Ops / Creative
↓
Specialists only when useful
↓
Result + evidence + work-log update
```

## Routing modes

Keep only three modes:

1. **DIRECT** — front-door agent handles it.
2. **CONSULT** — front-door agent asks one executive/specialist for perspective, then synthesizes.
3. **OWNED** — a department profile owns execution and validation from a context packet.

Default is **DIRECT**.

## Conservative delegation test

Delegate only when at least **2 of 6** are true:

1. The task has 3+ meaningful steps.
2. It changes code, files, website, database, deployment, public assets, or client deliverables.
3. It needs CTO/CMO/domain ownership beyond normal Larvuz judgment.
4. It requires verification evidence: tests, screenshots, logs, analytics, deploy URL, approval artifact.
5. It will continue beyond the current chat turn.
6. A mistake has real cost: broken app, bad public asset, client-facing error, lost lead, production/security/privacy risk.

If only 0–1 are true, answer directly.

## Project/client detection

Before routing an OWNED task, identify context:

1. Explicit user mention.
2. Current chat/topic/session context.
3. Known repo/path/URL/asset mentioned.
4. Keyword map in `project_registry.yaml`.
5. Recent work log/session_search if needed.
6. Ask only if ambiguity blocks execution.

## Emerging project rule

Projects/clients appear naturally in conversation. Do not create a project for every random idea.

Create an **emerging** project/client context only when at least one is true:

- recurring name or named client/company
- repo/path/URL/domain/asset folder exists
- work likely continues beyond one turn
- brand/goals/team/rules are worth preserving
- it will need CTO/CMO/specialists later

Use status: `emerging` until it has enough context to become `active`.

## When to create project-specific agents

Default: do not.

Create a dedicated project agent only if the project needs a different durable role or mode of thinking, not just different context.

Good dedicated agents:

- `capyverse-game-director`
- `merry-film-producer`
- `client-x-account-lead` for a large retainer/client
- `ai-video-pipeline-lead`

Bad default pattern:

- `cto-client-a`, `cto-client-b`, `cto-client-c`
- `cmo-project-a`, `cmo-project-b`

## Privacy/isolation rule for client VPS installs

On a client/company VPS, all memory and projects are isolated to that company. For agencies with many clients, use one agency company OS with per-client context packs unless legal/privacy requirements demand a separate VPS/profile per client.

Never leak Client A context into Client B context packets.

## Context hierarchy

```txt
Company memory = global operating truth
Project/client pack = local context and current state
Role skill = how the agent works
Context packet = what to do now
Work log = what happened and what matters later
```

## Anti-bureaucracy rules

- Never create a team workflow for a thinking task.
- Never wake CTO/CMO for simple rewrite/prompt/taste tasks.
- Never delegate unless the receiving agent can produce a concrete artifact, decision, or evidence.
- Never dump all session history into a worker. Send a compact context packet.
- Do not treat project creation as ceremony; create only enough context to preserve future work.

## Minimum implementation pieces

A reusable client/company install should include:

1. `project_registry.yaml`
2. project/client context pack template
3. context packet template
4. conservative routing contract
5. shared role-agent roster
6. approval boundaries
7. work-log template
8. smoke-test prompts
