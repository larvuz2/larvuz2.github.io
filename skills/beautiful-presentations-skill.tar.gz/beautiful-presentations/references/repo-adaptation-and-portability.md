# Repo Adaptation + Portable Skill Pattern

Use when the user points to a design-inspiration repo and asks to implement the same objective in the Hermes ecosystem, without depending on the original agent/model/tooling.

## Core lesson

Do not copy the repo superficially. First identify the repo's real design and workflow primitives, then re-express them as a Hermes-native class-level skill that any profile/model can run.

For presentation repos such as `frontend-slides` / `beautiful-html-templates`, the durable value is usually:

- one-file HTML artifacts for browser-first review
- strong template/source inspection before generation
- reusable visual systems, not demo content
- export paths for PDF and video after HTML approval
- quality QA before delivery
- preview URL delivery instead of raw HTML attachment

## Required sequence

1. Inspect the actual repo or imported template folder.
2. Read the source files that define the design system, especially `template.html`, `design.md`, `template.json`, screenshots, CSS, and JS.
3. Extract reusable primitives:
   - layout archetypes
   - typography scale
   - color system
   - motifs
   - animation language
   - export mechanics
   - QA checks
4. Translate those primitives into Hermes-native workflow:
   - normal file/terminal/browser tools
   - no Claude-only artifact assumptions
   - no provider-specific phrasing unless the user explicitly asks
   - works on any model/profile/VPS with the skill installed
5. Generate a self-contained HTML deck first.
6. Publish a preview URL for review.
7. Export PDF/video only when requested or after approval.
8. Verify before final delivery.

## Portability requirements

A portable deck skill should include:

- rich `SKILL.md` with triggers, workflow, non-negotiables, QA, and final response format
- `templates/` for copy-modify starter HTML
- `references/` for design analyses, repo notes, export notes, and pitfalls
- `scripts/` for deterministic helpers like HTML QA, PDF export, video export, preview publishing

Avoid embedding environment-specific paths as hard requirements. Use them only as examples. Prefer env vars for VPS preview configuration:

```bash
HERMES_PRESENTATION_PREVIEW_ROOT=/var/www/presentations
HERMES_PRESENTATION_PREVIEW_BASE_URL=https://preview.example.com
```

## Pitfalls

- Do not deliver a raw HTML attachment by default. It is bad for chat/client review. Send a URL.
- Do not say the deck matches an inspiration repo unless the actual source/template was inspected.
- Do not clone demo content. Reuse structure and art direction.
- Do not make a generic SaaS deck with the repo's palette pasted on top.
- Do not rely on Claude artifacts, hosted previews, or special slash commands.
- Do not export PDF/video before the HTML review path is established unless the user asked directly.

## Final test for portability

A different Hermes agent on another VPS should be able to paste/install the skill, read the linked files, create a one-file HTML deck, publish a preview URL if configured, and optionally export 16:9 PDF/video without needing the original conversation context.
