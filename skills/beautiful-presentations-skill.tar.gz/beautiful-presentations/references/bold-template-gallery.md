# Bold Template Gallery

Imported design gallery from `zarazhangrui/frontend-slides` (MIT). Use this as a style-selection library when users ask for templates, examples, moods, or a bold template gallery.

Source assets live under `gallery/frontend-slides-bold/bold-template-pack/`.

## Usage

1. Show 3–6 style options by name and mood when the user asks for styles/templates.
2. If the user picks one, inspect that template folder / design notes before generating the final HTML deck.
3. Reuse the visual principles, layout language, colors, and CSS patterns. Do not blindly copy demo content.
4. Keep our non-negotiables: one-file HTML, 1920×1080 fixed stage, browser-first review, PDF/video only on request.

## Templates

### 8-Bit Orbit (`8-bit-orbit`)

- Tagline: Pixel-art neon arcade aesthetic on a deep navy void.
- Mood: retro-tech, playful, cyberpunk, energetic
- Tone: geeky, neon, rebellious, sci-fi
- Scheme: dark
- Density: medium
- Best for: Anything that should feel like a CRT screen at 2am: cyberpunk, gaming, web3, indie dev tools, hackathon demos. Just as good for a tech talk that wants to lean into nostalgic-digital craft, a synthwave brand deck, or a creative review that wants to feel like a console.
- Avoid for: Contexts where the dark neon palette would actively work against the message — quiet institutional finance disclosures, healthcare patient-facing materials, traditional luxury.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/8-bit-orbit`

### Biennale Yellow (`biennale-yellow`)

- Tagline: Solar yellow on warm parchment with deep indigo serif and atmospheric sun-glow gradients.
- Mood: editorial, atmospheric, warm, cultural-institution, poster-like
- Tone: literary, considered, contemplative, warm-modern, Dutch-editorial
- Scheme: light
- Density: medium
- Best for: Anything that should feel like an art-biennale poster or a museum's annual programme: exhibition decks, arts-institution announcements, design conference brochures, curatorial pitches, literary publications, studio retrospectives. Equally good for any deck wanting Dutch-editorial atmosphere with an unmistakable single-color signature.
- Avoid for: Decks that need visual punch or saturated multi-color energy — the warm-paper canvas and one-yellow palette are intentionally quiet and atmospheric.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/biennale-yellow`

### BlockFrame (`block-frame`)

- Tagline: Neobrutalist deck with pastel-neon color blocks and chunky black borders.
- Mood: bold, playful, graphic, fresh
- Tone: confident, graphic, pop, design-led
- Scheme: light
- Density: high
- Best for: Anything that should feel pop-graphic and design-led: indie SaaS launches, agency credentials, creative reviews, brand redesigns. Also a strong unexpected pick for tech, finance, or research when the speaker wants to land as confident and contemporary rather than buttoned-up.
- Avoid for: Contexts that require quiet institutional restraint or traditional weight (regulated disclosures, formal legal briefs).
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/block-frame`

### Blue Professional (`blue-professional`)

- Tagline: Cream paper background with electric cobalt blue accents; clean modern professional.
- Mood: professional, modern, calm, trustworthy
- Tone: clean, considered, polished, neutral
- Scheme: light
- Density: medium
- Best for: Anything that should feel modern-considered and lightly authoritative: B2B SaaS pitches, consulting deliverables, advisory updates, investor reports. Also a clean, tasteful choice whenever you want to read as professional without going stiff — research synthesis, internal reviews, brand work for service businesses.
- Avoid for: Contexts where the deck should feel hot, playful, or intentionally informal — the cool electric-blue restraint will read as overly polished.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/blue-professional`

### Bold Poster (`bold-poster`)

- Tagline: Editorial poster aesthetic with massive Shrikhand display and a single fire-engine red accent.
- Mood: bold, editorial, loud, confident
- Tone: dramatic, graphic, sharp, intentional
- Scheme: light
- Density: low
- Best for: Anything that should land like a magazine cover: brand manifestos, founder vision decks, editorial / cultural pitches, creative reviews. Excellent any time you want a few words to feel like a poster — including unexpected fits like a tech keynote or a finance manifesto that wants to be quotable.
- Avoid for: Decks that need to communicate dense information per slide — the layout is built around a few large statements, not paragraphs of detail.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/bold-poster`

### Broadside (`broadside`)

- Tagline: Dark editorial canvas with a single fire orange accent and bilingual Latin/Chinese type stack.
- Mood: editorial, dramatic, loud, newspaper
- Tone: graphic, punchy, literary, considered
- Scheme: dark
- Density: medium
- Best for: Anything that should land like a broadside newspaper headline: brand manifestos, magazine and cultural pitches, design talks, bilingual EN/CN decks, founder vision statements. Also a striking pick for tech, research, or business decks that want a dramatic single-accent editorial feel.
- Avoid for: Decks that need to feel quiet, warm, or institutionally traditional — the dark canvas with fire-orange accent commits to drama.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/broadside`

### Capsule (`capsule`)

- Tagline: Modular pill-shaped cards on warm bone with a full pastel-pop palette.
- Mood: playful, modern, warm, fresh, fun
- Tone: upbeat, graphic, approachable, cool
- Scheme: light
- Density: medium
- Best for: Anything that should feel modular, modern, and a little Y2K: lifestyle brands, creator portfolios, DTC launches, beauty / wellness, agency credentials. Also fun for a playful tech demo or a research deck that wants pop-art clarity instead of gravitas.
- Avoid for: Contexts that require traditional institutional weight — the capsule shapes and pastel pops actively soften authority.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/capsule`

### Cartesian (`cartesian`)

- Tagline: Quiet warm-neutral palette with classical Playfair serifs; tasteful and unhurried.
- Mood: quiet, considered, elegant, warm-minimal
- Tone: classical, literary, restrained, confident-quiet
- Scheme: light
- Density: low
- Best for: Anything that should feel quiet, considered, and grown-up: investment theses, white papers, advisory work, longform research, gallery / cultural decks. Also a strong choice for editorial features, founder reflections, or any deck where restraint is the message — including across tech and finance.
- Avoid for: Decks that need visual heat, multiple accents, or a sense of urgency — the warm-neutral palette is intentionally low-energy.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/cartesian`

### Cobalt Grid (`cobalt-grid`)

- Tagline: Electric cobalt serifs on a graph-paper canvas, anchored by stair-stepped pixel-glitch decorations and slim hairline rules.
- Mood: editorial, design-research, studious, modernist, tech-print, monochrome
- Tone: considered, literary, studious, quietly-modern, editorial
- Scheme: light
- Density: medium
- Best for: Anything that should feel like a quietly serious design / research bulletin, art publication, or curated trend report. Strong for studio annuals, agency capabilities decks, design-research publications, architecture / art / academic decks, and any deck wanting one strict accent colour and a printed-ledger calmness rather than corporate polish.
- Avoid for: Decks that need warmth, multi-colour energy, or a casual / playful voice — the strict cobalt + cream + grid palette is intentionally austere.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/cobalt-grid`

### Coral (`coral`)

- Tagline: Cream and coral on near-black, set in oversized Bebas Neue.
- Mood: bold, warm, modern, confident
- Tone: graphic, punchy, magazine
- Scheme: mixed
- Density: medium
- Best for: Anything that should feel warm-graphic and editorial: fashion, beauty, fitness, F&B, lifestyle brands, agency credentials. Just as strong for a creator portfolio, a manifesto, or a tech / research deck that wants warmth and a single bold accent instead of corporate cool.
- Avoid for: Contexts that should feel quiet or institutional — the coral accent and oversized Bebas Neue commit hard to a confident magazine voice.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/coral`

### Creative Mode (`creative-mode`)

- Tagline: Cream paper canvas with confident multi-color (green, pink, orange, yellow) accents and Archivo Black display.
- Mood: creative, confident, playful, design-led
- Tone: graphic, expressive, modern
- Scheme: light
- Density: medium-high
- Best for: Anything that should feel design-led and confident: creative agency pitches, design studio decks, ad shop credentials, brand creative reviews, art-direction reviews. Also a great unexpected pick for a tech talk, research findings, or finance review when the speaker wants to lead with taste rather than convention.
- Avoid for: Contexts that demand institutional restraint and a quiet authority — the saturated multi-accent palette will read as expressive, not formal.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/creative-mode`

### Daisy Days (`daisy-days`)

- Tagline: Cheerful pastel deck with hand-drawn daisies, stars, and rainbows. Friendly, soft, and warm.
- Mood: cheerful, playful, warm, sunny, wholesome
- Tone: friendly, soft, encouraging, approachable, lighthearted
- Scheme: light
- Density: medium
- Best for: Anything that should feel friendly, soft, and joyful: educational content, kids and family, wellness programs, community workshops, creator portfolios for craft / illustration. Also lovely for an unexpected playful internal kickoff, a wedding planning deck, or any moment where warmth is the message — including across tech or business contexts.
- Avoid for: Contexts where the audience explicitly expects authority and precision — the hand-drawn pastel SVG decorations are the opposite of buttoned-up.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/daisy-days`

### Editorial Forest (`editorial-forest`)

- Tagline: Forest green, dusty pink, and warm cream meet Source Serif 4 in a quiet, intentional quarterly-review deck.
- Mood: editorial, quiet, considered, warm, intentional
- Tone: literary, thoughtful, warm, low-pressure
- Scheme: mixed
- Density: medium
- Best for: Anything that should feel like a considered editorial — quarterly reviews, internal readouts, studio updates, creative-agency presentations. Equally good for any deck that wants to feel warm and unhurried rather than corporate, including research recaps, book or program announcements, and team retrospectives.
- Avoid for: Contexts that need to feel urgent, punchy, or sales-driven — the palette and rhythm are intentionally quiet.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/editorial-forest`

### Editorial Tri-Tone (`editorial-tri-tone`)

- Tagline: Three-color editorial system: dusty pink, mustard cream, and deep burgundy, set in Bricolage + Instrument Serif.
- Mood: editorial, warm, intentional, moody
- Tone: literary, warm, considered, stylish
- Scheme: mixed
- Density: medium
- Best for: Anything that should feel like a fashion-magazine spread: editorial pitches, fashion brand decks, lifestyle media, art direction reviews. Equally good for any deck — including tech, research, or business — that wants tri-tone discipline and serif/sans contrast instead of the usual neutrals.
- Avoid for: Decks that need to read as soft or comforting — the burgundy/pink/cream tri-tone is intentionally high-contrast and styled.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/editorial-tri-tone`

### Emerald Editorial (`emerald-editorial`)

- Tagline: A magazine-cover business deck: emerald + navy + paper, double-rule masthead ornaments, and a bold Bodoni-style display serif.
- Mood: editorial, considered, confident, magazine-cover
- Tone: literary, authoritative, warm, designed
- Scheme: mixed
- Density: medium
- Best for: Anything that should feel like the front of a serious magazine, including but not limited to leadership readouts, planning-office reviews, and strategy briefings. The double-rule masthead ornament gives it editorial gravitas without making it stiff — also a great unexpected pick for product launches or research recaps that want to feel considered rather than corporate.
- Avoid for: Contexts that need to read as quiet, neutral, or institutionally restrained — the emerald field is too saturated to disappear into the background.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/emerald-editorial`

### Grove (`grove`)

- Tagline: Forest-green canvas with cream type, classical Playfair serifs, and a single rust accent.
- Mood: organic, considered, warm, literary, natural
- Tone: classical, warm, considered, patient
- Scheme: mixed
- Density: medium
- Best for: Anything that should feel organic, considered, and grown-up: sustainability and wellness brands, outdoor / nature products, wineries and restaurants, literary or arts decks, advisory deliverables, bilingual EN/CN reports. Also a calm, distinctive choice for tech, research, or business decks that want patience over urgency.
- Avoid for: Decks that need neon energy or rapid-fire pop — the forest-green canvas and Playfair serif commit to a slow, classical voice.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/grove`

### Long Table (`long-table`)

- Tagline: Warm cream and rust-red supper-club aesthetic with bold uppercase grotesk headlines, Fraunces serifs, and pill-shaped outlined buttons.
- Mood: warm, intimate, modern, friendly, small-batch, social, hospitality
- Tone: warm, playful, considered, social, magazine-friendly, modern-editorial
- Scheme: light
- Density: medium
- Best for: Anything that should feel like a warm, intimate, modern hospitality / community brand: supper clubs, dinner series, small restaurants, creative-studio events, membership pitches, lifestyle and wine brands. Equally good for any deck wanting a single warm accent colour, mixed-weight typography, and a social-media-aware modern-editorial voice.
- Avoid for: Decks that need corporate polish, technical density, or a cold / minimalist register — the rust-red palette and bold serif mix are intentionally warm and people-facing.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/long-table`

### Mat (`mat`)

- Tagline: Dark sage canvas with bone paper and burnt-orange accent; mid-century modern with wood undertones.
- Mood: warm-modern, considered, tactile, mid-century
- Tone: warm, design-led, intentional, considered
- Scheme: mixed
- Density: medium
- Best for: Anything that should feel mid-century, tactile, and intentional: design studio credentials, architecture / interior brands, ceramics / craft / furniture, advisory decks. Also a warm, distinctive choice for tech, research, or business decks that want a considered analog feel instead of digital-cool.
- Avoid for: Contexts that need fast tech energy or institutional restraint — the muted sage and burnt-orange palette is intentionally warm and slow.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/mat`

### Monochrome (`monochrome`)

- Tagline: Ivory ledger paper with all-black type; Lora serif headlines, Jost body, no color at all.
- Mood: restrained, literary, archival, ledger
- Tone: literary, considered, neutral, honest
- Scheme: light
- Density: high
- Best for: Anything that should feel like a hand-typeset ledger: user research synthesis, white papers, longform reports, academic and policy briefs, advisory deliverables, bilingual EN/CN reports. Equally good for tech, design, or brand decks that want their words to be the only thing on the page.
- Avoid for: Decks that need visual personality or color-led storytelling — the all-ink palette is intentionally austere.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/monochrome`

### Neo-Grid Bold (`neo-grid-bold`)

- Tagline: Editorial neo-brutalism with a single neon yellow accent on off-white paper.
- Mood: confident, punchy, editorial, modern
- Tone: bold, minimal, design-led, graphic
- Scheme: light
- Density: high
- Best for: Anything that should feel confident and editorial-graphic: design-led pitches, brand work, founder talks, conference keynotes. Excellent for stat-heavy slides, comparisons, and process flows. Just as strong for tech, research, or finance when the speaker wants to read as design-led rather than corporate.
- Avoid for: Contexts that need to feel quiet, traditional, or warm — the neon-yellow accent and uppercase display commit to a confident editorial voice.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/neo-grid-bold`

### People's Platform (Block & Bold) (`peoples-platform`)

- Tagline: Activist poster energy: blue, orange, red on cream, with Alfa Slab + Caveat Brush.
- Mood: activist, loud, graphic, honest
- Tone: punchy, direct, expressive, warm-bold
- Scheme: light
- Density: medium-high
- Best for: Anything that should feel honest, loud, and graphic: cultural commentary, manifestos, civic and community decks, design talks, campaign pitches. Excellent for founder-vision moments, mission statements, or any deck — including across industries — that wants protest-poster energy instead of corporate polish.
- Avoid for: Contexts where institutional restraint is the actual goal — the saturated political-poster palette commits hard to expressive energy.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/peoples-platform`

### Pin & Paper (`pin-and-paper`)

- Tagline: Yellow paper with safety-pin illustrations, ink-blue handwritten Caveat, paper-grain texture.
- Mood: crafted, handmade, warm, thoughtful, literary
- Tone: literary, intimate, warm, grounded
- Scheme: light
- Density: medium
- Best for: Anything that should feel hand-crafted, warm, and literary: qualitative research findings, founder reflections, longform brand stories, workshop debriefs. The signature safety-pin illustrations and paper-grain texture make it especially good for any deck — including tech or business — that wants personality and warmth over polish.
- Avoid for: Decks that need to feel digital-native polished or rigorously data-driven — handwritten Caveat is intentionally informal.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/pin-and-paper`

### Pink Script — After Hours (`pink-script`)

- Tagline: Black canvas, hot pink accent, pearl-cream paper, Instrument Serif headlines: late-night editorial luxury.
- Mood: nocturnal, moody, intentional, luxe, expressive
- Tone: literary, sultry, considered, magazine
- Scheme: dark
- Density: low
- Best for: Anything that should feel nocturnal, intentional, and a little luxe: fashion brand decks, creator personal brands, after-hours / nightlife / spirits launches, luxury product reveals, editorial features. Also a striking unexpected pick for a tech keynote, research synthesis, or business pitch that wants to land with magnetic confidence.
- Avoid for: Daytime corporate-professional and traditional B2B contexts where the dark canvas with hot-pink accent reads as too styled or too expressive.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/pink-script`

### Playful (`playful`)

- Tagline: Sun-warm peach background with Syne display: a friendly indie launch deck.
- Mood: warm, approachable, indie, friendly
- Tone: upbeat, informal, welcoming
- Scheme: light
- Density: medium
- Best for: Anything that should feel warm, indie, and approachable: creator portfolios, indie product launches, lifestyle brands, small-business pitches, newsletter / community decks. Also welcoming for any deck — including tech or research — that wants to feel friendly and human rather than corporate.
- Avoid for: Contexts where institutional credibility matters more than warmth — the peach palette is intentionally informal.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/playful`

### Raw Grid (`raw-grid`)

- Tagline: Neo-brutalist deck with thick borders, offset shadows, and a pink/sage/ink palette.
- Mood: raw, punchy, energetic, confident
- Tone: direct, modern, no-nonsense, graphic
- Scheme: light
- Density: high
- Best for: Anything that should feel direct and graphic-confident: founder pitches, accelerator demos, brand decks, indie launches, creator portfolios. Strong for stat slides, comparison tables, and process flows. Equally good for tech, research, or finance when the speaker wants the deck to feel scrappy-confident rather than buttoned-up.
- Avoid for: Contexts that need to feel soft, warm, or intentionally quiet — the brutalist borders and offset shadows commit to a graphic voice.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/raw-grid`

### Retro Windows (`retro-windows`)

- Tagline: Windows 95 chrome: gray title bars, MS Sans Serif, pixel typography, full nostalgia.
- Mood: nostalgic, retro, geeky, playful
- Tone: winking, nostalgic, geeky, fun
- Scheme: light
- Density: medium
- Best for: Anything that should feel knowingly nostalgic: retro gaming, Y2K-aesthetic brands, creator portfolios with a 90s vibe, tech-history talks, deliberately tongue-in-cheek decks. A great choice anywhere a playful retro reference is the entire point.
- Avoid for: Decks that need to read as modern, elegant, or institutionally credible — the Win95 chrome will always read as a costume.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/retro-windows`

### Retro Zine (`retro-zine`)

- Tagline: Beige paper with green accent and Bebas Neue + Caveat: a riso-printed zine in HTML form.
- Mood: crafted, lo-fi, underground, warm-retro
- Tone: scrappy, warm, intentional, DIY
- Scheme: light
- Density: medium
- Best for: Anything that should feel printed, lo-fi, and crafted: indie zines and publications, music / arts brands, creator portfolios, small-batch craft launches, community decks. Also a great underdog choice for tech, research, or business decks that want a riso-print warmth instead of digital polish.
- Avoid for: Contexts that demand digital-native polish or fast modern-tech energy — the layered zine aesthetic intentionally feels handmade.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/retro-zine`

### Sakura Chroma (`sakura-chroma`)

- Tagline: Vintage Japanese cassette-package aesthetic: cream paper, diagonal rainbow ribbons, condensed bold type, JIS-style spec checkboxes.
- Mood: retro, playful, kawaii-tech, warm, tactile, product-catalogue
- Tone: playful, confident, warm, tactile, 80s-Japanese-tech
- Scheme: light
- Density: medium
- Best for: Anything that should feel like a vintage Japanese cassette package or a TDK / Sony / Sakura Color product catalogue: indie hardware brand decks, music-label release schedules, analog studio retrospectives, zine and magazine pitches, kawaii-tech product launches, creative-studio annual reports. Equally good for any deck wanting bold colour, condensed display type, and a tactile printed-product personality.
- Avoid for: Decks that need restrained, corporate, or quiet typography — the bold condensed lockups, ribbon stripes, and primary-colour palette are intentionally loud and product-page-y.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/sakura-chroma`

### Scatterbrain (`scatterbrain`)

- Tagline: Post-it inspired: pastel sticky notes, Caveat handwriting, Shrikhand and Zilla Slab type stack.
- Mood: playful, creative, warm, messy-on-purpose, workshop
- Tone: informal, warm, expressive, human
- Scheme: light
- Density: high
- Best for: Anything that should feel like a designer's whiteboard: brainstorms, workshops, creative-agency credentials, design-thinking sessions, ideation pitches, art-direction reviews. Equally fun for any deck — including tech, research, or business — that wants to read as in-progress thinking rather than polished conclusions.
- Avoid for: Contexts that demand precision and institutional weight — the post-it sticky-note aesthetic intentionally reads as warm and unfinished.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/scatterbrain`

### Signal (`signal`)

- Tagline: Deep navy canvas with bone paper and a single muted-gold accent; institutional with quiet weight.
- Mood: institutional, trustworthy, considered, weighty
- Tone: sober, polished, established, literary
- Scheme: mixed
- Density: high
- Best for: Anything that should feel weighty, considered, and credibly institutional: investor decks, board presentations, consulting deliverables, legal / policy briefs, advisory pitches. Also a strong choice for tech, research, or brand work that wants to read as quietly authoritative rather than loud.
- Avoid for: Contexts that should feel hot, fast, or intentionally playful — the navy + gold restraint commits to a sober voice.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/signal`

### Soft Editorial (`soft-editorial`)

- Tagline: Cormorant Garamond serif on warm paper with sage, blush, and lemon accents.
- Mood: literary, elegant, quiet, warm-classical
- Tone: literary, considered, warm, magazine
- Scheme: light
- Density: low
- Best for: Anything that should feel literary, elegant, and unhurried: editorial features, longform brand stories, gallery / museum decks, advisory deliverables, wedding / lifestyle media, founder essays. Equally good for tech, research, or business decks that want a Sunday-supplement warmth instead of corporate polish.
- Avoid for: Decks that need visual heat or punch — the warm-paper palette and Cormorant serif are intentionally quiet.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/soft-editorial`

### Stencil & Tablet (`stencil-tablet`)

- Tagline: Bone paper with stencil-cut headlines and a six-color earth palette: archaeology meets brand.
- Mood: archival, earthy, tactile, considered, graphic
- Tone: weighty, considered, tactile, literary
- Scheme: light
- Density: medium
- Best for: Anything that should feel archival, tactile, and weighty-graphic: museum and cultural-institution decks, art / architecture brands, longform research, heritage and craft brands, manifestos. A great choice anytime — including across tech and business — when you want the deck to feel like a field manual rather than a slide deck.
- Avoid for: Contexts that demand digital-native polish or playful pop — the stencil-cut display and earth-tone palette commit to a deliberate analog feel.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/stencil-tablet`

### Studio (`studio`)

- Tagline: Black canvas with electric-yellow type; high-voltage design studio aesthetic.
- Mood: electric, bold, graphic, design-led, high-contrast
- Tone: graphic, loud, modern, intentional
- Scheme: dark
- Density: medium
- Best for: Anything that should feel electric and design-led: studio credentials, creative agency pitches, brand showcases, art-direction reviews, fashion / sneaker brand work. Also a striking unexpected choice for tech, research, or business decks where the speaker wants the deck to *be* a brand statement.
- Avoid for: Contexts that should feel quiet or institutional — the black-and-electric-yellow palette is the loudest in the library.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/studio`

### Vellum (`vellum`)

- Tagline: Deep navy canvas with warm-yellow Cormorant serifs and a single dusty teal accent. A quiet, scholarly aesthetic.
- Mood: scholarly, literary, considered, quiet, intellectual
- Tone: literary, considered, patient, intelligent
- Scheme: dark
- Density: low
- Best for: Anything that should feel scholarly, literary, and quietly intelligent: research synthesis, white papers, academic and policy briefs, advisory deliverables, longform editorial pieces, founder reflections. Equally strong for any deck — including tech, business, or creator work — that wants a calm, considered atmosphere instead of energetic visuals.
- Avoid for: Contexts that need visual heat or pop — the navy + warm-yellow Cormorant aesthetic is intentionally low-tempo.
- Folder: `gallery/frontend-slides-bold/bold-template-pack/templates/vellum`
