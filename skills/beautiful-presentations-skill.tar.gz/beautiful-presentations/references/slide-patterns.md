# Slide Patterns

Use patterns to avoid plain bullet decks. Every slide needs a visual job.

## 01 Title / Promise

- Huge title, one-line promise, small context label.
- Best for opening, section openers, final claim.
- Visual: atmospheric background, large wordmark, single abstract shape.

## 02 Problem Contrast

- Left: old broken way.
- Right: new desired way.
- Use strong visual contrast, not too many words.

## 03 Before → After

- Three-part transformation.
- Before state, mechanism, after state.
- Good for agency proposals and products.

## 04 Big Claim + Proof

- One bold claim.
- 2–3 proof points below.
- If proof is missing, use labeled placeholders.

## 05 Three-Part System

- Three large modules with clear names.
- Use for product pillars, service packages, workflows.
- Avoid generic words like “Optimize” unless content is specific.

## 06 Timeline / Roadmap

- Horizontal timeline.
- 3–5 phases max.
- Make current phase visually distinct.

## 07 Process Flow

- Steps connected by arrows or lanes.
- Good for AI pipelines, production workflows, sales process.
- Use short labels and supporting notes.

## 08 Architecture Map

- Nodes and flows.
- Good for technical decks.
- Keep labels readable; split into multiple slides if crowded.

## 09 Feature Anatomy

- One product/interface/workflow element in center.
- Callouts around it.
- Use realistic UI framing when possible.

## 10 Cinematic Mood Board

- Large visual area with placeholders.
- Use text labels for frame, mood, camera, lighting.
- Do not fake finished art unless user supplies it or asks for placeholders.

## 11 Offer / Package Slide

- 2–3 package tiers or one signature offer.
- Focus on deliverables and outcomes.
- Avoid generic pricing fluff.

## 12 Decision Slide

- Show options with recommendation.
- One option should be visually marked “Best.”
- Keep criteria clear.

## 13 Final Ask

- One direct ask.
- Next steps.
- Contact/project label.
- Strong but not salesy.

## Density checks

If a slide has:

- more than 8 bullets,
- more than 6 cards,
- more than 2 paragraphs,
- more than 3 nested layers,

split it.

## Text size guidance at 1920×1080

- Hero title: 96–170px
- Slide title: 58–96px
- Subtitle: 34–48px
- Body: 28–38px
- Small labels: 20–26px
- Footnotes: 18–22px only if truly minor

Do not go under 18px unless it is decorative metadata.
