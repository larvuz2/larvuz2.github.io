# Client Review Preview & Navigation Notes

Use this reference when generating browser-first decks intended for fast client/user review.

## Durable user correction captured

For HTML presentation deliverables, chat/file attachment is the wrong default. The review object should be a live URL that the user can open instantly, share, and comment on.

Default path:

1. Build the deck as a one-file `index.html`.
2. Verify locally: no console errors, no overflow, keyboard navigation works.
3. Publish through the shared `presentations` GitHub Pages repository, one folder per deck.
4. Send the live GitHub Pages URL first.
5. Include repo URL and local backup path only as secondary info.
6. Do not send raw HTML unless the user explicitly asks for the file.

## Scroll navigation requirement

Browser-native decks should feel natural when opened by a client. In addition to arrows, buttons, and swipe:

- mouse wheel / trackpad scroll down advances one slide
- mouse wheel / trackpad scroll up returns one slide
- call `preventDefault()` in the wheel handler to stop browser rubber-banding
- throttle/debounce wheel gestures so one trackpad gesture does not skip multiple slides
- keep body/page overflow hidden; slides themselves must not scroll

Minimal wheel handler pattern:

```js
constructor() {
  this.wheelLocked = false;
}

handleWheel(event) {
  event.preventDefault();
  const delta = Math.abs(event.deltaY) >= Math.abs(event.deltaX)
    ? event.deltaY
    : event.deltaX;

  if (Math.abs(delta) < 18 || this.wheelLocked) return;

  this.show(this.current + (delta > 0 ? 1 : -1));
  this.wheelLocked = true;
  setTimeout(() => { this.wheelLocked = false; }, 640);
}

document.addEventListener('wheel', event => this.handleWheel(event), {
  passive: false
});
```

## Verification

After publishing, verify against the live URL, not only the local file:

- fetch/check the live URL returns the updated HTML from `https://<owner>.github.io/presentations/<project-slug>/`
- browser opens the GitHub Pages URL
- console has no JS errors
- wheel event changes the visible slide counter, e.g. `1 / 3 → 2 / 3`
- reverse wheel changes back, e.g. `2 / 3 → 1 / 3`
- visual QA confirms controls/hints do not cover important content

## Final response shape

Keep it short:

```txt
Updated: <live GitHub Pages URL>
Verified: scroll down/up changes slides, arrows/space still work, no console errors.
Repo: <GitHub repo URL>
```
