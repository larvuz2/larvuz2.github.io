# Agent Handoff Message Pattern

Use when sharing the `beautiful-presentations` skill with another Hermes agent/profile/VPS.

## Rule

The chat handoff should be extremely brief. The operational detail belongs inside the public Markdown skill file and tarball, not in the message.

## Final message template

```txt
Read and install this skill:

https://larvuz2.github.io/skills/beautiful-presentations.md

Use it whenever I ask for presentations, decks, client previews, PDF exports, or video exports.
```

## Why

Receiving agents should fetch the Markdown reader and learn the workflow there. The user does not want the paste-message cluttered with repo structure, aspect ratio, export mechanics, or design rules.

## Pitfall

Do not restate all implementation details in the handoff message. If the detail matters, put it in `SKILL.md` or a `references/` file and make sure the public reader/tarball includes it.
