# Visual Template Gallery

Use this when maintaining or extending the public template gallery for `beautiful-presentations`.

## Preferred gallery pattern

Use **live HTML embeds** for template previews, not screenshots, unless performance becomes a real blocker.

Why live embeds are preferred:

- they show the actual HTML design instead of a stale capture
- subtle motion stays visible
- no screenshot regeneration pipeline is needed
- clicking a card can open the full template directly
- each template remains scrollable/navigable on its own page

## Gallery card rules

- Show the embedded preview prominently.
- Show only one visible template label per card.
- Keep the label on the far left under the preview.
- Do not duplicate the slug/name on the right side of the card.
- Descriptions are secondary; for this gallery, visual grasp matters more than explanatory copy.
- The card click target should open `templates/<slug>/template.html`.

## Verification checklist

Before saying the gallery is done:

- public gallery URL returns 200
- gallery contains one card per template
- each card contains one preview iframe
- visible duplicate labels are removed
- clicking a card opens the matching template page
- browser console has no errors
- if GitHub Pages appears stale, verify the raw pushed file and retry the public URL with a cache-busting query string after a short delay

## Cache pitfall

GitHub Pages can serve the previous version briefly after push. If the local/remote git content is correct but the public URL still shows old markup, wait and retry with a cache-busting query string before making more changes.
