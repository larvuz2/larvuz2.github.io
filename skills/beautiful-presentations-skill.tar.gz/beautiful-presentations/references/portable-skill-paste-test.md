# Portable Skill Paste Test

Use this when the user wants the presentation workflow to be reusable across Hermes profiles, VPS machines, and models.

## Test objective

A separate Hermes agent should be able to paste/install this skill and produce the same class of artifact without needing Claude, the original chat, or local unstated assumptions.

The required outcome is:

- one self-contained 16:9 HTML deck by default
- browser-first review URL
- one shared private `presentations` repo for GitHub Pages previews, with one folder per deck; no new repo per deck by default
- beautiful custom visual system, not generic SaaS slides
- subtle alive motion by default
- keyboard, wheel, and touch navigation when practical
- print CSS for horizontal PDF export
- optional video export path
- clear QA and final response format

## What the skill package must include

- `SKILL.md` with triggers, defaults, non-negotiables, workflow, QA, and final response shape
- `templates/base-deck.html` as the copy-modify starting point
- `references/` for style systems, repo analyses, motion rules, delivery rules, and export notes
- `scripts/` for deterministic QA/export/publish helpers where possible

## Model-neutral requirements

Do not depend on:

- Claude Artifacts
- Claude Code slash commands
- a specific model family
- hidden chat context
- manual copy/paste of missing CSS or JS
- external build steps unless explicitly stated

The skill should read like operating instructions that any competent Hermes model can follow with file, terminal, browser, and GitHub tools.

## Final validation prompt

After installing the skill in another Hermes agent/profile, use a prompt like:

```txt
Use the beautiful-presentations skill to create a browser-first one-file HTML deck for [PROJECT]. Make it 16:9, high-design, with subtle alive motion by default, keyboard/wheel navigation, print CSS for PDF export, and a live preview URL. Publish it inside the shared private `presentations` GitHub Pages repo under a project slug folder; do not create a new repo unless I explicitly ask. Do not use Claude-specific features. Verify repo privacy and live preview availability before final response.
```

Passing means the other agent produces a working reviewed HTML presentation and can explain/export PDF or video only when asked.
