# Beautiful Presentations Ramp-Up Plan

## Goal

Raise the skill from “can generate HTML slides” to “can reliably create beautiful, reference-grade browser-native decks.”

The core shift:

```txt
from themed slide generation → to design-system adaptation
```

A great deck should feel like a designed object, not content placed inside a style skin.

## Immediate fixes already applied

- Raw HTML files should not be attached by default.
- HTML delivery should produce a preview URL.
- Added `publish_preview.py` helper for preview publishing.
- PDF export now injects a 16:9 print page rule and exports 1920×1080 / 1440×810pt pages.
- Imported the real `beautiful-html-templates/templates/sakura-chroma` source.
- Added Sakura Chroma source-analysis notes.

## Phase 1 — Preview delivery infrastructure

### Problem

HTML files are technically correct but bad client deliverables in Telegram/chat. They need a URL.

### Implementation

Add a stable preview host for generated decks:

```txt
/var/www/presentations/<deck-slug>/<timestamp>/index.html
https://preview.domain.com/<deck-slug>/<timestamp>/
```

Set env vars on each Hermes VPS/profile:

```bash
HERMES_PRESENTATION_PREVIEW_ROOT=/var/www/presentations
HERMES_PRESENTATION_PREVIEW_BASE_URL=https://preview.domain.com
```

Then the skill uses:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/publish_preview.py deck.html --slug project-name
```

### Acceptance criteria

- User receives a clickable URL.
- Raw HTML is never attached unless requested.
- Local backup path is still reported.
- URL works on phone and desktop.

## Phase 2 — Real template adaptation

### Problem

The first Sakura Chroma deck copied tokens and motifs, but not the source template's composition intelligence.

### Implementation

For every imported template, store:

```txt
template.html
design.md
template.json
screenshots/
adaptation-notes.md
```

For Sakura Chroma specifically, future decks should start from the real source template and map content into its slide archetypes:

- package cover
- giant manifesto statement
- product catalogue grid
- ribbon quote card
- ledger/spec sheet
- stat/equalizer page
- closing colophon

### Acceptance criteria

- Deck looks like a real object from the reference universe.
- Different slides use different composition archetypes.
- Visual system is not just colors + fonts.
- User content replaces demo content without collapsing the layout.

## Phase 3 — Design QA rubric

Before final delivery, evaluate every slide against:

- **Composition**: strong focal point, asymmetry, visual balance.
- **Typography**: correct type scale, no timid headings, readable body.
- **Density**: intentional whitespace, no cramped cards.
- **Motif discipline**: motifs used structurally, not randomly.
- **Authenticity**: micro-labels, metadata, spec rows, and object logic feel real.
- **Export**: no overflow, no console errors, PDF is 16:9 if requested.

Add scoring:

```txt
A = client-ready / reference-grade
B = usable but needs polish
C = generic themed deck
F = broken / unreadable / export failure
```

Do not deliver below B. For high-design asks, target A.

## Phase 4 — Template gallery upgrade

### Problem

The gallery currently exists as reference files, but agents may still generate generic approximations.

### Implementation

For each strong template:

1. Copy source template.
2. Generate screenshots.
3. Write adaptation notes.
4. Extract reusable slide archetypes.
5. Create mini CSS/component snippets.
6. Add “what not to do” pitfalls.

Priority templates:

1. Sakura Chroma
2. Studio
3. Bold Poster
4. Neo Grid Bold
5. Editorial Forest
6. Signal
7. Vellum
8. Raw Grid

## Phase 5 — Export hardening

PDF:

- Always force 16:9 page size.
- Verify with `pypdf` if `pdfinfo` is missing.
- Compare page count to slide count.
- Optionally screenshot PDF pages for visual QA.

Video:

- Export from verified slide screenshots first.
- Add animated capture later.

HTML:

- Preview URL first.
- Attach raw HTML only on explicit request.

## New generation rule

When a user asks for a named template style:

```txt
Do not approximate from memory. Read the template source, inspect screenshots, and adapt its composition system.
```

## Next implementation move

Rebuild the Gus 3-slide deck from the actual Sakura Chroma source template, not from the generic base. Use fewer words, stronger poster statements, and object-like catalogue composition.
