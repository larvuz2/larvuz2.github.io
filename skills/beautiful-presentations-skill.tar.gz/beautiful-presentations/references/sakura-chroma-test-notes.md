# Sakura Chroma Deck Test Notes

Session-derived notes from building and QAing a 3-slide personal deck in the `sakura-chroma` gallery style.

## When user asks for a gallery style

1. Load `references/bold-template-gallery.md`.
2. Load the selected template's `design.md` before generating final slides.
3. Reuse the style system: palette, typography roles, component vocabulary, density, and layout logic.
4. Do not copy demo/template content. Use the user's real content.
5. Default deliverable stays the one-file HTML deck. PDF/video exports are optional downstream artifacts.

## Portable package clarity

A `.tar.gz` skill package is only for installing the skill on another Hermes profile/VPS/agent. It is not the deck deliverable.

When delivering a deck, prioritize:

- `MEDIA:/absolute/path/deck.html`
- optional `MEDIA:/absolute/path/deck.pdf` only if exported/asked/used for verification

Only send the skill `.tar.gz` when the user asks for portability, another VPS/profile, or reusable ecosystem install.

## CSS overflow pitfall: diagonal ribbons

Large rotated absolutely-positioned ribbon stacks can make `scrollWidth` / `scrollHeight` exceed the 1920×1080 slide even when `.slide { overflow: hidden; }` visually clips them. This creates false or real export QA failures.

Preferred fix:

- Render full-bleed diagonal ribbon bands as `.slide::before` linear-gradients on a `ribbon-left` / `ribbon-right` class.
- Keep decorative ribbon layers inside the slide box instead of using huge off-canvas rotated DOM elements.
- If using rotated DOM ribbons anyway, QA all slides with Playwright and patch until overflow is false.

## Screenshot QA timing

If slides use reveal animations, do not screenshot immediately after `window.deck.show(i)`. Wait for the animation duration plus buffer.

Known-good default:

```js
page.wait_for_timeout(700)
```

This prevents screenshots from capturing semi-transparent or still-moving content.

## Verification loop

For generated HTML decks:

1. Run static QA.
2. Run Playwright browser QA when available.
3. Capture screenshots for every slide.
4. Inspect screenshots visually for style fidelity, readability, clipping, hidden content, and hierarchy.
5. Patch until:
   - no console errors
   - `scrollWidth === clientWidth`
   - `scrollHeight === clientHeight`
   - all slide screenshots look complete after animation settle
6. Export PDF only when asked or when useful to validate print/export behavior.
