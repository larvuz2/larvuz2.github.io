# GitHub Pages Preview Delivery

Use this when delivering browser-native HTML decks for client review.

## Rule

Default delivery is a live URL, not an HTML attachment.

For this user's presentation workflow, **do not create one new repo per deck**. Use one shared **private** GitHub Pages repository for all presentations unless the user explicitly requests a separate repo.

Current preferred shared repo:

```txt
Repo: https://github.com/larvuz2/presentations
Visibility: private repo
Pages root: https://larvuz2.github.io/presentations/
Deck URL pattern: https://larvuz2.github.io/presentations/<project-slug>/
Public deploy mirror if private Pages is unsupported: https://github.com/larvuz2/larvuz2.github.io
```

Privacy note: source/version history should live in a private repo. GitHub Pages previews may still be public depending on GitHub plan/settings, so verify repo privacy and preview availability as separate checks. If GitHub reports that the plan does not support Pages for the private source repo, keep the source repo private and push a static preview mirror to the public user-site repo instead.

## Why

- Clients can open the deck on phone/desktop without downloading HTML.
- Revisions are easier to review by URL.
- The shared repo keeps version history without cluttering GitHub with one-off deck repos.
- The same preview flow works across Hermes profiles, VPS agents, and models.

## Shared repo structure

```txt
presentations/
  index.html                         # optional gallery/index of all decks
  README.md
  <project-slug>/
    index.html                       # default browser review artifact
    exports/
      <project-name>.pdf             # only when requested
      <project-name>.mp4             # only when requested
    assets/                          # only if absolutely needed
```

Decks should still be self-contained whenever possible. Keep exports inside the same project folder.

## Workflow

1. Clone or reuse the shared private `presentations` repo.
2. Create/update a slug folder for the deck: `<project-slug>/index.html`.
3. If a PDF/MP4 export is requested, place it under `<project-slug>/exports/`.
4. Commit with a concise design/deploy message.
5. Push to `main`.
6. Confirm repo visibility is private.
7. Enable GitHub Pages from `main` / root if supported. If unsupported for the private repo, mirror the static `/presentations/` folder into `larvuz2.github.io` or the equivalent public preview deployment repo.
8. Poll the deck Pages URL until it returns HTTP 200 before telling the user it is live.
9. Browser-check the live deck URL, not only the local file.
10. Final response should lead with the preview URL and mention repo privacy.

## Preferred final response shape

```txt
Preview: https://<owner>.github.io/presentations/<project-slug>/
Repo: https://github.com/<owner>/presentations
Verified: live URL works, 3 slides, no console errors, no overflow.
Local backup: /absolute/path/presentations/<project-slug>/index.html
```

## Pitfalls

- Do not attach `MEDIA:/path/deck.html` unless the user explicitly asks for the raw file.
- Do not create a fresh GitHub repo for each presentation. Use the shared `presentations` repo unless the user asks for isolation.
- Do not leave the shared presentations repo public. Create/keep it private unless the user explicitly requests public source.
- Do not break the live review URL when making the source repo private. If private Pages is unsupported, use a public static deployment mirror while keeping the source repo private.
- Do not delete old per-deck repos without explicit written confirmation from Gus.
- Do not claim GitHub Pages is live immediately after enabling it; it may return 404 while building. Poll until 200.
- Do not rely only on local QA. Open the public Pages URL and check console errors.
- Keep navigation controls subtle and out of the slide composition. If controls obscure content in screenshots, move them or make them hover-only.
- For high-design decks, use visual QA screenshots in addition to DOM overflow checks. DOM can pass while the design still has ugly overlap.
