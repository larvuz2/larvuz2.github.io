# PPTX Conversion

Use this when the user gives a `.pptx` and asks to convert, redesign, or improve it.

## Principle

Extract accurately, then redesign. Do not blindly recreate ugly PowerPoint layouts unless the user explicitly asks for pixel matching.

## Pipeline

1. Extract text, notes, and images.
2. Preserve slide order.
3. Build `outline.md` and `manifest.json`.
4. Identify hierarchy and key message per slide.
5. Redesign into browser-native HTML.
6. Verify deck against extracted outline.

## Helper

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/extract_pptx.py source.pptx extracted/
```

Expected output:

```txt
extracted/
├── outline.md
├── manifest.json
└── media/
```

## Fallback

If helper dependencies are missing, try:

```bash
python -m markitdown source.pptx
```

If both fail, ask the user for exported text/images.
