# Animation Patterns

Use motion as design discipline. It should clarify hierarchy and make the deck feel alive without hurting export.

## Default reveal

```css
.reveal {
  opacity: 0;
  transform: translateY(26px);
  filter: blur(8px);
  transition:
    opacity 700ms var(--ease-out),
    transform 700ms var(--ease-out),
    filter 700ms var(--ease-out);
}

.slide.visible .reveal {
  opacity: 1;
  transform: translateY(0);
  filter: blur(0);
}

.slide.visible .reveal:nth-child(1) { transition-delay: 80ms; }
.slide.visible .reveal:nth-child(2) { transition-delay: 160ms; }
.slide.visible .reveal:nth-child(3) { transition-delay: 240ms; }
.slide.visible .reveal:nth-child(4) { transition-delay: 320ms; }
```

## Feeling map

### Cinematic / dramatic

- Slow fade and blur
- Spotlight gradients
- subtle atmospheric drift
- large title scale

### Technical / futuristic

- grid reveal
- line tracing
- small pulsing nodes
- mono labels

### Founder / sharp pitch

- fast 250–400ms fades
- clean slide-in
- no ornamental loops

### Editorial

- text cascade
- image/text interplay
- subtle page-like movement

### Playful / game

- snappier easing
- card pops
- controlled bounce

## Background texture

Use subtle texture to avoid flatness:

```css
.noise::before {
  content: '';
  position: absolute;
  inset: 0;
  pointer-events: none;
  opacity: .18;
  background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.35'/%3E%3C/svg%3E");
}
```

## Export warning

PDF export captures final visual state better than complex animations. Make sure every animated object has a clean visible final state.

Video export from screenshots will not capture motion unless animated capture is specifically implemented. Static slide MP4 is acceptable as MVP.
