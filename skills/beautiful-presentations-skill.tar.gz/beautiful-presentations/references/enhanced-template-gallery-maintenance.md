# Enhanced Template Gallery Maintenance

Use when refreshing or expanding the local presentation template foundation from an external HTML template repo.

## Goal

Keep `beautiful-presentations` as a class-level reusable deck system, not a one-off template dump.

Imported templates should become **our established design foundations**:

- copied into the skill for portability
- inspected through `design.md`, `template.json`, and `template.html`
- enhanced with subtle premium motion
- verified with smoke tests
- exposed through the public skill reader / tarball when sharing the skill

## Standard refresh sequence

1. Clone or pull the upstream inspiration repo into a temporary/work repo.
2. Copy the complete `templates/` folder into:

```txt
gallery/beautiful-html-templates/templates/
```

3. Copy the upstream index/metadata into:

```txt
gallery/beautiful-html-templates/index.json
```

4. For every `template.html`, inject a small reusable motion/runtime layer:
   - quiet slide-entry reveal
   - tiny living motif pulse/drift only on decorative systems
   - tactile hover transitions
   - `prefers-reduced-motion` safety
   - wheel navigation fallback when the template does not already support it

5. For every template-local `deck-stage.js`, patch wheel navigation directly into the component:
   - `window.addEventListener('wheel', handler, { passive: false })`
   - debounce/lock so one scroll gesture advances only one slide
   - call the component's normal navigation method, not a separate state system

6. Add/update a gallery reference file that lists all templates by name, slug, mood, tone, best use, and folder.

7. Update `SKILL.md` so new-design/template requests load the enhanced gallery first.

8. Rebuild the portable reader and tarball if this skill is published publicly.

## Verification checklist

Minimum local checks:

- all template folders include `template.html`
- all enhanced templates contain the motion marker
- all enhanced templates contain the runtime marker
- all `deck-stage.js` files contain the wheel-navigation patch
- HTML parser does not throw on the modified files

Browser smoke test at least:

- one inline-script template
- one `deck-stage.js` template
- load each through a local static server
- check console errors
- navigate with keyboard
- verify wheel/scroll navigation when practical

Public sharing checks if published:

- skill Markdown reader returns HTTP 200
- tarball returns HTTP 200 and contains all enhanced `template.html` files
- public template gallery URL returns HTTP 200
- at least one public template URL returns HTTP 200 and contains the motion marker

## Important taste rule

Do not treat imported templates as final decks. They are design foundations.

For a user deck:

1. choose by mood/tone/audience
2. inspect `design.md` and `template.html`
3. preserve the visual grammar
4. replace demo content completely
5. keep our deck non-negotiables: one-file HTML, browser-first preview, subtle alive motion, print/export path, verified navigation

## Pitfalls

- Do not flatten all templates into a generic SaaS deck style.
- Do not copy demo content into client work.
- Do not add loud animation everywhere; the Sakura Chroma improvement worked because the motion was subtle.
- Do not publish only a Telegram attachment when sharing the skill. The receiving agent needs a public reader URL and/or tarball.
- Do not put long handoff instructions in chat if the Markdown skill file already contains the operating details. The handoff message should stay extremely short.
