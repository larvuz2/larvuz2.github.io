# Installation and Verification

Use this reference when packaging the skill for another Hermes profile/VPS or when checking that the skill is usable after installation.

## Install into the active Hermes profile

```bash
mkdir -p ~/.hermes/skills/creative/beautiful-presentations
# copy SKILL.md plus references/, templates/, scripts/, assets/ into that directory
```

Load it:

```bash
hermes -s beautiful-presentations
```

or in an active Hermes session:

```txt
/skill beautiful-presentations
```

## Install into another named profile

```bash
mkdir -p ~/.hermes/profiles/PROFILE_NAME/skills/creative/beautiful-presentations
# copy the complete skill directory contents there
```

Then run:

```bash
hermes -p PROFILE_NAME -s beautiful-presentations
```

## Portable tarball package

From an installed skill directory:

```bash
mkdir -p ~/.hermes/cache/documents
tar -C ~/.hermes/skills/creative -czf ~/.hermes/cache/documents/beautiful-presentations-skill.tar.gz beautiful-presentations
```

On another VPS:

```bash
mkdir -p ~/.hermes/skills/creative
tar -xzf beautiful-presentations-skill.tar.gz -C ~/.hermes/skills/creative
```

## One-time GitHub setup for a new VPS/user

The skill can generate decks without GitHub, but live review URLs require GitHub auth and repo setup.

Prerequisites:

- `git` installed
- GitHub auth available through `GITHUB_TOKEN`, `GH_TOKEN`, `gh auth login`, or git credentials
- a GitHub owner/user/org where repos can be created

Run once:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/setup_presentations_repos.py --owner YOUR_GITHUB_OWNER
```

This creates/checks:

- private source repo: `YOUR_GITHUB_OWNER/presentations`
- public preview mirror: `YOUR_GITHUB_OWNER/YOUR_GITHUB_OWNER.github.io`
- local source clone: `~/presentations/shared-repo`
- local preview mirror clone: `~/presentations/public-pages-deploy`
- live URL pattern: `https://YOUR_GITHUB_OWNER.github.io/presentations/<project-slug>/`

Why two repos: many GitHub plans do not support Pages directly from private repos. The private repo preserves source/history; the public mirror preserves easy browser feedback URLs.

If the user/client requires private access-controlled preview URLs, GitHub Pages may not be enough. Use a private VPS/authenticated preview host instead.

## Minimum verification

Run these after install or edits:

```bash
chmod +x ~/.hermes/skills/creative/beautiful-presentations/scripts/*.py
python -m py_compile ~/.hermes/skills/creative/beautiful-presentations/scripts/*.py
python ~/.hermes/skills/creative/beautiful-presentations/scripts/export_pdf.py --help
python ~/.hermes/skills/creative/beautiful-presentations/scripts/export_video.py --help
python ~/.hermes/skills/creative/beautiful-presentations/scripts/extract_pptx.py --help
python ~/.hermes/skills/creative/beautiful-presentations/scripts/setup_presentations_repos.py --help
python ~/.hermes/skills/creative/beautiful-presentations/scripts/sync_private_presentations_mirror.py --help
python ~/.hermes/skills/creative/beautiful-presentations/scripts/qa_html_deck.py ~/.hermes/skills/creative/beautiful-presentations/templates/base-deck.html
```

The QA helper has two levels:

- Static checks: validate file shape, print CSS, controller, slide count, and 1920×1080 rules.
- Browser checks: if Playwright/Chromium is available, open the deck, capture console errors, inspect slides, and optionally produce screenshots.

Do not claim browser verification unless the browser checks actually ran. Static QA is still useful, but label it as static QA.

## Delivery pattern for Telegram / gateway

For file delivery, put portable archives or exports under:

```txt
~/.hermes/cache/documents/
```

Then attach with:

```txt
MEDIA:/root/.hermes/cache/documents/beautiful-presentations-skill.tar.gz
```

## Quality reminder

The purpose is not just to install files. A usable implementation means another Hermes agent can load the skill, generate an HTML deck, run QA, and export PDF/video when dependencies are available.