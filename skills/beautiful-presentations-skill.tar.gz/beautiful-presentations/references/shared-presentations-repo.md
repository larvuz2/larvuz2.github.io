# Shared Presentations Repo

Use this reference when publishing browser-first HTML decks for Gus/Larvuz.

## User correction

Do **not** create a new GitHub repository for every deck or presentation.

Default to one shared **private** GitHub Pages repo that contains all presentations, with one folder per project/deck.

Current default for Gus:

```txt
Repo: https://github.com/larvuz2/presentations
Visibility: private repo
Local clone: /root/presentations/shared-repo
Pages root: https://larvuz2.github.io/presentations/
Deck URL pattern: https://larvuz2.github.io/presentations/<project-slug>/
Public deploy mirror: https://github.com/larvuz2/larvuz2.github.io
Deploy mirror local clone: /root/presentations/public-pages-deploy
```

## Privacy rule

The shared `presentations` repo should be private for Gus and for any user/profile that installs this skill. If the repo does not exist, create it as private. If it already exists and is public, convert it to private before continuing.

GitHub Pages previews can still be public depending on account/plan/settings. On GitHub plans that do not support Pages directly from private repos, keep `presentations` private as the source repo and publish a review-only static mirror to the public `larvuz2.github.io` deploy repo under `/presentations/`.

Verify both separately:

- repo API/settings reports `private: true`
- live deck URL still returns HTTP `200` if the user expects browser review to keep working

Do not assume the Pages URL itself is private or access-controlled unless this has been explicitly verified. The default Gus setup is: private source repo, public browser-review URL.

## Structure

```txt
presentations/
  index.html                         # gallery/index of all decks
  README.md
  <project-slug>/
    index.html                       # browser-first HTML deck
    exports/
      <project-name>.pdf             # only when requested
      <project-name>.mp4             # only when requested
    assets/                          # only if the deck cannot stay self-contained
```

## Workflow

1. Build and verify the one-file HTML deck locally.
2. Clone or reuse `/root/presentations/shared-repo`.
3. If this is a new VPS/user, run `scripts/setup_presentations_repos.py --owner <github-owner>` once to create/check the private source repo and public preview mirror.
4. Copy the deck to `<project-slug>/index.html`.
5. Put requested exports under `<project-slug>/exports/`.
6. Update the shared `index.html` gallery/landing page if useful.
7. Commit and push the private source repo to `main`.
8. Ensure the shared repo visibility is private.
9. If private-repo Pages is unsupported or unavailable, mirror the static files into `/root/presentations/public-pages-deploy/presentations/` and push `larvuz2.github.io`.
10. Poll the live deck URL until it returns HTTP `200`.
11. Browser-check the live deck URL, not just the local file.
12. Final response leads with the live deck URL and confirms repo privacy.

## Deletion rule

Old one-off deck repos may remain as legacy. Do **not** delete GitHub repositories unless Gus gives explicit written confirmation.

## Final response shape

```txt
Preview: https://larvuz2.github.io/presentations/<project-slug>/
Repo: https://github.com/larvuz2/presentations
Verified: live URL works, navigation works, no console errors.
Local backup: /root/presentations/shared-repo/<project-slug>/index.html
```
