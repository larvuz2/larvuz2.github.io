# PPTX Export

Use this when the user asks for a `.pptx`, PowerPoint file, editable presentation file, or “download as PowerPoint.”

## Principle

Yes: `.pptx` export is supported.

The default export should be **pixel-faithful**, not a rough rebuilt PowerPoint approximation.

Best reliable method:

1. Finalize and verify the browser HTML deck first.
2. Render every slide at `1920 × 1080`.
3. Create a widescreen `.pptx` with one full-bleed rendered slide image per PowerPoint slide.
4. Deliver the `.pptx` as a downloadable PowerPoint file.

This preserves the exact look of the approved web/PDF deck after opening or importing into PowerPoint, Keynote, or Google Slides.

## Important expectation

PowerPoint cannot reliably reproduce complex HTML/CSS layouts, custom web fonts, masks, blend modes, browser animations, and responsive positioning as editable native shapes.

So the primary `.pptx` export is:

```txt
pixel-faithful PowerPoint slides, full-bleed image per slide
```

This is the correct default when the user says it should look exactly like web/PDF.

If the user explicitly asks for editable PowerPoint objects, explain the tradeoff:

- editable PPTX = easier to modify, but may not match exactly
- pixel-faithful PPTX = matches the web/PDF exactly, but slide content is flattened

Default to pixel-faithful unless the user explicitly prioritizes editability.

## Helper

Preferred helper:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/export_pptx.py deck.html exports/deck.pptx
```

The helper:

- opens the HTML deck with Playwright/Chromium
- captures each slide at 1920×1080
- creates a valid 16:9 `.pptx`
- places each rendered PNG full-bleed on its matching slide
- validates the PowerPoint package structure

## Verification

Before delivery:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/export_pptx.py deck.html exports/deck.pptx
python - <<'PY'
from pathlib import Path
import zipfile
p=Path('exports/deck.pptx')
print('exists', p.exists())
print('bytes', p.stat().st_size if p.exists() else 0)
with zipfile.ZipFile(p) as z:
    slides=[n for n in z.namelist() if n.startswith('ppt/slides/slide') and n.endswith('.xml')]
    images=[n for n in z.namelist() if n.startswith('ppt/media/image') and n.endswith('.png')]
    print('slides', len(slides))
    print('images', len(images))
PY
```

Minimum pass:

- file exists
- file size > 0
- zip opens
- slide count matches HTML slide count
- image count matches slide count
- `ppt/presentation.xml` exists
- `ppt/slides/slide1.xml` exists

If available, also open the PPTX in LibreOffice/PowerPoint and export/check a preview PDF.

## Final response

For Telegram/client delivery:

```txt
PowerPoint exported and verified.
MEDIA:/absolute/path/exports/Project_Name_Deck.pptx
```

Mention only if relevant:

```txt
This is a pixel-faithful PPTX, so it visually matches the web/PDF. Slide contents are flattened to preserve the design exactly.
```
