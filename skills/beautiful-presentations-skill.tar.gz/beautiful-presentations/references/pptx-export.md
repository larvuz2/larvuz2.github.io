# PPTX Export

Use this when the user asks for a `.pptx`, PowerPoint file, editable presentation file, or “download as PowerPoint.”

## Principle

Yes: `.pptx` export is supported.

The default export should be **pixel-faithful**, not a rough rebuilt PowerPoint approximation.

Best reliable method:

1. Finalize and verify the browser HTML deck first.
2. Render every slide at `1920 × 1080`.
3. Create a widescreen `.pptx` with one full-bleed rendered slide image per PowerPoint slide.
4. Deliver the `.pptx` as a downloadable PowerPoint file.

This preserves the exact look of the approved web/PDF deck after opening or importing into PowerPoint, Keynote, or Google Slides.

## Important expectation

PowerPoint cannot reliably reproduce complex HTML/CSS layouts, custom web fonts, masks, blend modes, browser animations, and responsive positioning as editable native shapes.

So the primary `.pptx` export is:

```txt
pixel-faithful PowerPoint slides, full-bleed image per slide
```

This is the correct default when the user says it should look exactly like web/PDF.

If the user explicitly asks for editable PowerPoint objects, **do not send only the pixel-faithful image-per-slide export**. Create a separate editable/native PPTX.

Tradeoff:

- editable/native PPTX = text boxes, circles, lines, rectangles, cards, and labels can be selected and edited; may not match complex HTML/CSS perfectly
- pixel-faithful PPTX = matches the web/PDF exactly, but slide content is flattened into one image per slide

Default to pixel-faithful for exact visual matching. When the user says the flattened version is useless, asks for every object to be editable, or asks for editable PowerPoint, switch to native editable export.

## Editable/native PPTX export

For editable decks, rebuild the slide as PowerPoint-native objects instead of screenshots.

Preferred approach:

1. Use the approved HTML deck as the visual reference.
2. Preserve the same 16:9 slide size and coordinate system.
3. Convert HTML/CSS layout coordinates into PowerPoint units carefully. For 1920×1080 HTML mapped to 13.333×7.5in PowerPoint, coordinates use `x_in = px / 144`, `y_in = px / 144`, and CSS font pixels convert roughly to `font_pt = css_px * 0.5` — not `0.75`. Using `0.75` makes text about 50% too large and causes Google Slides/PowerPoint overflow.
4. Recreate:
   - text as editable text boxes
   - circles/blobs as editable ellipse shapes
   - cards/panels as editable rectangles
   - rules/lines as editable line shapes
   - ribbons/bars as editable rotated rectangles or parallelograms
   - simple icons/seals as editable native shapes when possible
5. Avoid using slide screenshots except as optional hidden/reference or if the user asks for pixel-perfect non-editable export.
6. Verify the `.pptx` zip has slide XML with many native `<p:sp>` shapes and no full-slide PNG media.

Recommended tool: `pptxgenjs` for native shape generation.

Minimum verification for editable PPTX:

```bash
python - <<'PY'
from pathlib import Path
import zipfile
p=Path('exports/deck_EDITABLE.pptx')
with zipfile.ZipFile(p) as z:
    names=z.namelist()
    slides=[n for n in names if n.startswith('ppt/slides/slide') and n.endswith('.xml')]
    media=[n for n in names if n.startswith('ppt/media/image')]
    shapes=sum(z.read(s).decode('utf-8', 'ignore').count('<p:sp>') for s in slides)
    texts=sum(z.read(s).decode('utf-8', 'ignore').count('<a:t>') for s in slides)
print('slides', len(slides))
print('image_media', len(media))
print('native_shapes', shapes)
print('text_runs', texts)
PY
```

Pass criteria:

- slide count matches the HTML deck
- `image_media` is 0 or only intentional non-editable assets
- `native_shapes` is high enough to represent real objects, not one image per slide
- `text_runs` is > 0 and expected text extracts from the deck

If perfect HTML-to-editable conversion is impossible, be direct: complex browser effects cannot be converted automatically, but the deck can be rebuilt as editable PowerPoint-native objects with close visual fidelity.

## Helper

Preferred helper:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/export_pptx.py deck.html exports/deck.pptx
```

The helper:

- opens the HTML deck with Playwright/Chromium
- captures each slide at 1920×1080
- creates a valid 16:9 `.pptx`
- places each rendered PNG full-bleed on its matching slide
- validates the PowerPoint package structure

## Verification

Before delivery:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/export_pptx.py deck.html exports/deck.pptx
python - <<'PY'
from pathlib import Path
import zipfile
p=Path('exports/deck.pptx')
print('exists', p.exists())
print('bytes', p.stat().st_size if p.exists() else 0)
with zipfile.ZipFile(p) as z:
    slides=[n for n in z.namelist() if n.startswith('ppt/slides/slide') and n.endswith('.xml')]
    images=[n for n in z.namelist() if n.startswith('ppt/media/image') and n.endswith('.png')]
    print('slides', len(slides))
    print('images', len(images))
PY
```

Minimum pass:

- file exists
- file size > 0
- zip opens
- slide count matches HTML slide count
- image count matches slide count
- `ppt/presentation.xml` exists
- `ppt/slides/slide1.xml` exists

If available, also open the PPTX in LibreOffice/PowerPoint and export/check a preview PDF.

## Final response

For Telegram/client delivery:

```txt
PowerPoint exported and verified.
MEDIA:/absolute/path/exports/Project_Name_Deck.pptx
```

Mention only if relevant:

```txt
This is a pixel-faithful PPTX, so it visually matches the web/PDF. Slide contents are flattened to preserve the design exactly.
```
