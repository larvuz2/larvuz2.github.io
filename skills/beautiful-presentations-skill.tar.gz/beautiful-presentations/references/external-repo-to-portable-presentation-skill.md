# External repo → portable Hermes presentation skill

Use this when the user points at an external presentation/design repo and asks to implement it “in our stack,” “without Claude,” “using our model,” or as a repeatable skill any Hermes agent/VPS/model can paste and run.

## Durable lesson

The deliverable is not only a local deck or a plan. The real deliverable is a **portable class-level skill package** that preserves the external repo’s objective and design strengths while converting the workflow into Hermes-native, model-agnostic operations.

## Expected output shape

- Rich `SKILL.md` with clear triggers, load order, non-negotiables, workflows, verification, and final response patterns.
- `references/` for design-system analysis, repo adaptation notes, export details, portability checklist, and session-specific implementation notes.
- `templates/` for reusable HTML deck bases or imported visual systems.
- `scripts/` for deterministic helpers: QA, preview publishing, PDF/PPTX/video export, repo setup/sync.
- Public Markdown reader URL for another agent to inspect quickly.
- Optional `.tar.gz` install package for VPS/profile installation.

## Adaptation workflow

1. Inspect the external repo’s goal, UX, design patterns, dependencies, and export assumptions.
2. Extract the class-level objective, not the original tool identity.
3. Remove platform-specific assumptions such as Claude-only commands, hosted artifacts, slash commands, or repo-specific build steps.
4. Convert the workflow to Hermes-native actions that work with normal file, terminal, browser, and GitHub/static-hosting tools.
5. Keep the default artifact browser-first: one self-contained `index.html` per project for client review and feedback.
6. Add optional exports only when asked: PDF, PPTX, video.
7. Package all reusable knowledge as a skill, not as one-off notes.
8. Publish a public skill reader and tarball when the user wants ecosystem reuse.
9. Verify locally and publicly before claiming readiness.

## Handoff test

A good final test is:

- Could a different Hermes agent, on a VPS, using any model, read the public Markdown skill and produce the same class of output?
- Can it install the tarball without needing this conversation?
- Are helper scripts included and executable?
- Are linked references/templates/scripts named in `SKILL.md` so the next agent knows when to open them?
- Does the public URL include the latest files, confirmed with a cache-busted fetch?

## Pitfalls

- Do not ship only a plan when the user asked for a repeatable ecosystem workflow.
- Do not preserve Claude-specific implementation details unless clearly marked as historical inspiration.
- Do not create a narrow one-session skill named after the repo. Update the class-level presentation skill unless no umbrella exists.
- Do not attach raw HTML by default. Publish a preview URL.
- Do not claim public skill readiness until the reader and tarball both include the new files.
