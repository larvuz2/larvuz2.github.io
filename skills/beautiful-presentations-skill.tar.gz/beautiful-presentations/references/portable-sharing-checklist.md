# Portable Sharing Checklist

Use this before sharing the `beautiful-presentations` skill with another Hermes agent/profile/VPS.

## Public reader URL

When sharing with another agent, lead with this URL:

```txt
https://larvuz2.github.io/skills/beautiful-presentations.md
```

That public Markdown file contains the consolidated instructions, key references, base template, and helper scripts so another agent can read and understand the workflow before installing anything.

Full install package:

```txt
https://larvuz2.github.io/skills/beautiful-presentations-skill.tar.gz
```

## What must be included

The skill package must include the full directory, not only `SKILL.md`:

```txt
beautiful-presentations/
  SKILL.md
  templates/base-deck.html
  references/
  scripts/
  assets/
  gallery/                 # if available; optional but preferred for richer design systems
```

## One-time setup the receiving agent/user needs

Pasting/installing the skill is enough to generate local HTML decks, but live review URLs require GitHub auth and a one-time repo setup.

Prerequisites:

- GitHub auth available through `GITHUB_TOKEN`, `GH_TOKEN`, `gh auth login`, or git credentials
- Git installed
- Python 3 available
- Optional but useful: Playwright/Chromium for browser QA and PDF export, ffmpeg for video export

Run once after install:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/setup_presentations_repos.py --owner YOUR_GITHUB_OWNER
```

This creates/checks:

- private source repo: `YOUR_GITHUB_OWNER/presentations`
- public preview mirror: `YOUR_GITHUB_OWNER/YOUR_GITHUB_OWNER.github.io`
- source clone: `~/presentations/shared-repo`
- preview mirror clone: `~/presentations/public-pages-deploy`
- live URL pattern: `https://YOUR_GITHUB_OWNER.github.io/presentations/<project-slug>/`

## Why source and preview are separate

Many GitHub plans do not support Pages directly from private repos. The durable pattern is:

- private `presentations` repo = source, exports, version history
- public `<owner>.github.io` repo = static browser-review mirror

Do not claim the preview URL is private unless access control has been explicitly verified. The default is private source + public review URL.

## Passing validation

A receiving agent passes when it can:

1. Load the skill.
2. Create a one-file 16:9 HTML deck.
3. Put it in `<project-slug>/index.html` inside the private source repo.
4. Sync/publish the mirror if needed.
5. Return a working URL for feedback.
6. Verify navigation and console health.
7. Export PDF only when asked, with true 16:9 pages.

## Good user-facing caveat

Do not say “paste only and everything works perfectly” unless GitHub auth and the shared repo/mirror already exist. Say:

```txt
The skill is portable. For live URLs, the new VPS needs GitHub auth and a one-time setup command. After that, deck generation follows the same structure automatically.
```
