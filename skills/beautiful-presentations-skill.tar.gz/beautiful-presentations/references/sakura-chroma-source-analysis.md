# Sakura Chroma Source Analysis

Source of truth copied from:

```txt
https://github.com/zarazhangrui/beautiful-html-templates/tree/main/templates/sakura-chroma
```

Local source files:

```txt
gallery/beautiful-html-templates/templates/sakura-chroma/template.html
gallery/beautiful-html-templates/templates/sakura-chroma/design.md
gallery/beautiful-html-templates/templates/sakura-chroma/template.json
```

Generated local preview screenshots:

```txt
gallery/beautiful-html-templates/templates/sakura-chroma/screenshots/
```

## What makes the real template work

Sakura Chroma is not just a cream background with rainbow stripes. It works because every slide behaves like a printed cassette/product catalogue page.

Key qualities:

- **Massive editorial type**: Big Shoulders Display is used at brutal scale, with tight line-height and dense lockups.
- **Large empty fields**: the template leaves confident cream-paper negative space instead of filling every region.
- **One dominant composition per slide**: cover, manifesto, product catalogue, quote/ribbon spread, ledger, stats, closing. Each has a different layout logic.
- **Print-object metaphors**: cards feel like catalogue SKUs, rows feel like spec sheets, badges feel like product stickers, checkboxes feel like JIS package markings.
- **Hard geometry**: rectangles, hairline rules, exact borders, no rounded cards, no soft shadows.
- **Flat color blocks**: the color is graphic and printed, not glossy, gradient, or decorative filler.
- **Micro-detail discipline**: mono specs, page numbers, tiny labels, footer metadata, Japanese accent text, and checkbox marks give it authenticity.
- **Compositional asymmetry**: it uses big off-center masses, sweeping ribbons, and large type blocks; it does not center everything like a generic AI deck.

## Where our first test deck failed

The first test was useful as a systems check, but not good enough aesthetically.

Problems:

- It translated the design tokens but not the *composition logic*.
- It overused generic product cards and underused catalogue poster rhythm.
- It made ribbons as decoration instead of structural composition.
- It had too many words trying to explain Gus instead of fewer stronger poster statements.
- It lacked the source template's confident negative space and typographic scale.
- It did not use enough authentic micro-details: SKU labels, product-format rows, edition marks, side labels, package metadata.
- It felt like a themed deck. The reference feels like a real object.

## Implementation rules for future Sakura Chroma decks

1. Start from the real `template.html`, not the generic base deck.
2. Preserve the source composition patterns:
   - cover package spread
   - giant manifesto statement with petal dots
   - four-card product catalogue grid
   - ribbon-backed quote box
   - ledger/spec-sheet rows
   - stat/equalizer spread
   - closing colophon
3. Replace demo content with user/project content, but keep the print-object grammar.
4. Use fewer, stronger phrases. Do not explain everything on every slide.
5. Build visual hierarchy first, content second.
6. Use strict 1920×1080 fixed-stage wrapper for Hermes, but keep the original template's proportions.
7. Never add modern SaaS styling: no glass, no blurred shadows, no rounded cards, no generic gradient backgrounds.
8. Use hard offset shadows only where the source does.
9. Use 16:9 PDF export verification before sending any PDF.
10. Deliver a preview URL, not raw HTML.

## Aesthetic target

The final deck should feel like:

```txt
Japanese cassette catalogue × creative-tech dossier × warm printed product object
```

Not:

```txt
A normal slide deck decorated with Sakura Chroma colors
```
