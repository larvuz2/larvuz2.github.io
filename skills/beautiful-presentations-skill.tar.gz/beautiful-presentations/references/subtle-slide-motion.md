# Subtle Slide Motion

Default HTML decks should feel lightly alive, not animated for its own sake.

## Default motion posture

Use **very subtle, elegant, minimal motion inside each slide** unless the user asks for more.

The goal:

```txt
alive / modern / tactile / calm
```

Not:

```txt
flashy / distracting / keynote gimmick / loading screen
```

## Required defaults

Every generated HTML deck should include:

1. **Slide-entry reveal**
   - Active slide content fades in by 8–24px upward movement.
   - Duration: 500–900ms.
   - Stagger important elements by 60–140ms.
   - Do not delay readability for more than ~1 second.

2. **Subtle living motif motion**
   - Animate background motifs, ribbons, dots, gradients, blobs, or diagram accents very slowly.
   - Movement should be tiny: translate 4–18px, rotate 0.2–1.5deg, or opacity shift 0.05–0.12.
   - Duration: 8–24s.
   - Use alternate/ease-in-out loops.

3. **Interaction tactility**
   - Buttons/cards/controls can have tiny hover transforms: translateY(-1px to -4px), no bouncing.
   - Hover transitions should feel premium and fast: 140–240ms.

4. **Navigation motion**
   - Slide transition should be a quick opacity transition, not a complex wipe unless requested.
   - Do not use `display:none` for active slide switching.

5. **Reduced motion**
   - Always include `@media (prefers-reduced-motion: reduce)`.
   - Disable loops and reduce transitions there.

## Recommended CSS pattern

```css
@keyframes softFloat {
  from { transform: translate3d(0, 0, 0) rotate(0deg); }
  to   { transform: translate3d(10px, -8px, 0) rotate(0.6deg); }
}

@keyframes quietPulse {
  0%, 100% { opacity: .92; }
  50%      { opacity: 1; }
}

.motion-item {
  animation: softFloat 16s ease-in-out infinite alternate;
}

.reveal {
  opacity: 0;
  transform: translateY(18px);
  transition: opacity 700ms cubic-bezier(.16,1,.3,1), transform 700ms cubic-bezier(.16,1,.3,1);
}

.slide.visible .reveal {
  opacity: 1;
  transform: translateY(0);
}

.slide.visible .reveal:nth-child(2) { transition-delay: 80ms; }
.slide.visible .reveal:nth-child(3) { transition-delay: 160ms; }

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation: none !important;
    transition-duration: .01ms !important;
  }
}
```

## Quality rules

- Motion should be nearly invisible when reading, but missed when removed.
- Do not animate large blocks of body text continuously.
- Do not animate every element. Pick 1–3 motif systems per deck.
- For client decks, prioritize calm reviewability over spectacle.
- For cinematic decks, subtle atmospheric motion is acceptable, but keep text stable.
- For PDF/video export, motion must not break static capture.

## Verification

Before delivery:

- open in browser
- check console errors
- navigate slides
- visually inspect that animation does not cover text, jitter, or make the deck feel cheap
- verify `prefers-reduced-motion` CSS exists
