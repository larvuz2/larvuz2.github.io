# PDF Export

Only export PDF when requested. HTML review remains the default.

Preferred helper:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/export_pdf.py deck.html exports/deck.pdf
```

## Hard rule

PDF pages must be true horizontal 16:9 slides, not A4/Letter.

Target page size:

```txt
1920px × 1080px
16:9 landscape
0 margins
one slide per page
```

If the PDF looks like A4, portrait, cropped, unreadable, or tiny, it is broken. Fix export before delivery.

## Verification

Check:

- PDF exists
- PDF is non-empty
- first bytes are `%PDF`
- page size is 16:9 landscape, ideally around `1440 × 810 pts` when reported by `pdfinfo`
- number of pages matches slide count
- controls are hidden
- slides 2+ are readable, not cropped or squeezed

Useful command when available:

```bash
pdfinfo exports/deck.pdf | grep -E 'Pages|Page size'
```

## Browser print fallback

If exporting manually from browser:

- layout: landscape
- paper/page size: custom 16:9 if available
- margins: none
- background graphics: enabled
- scale: fit to printable area or 100%, whichever preserves full slide

Do not deliver a PDF if browser print creates A4/Letter pages.
