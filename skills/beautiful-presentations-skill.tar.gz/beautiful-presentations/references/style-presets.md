# Style Presets

Use one visual system per deck. Do not create color-swap variants unless the user specifically asks.

## Selection rule

- Startup/investor → Founder Pitch
- AI film/fantasy/game/cinematic production → Cinematic Dark
- Product architecture/workflows → Technical Blueprint or AI Control Room
- Client service proposal → Agency Proposal
- Game/IP bible → Game / IP Bible
- Report/memo/editorial review → Editorial Light
- Premium brand/treatment → Luxury Minimal
- SaaS platform/demo → Product Demo

## Cinematic Dark

Use for AI film, fantasy, game worlds, premium tech, dramatic pitches.

- Background: near-black charcoal, deep navy, warm shadow gradients
- Accent: candle gold, ember, ghost blue, bone white
- Type: elegant serif display + precise sans body
- Motif: spotlight cones, soft fog, thin rules, oversized title cards
- Motion: slow fade/blur, subtle parallax, staggered text
- Avoid: crushed blacks, unreadable gray, horror cliché unless requested

Suggested CSS tokens:

```css
:root {
  --stage-bg: #050506;
  --slide-bg: #08080a;
  --ink: #f3efe7;
  --muted: #a8a199;
  --accent: #d6aa62;
  --accent-2: #7ba7ff;
  --panel: rgba(255,255,255,0.055);
  --line: rgba(255,255,255,0.14);
  --font-display: 'Cormorant Garamond', Georgia, serif;
  --font-body: 'IBM Plex Sans', Arial, sans-serif;
}
```

## Founder Pitch

Use for startups, investors, YC-style decks, business strategy.

- Background: off-white or hard dark
- Accent: one sharp color
- Type: bold grotesk headline + clean body
- Motif: big statements, crisp diagrams, labeled proof
- Motion: fast, confident, minimal
- Avoid: corporate jargon, fake metrics, bland blue SaaS

Tokens:

```css
:root {
  --stage-bg: #0b0c0f;
  --slide-bg: #f5f2ea;
  --ink: #111113;
  --muted: #625f59;
  --accent: #ff4d2e;
  --dark: #0b0c0f;
  --line: rgba(17,17,19,0.16);
  --font-display: 'Space Grotesk', Arial, sans-serif;
  --font-body: 'Manrope', Arial, sans-serif;
}
```

## Editorial Light

Use for reports, strategy narratives, cultural projects, thoughtful proposals.

- Background: warm paper/off-white
- Accent: restrained ink, muted red, olive, or blue
- Type: editorial serif headline + humanist sans body
- Motif: columns, pull quotes, margin labels, page numbers
- Motion: gentle staggered text
- Avoid: overdecorated magazine cosplay

Tokens:

```css
:root {
  --stage-bg: #2c2a27;
  --slide-bg: #f4efe5;
  --ink: #191816;
  --muted: #6f685e;
  --accent: #9b3d2f;
  --line: rgba(25,24,22,0.18);
  --font-display: 'Bodoni Moda', Georgia, serif;
  --font-body: 'DM Sans', Arial, sans-serif;
}
```

## Technical Blueprint

Use for architecture, AI workflows, CTO decks, systems.

- Background: graphite/navy
- Accent: cyan, lime, or amber
- Type: technical sans + mono labels
- Motif: grid lines, nodes, arrows, lanes, console labels
- Motion: diagram reveal, line trace, small pulse
- Avoid: fake code walls, illegible tiny labels

Tokens:

```css
:root {
  --stage-bg: #050914;
  --slide-bg: #07111f;
  --ink: #eaf3ff;
  --muted: #8fa3b8;
  --accent: #44f0d2;
  --accent-2: #b7ff5a;
  --panel: rgba(255,255,255,0.055);
  --line: rgba(130,190,255,0.18);
  --font-display: 'Sora', Arial, sans-serif;
  --font-body: 'IBM Plex Sans', Arial, sans-serif;
  --font-mono: 'IBM Plex Mono', monospace;
}
```

## Product Demo

Use for SaaS, platforms, dashboards, app concepts.

- Background: clean off-white or calm dark
- Accent: one product color
- Type: precise sans
- Motif: realistic product frame, cursor path, callout tags, workflow lanes
- Motion: screen reveal, cursor movement, panel focus
- Avoid: fake metric slop and random cards

## Game / IP Bible

Use for games, characters, worlds, gameplay systems.

- Background: dark cinematic or stylized parchment
- Accent: project-specific world color
- Type: bold title + readable body
- Motif: character slots, world map panels, mechanic cards, boss/ally hierarchy
- Motion: energetic cuts, punchy reveals
- Avoid: too kiddy unless requested, cheap cartoon, overloaded lore walls

## Agency Proposal

Use for marketing services, AI production services, retainers, client pitches.

- Background: premium light or dark
- Accent: confident but not gimmicky
- Type: founder-simple, service-clear
- Motif: before/after, workflow pipeline, package tiers, output examples
- Motion: clean reveal
- Avoid: “unlock growth” language, generic service grids

## Luxury Minimal

Use for premium treatments, high-end creative proposals, elegant brands.

- Background: bone, black, deep brown, muted gray
- Accent: gold, oxblood, moss, or cold silver
- Type: refined serif + sparse sans
- Motif: large whitespace, thin rules, quiet asymmetry
- Motion: very subtle
- Avoid: over-glossy, fake luxury, low-contrast gray text

## AI Control Room

Use for AI operations, automation, agents, monitoring, dashboards.

- Background: dark graphite
- Accent: signal green, electric cyan, orange warnings
- Type: technical sans + mono labels
- Motif: live system map, agent cards, status strips, signal timeline
- Motion: pulse, sweep, connection glow
- Avoid: random fake charts, unreadable terminal walls
