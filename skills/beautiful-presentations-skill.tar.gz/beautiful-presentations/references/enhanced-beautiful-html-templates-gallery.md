# Enhanced Beautiful HTML Templates Gallery

Imported from `zarazhangrui/beautiful-html-templates` and duplicated into this Hermes skill as a local, portable template foundation.

## What changed in our stack

- Every template is copied into `gallery/beautiful-html-templates/templates/<slug>/`.
- Every `template.html` has `LRVZ_ENHANCED_TEMPLATE_MOTION v1` CSS injected: quiet reveals, subtle living motif pulse, tactile hover, and reduced-motion safety.
- Every template has the `lrvz-enhanced-template-runtime` injected for wheel navigation fallback.
- Templates using `deck-stage.js` were patched with one-slide-per-scroll wheel navigation.
- These are design foundations, not final client decks. When generating a user deck, inspect the chosen template and adapt its visual grammar into a new self-contained HTML deck.

## Usage rule

When the user asks for a new presentation style, use this gallery as the established design foundation. Pick by mood/tone, inspect `design.md` + `template.html`, then generate a deck that keeps our non-negotiables: one-file HTML, browser-first preview, subtle alive motion, print CSS, and export path.

## Template list

### 8-Bit Orbit (`8-bit-orbit`)

- Mood: retro-tech, playful, cyberpunk, energetic
- Tone: geeky, neon, rebellious, sci-fi
- Best for: Anything that should feel like a CRT screen at 2am: cyberpunk, gaming, web3, indie dev tools, hackathon demos. Just as good for a tech talk that wants to lean into nostalgic-digital craft, a synthwave brand deck, or a creative review that wants to feel like a console.
- Folder: `gallery/beautiful-html-templates/templates/8-bit-orbit`

### Biennale Yellow (`biennale-yellow`)

- Mood: editorial, atmospheric, warm, cultural-institution, poster-like
- Tone: literary, considered, contemplative, warm-modern, Dutch-editorial
- Best for: Anything that should feel like an art-biennale poster or a museum's annual programme: exhibition decks, arts-institution announcements, design conference brochures, curatorial pitches, literary publications, studio retrospectives. Equally good for any deck wanting Dutch-editorial atmosphere with an unmistakable single-color signature.
- Folder: `gallery/beautiful-html-templates/templates/biennale-yellow`

### BlockFrame (`block-frame`)

- Mood: bold, playful, graphic, fresh
- Tone: confident, graphic, pop, design-led
- Best for: Anything that should feel pop-graphic and design-led: indie SaaS launches, agency credentials, creative reviews, brand redesigns. Also a strong unexpected pick for tech, finance, or research when the speaker wants to land as confident and contemporary rather than buttoned-up.
- Folder: `gallery/beautiful-html-templates/templates/block-frame`

### Blue Professional (`blue-professional`)

- Mood: professional, modern, calm, trustworthy
- Tone: clean, considered, polished, neutral
- Best for: Anything that should feel modern-considered and lightly authoritative: B2B SaaS pitches, consulting deliverables, advisory updates, investor reports. Also a clean, tasteful choice whenever you want to read as professional without going stiff — research synthesis, internal reviews, brand work for service businesses.
- Folder: `gallery/beautiful-html-templates/templates/blue-professional`

### Bold Poster (`bold-poster`)

- Mood: bold, editorial, loud, confident
- Tone: dramatic, graphic, sharp, intentional
- Best for: Anything that should land like a magazine cover: brand manifestos, founder vision decks, editorial / cultural pitches, creative reviews. Excellent any time you want a few words to feel like a poster — including unexpected fits like a tech keynote or a finance manifesto that wants to be quotable.
- Folder: `gallery/beautiful-html-templates/templates/bold-poster`

### Broadside (`broadside`)

- Mood: editorial, dramatic, loud, newspaper
- Tone: graphic, punchy, literary, considered
- Best for: Anything that should land like a broadside newspaper headline: brand manifestos, magazine and cultural pitches, design talks, bilingual EN/CN decks, founder vision statements. Also a striking pick for tech, research, or business decks that want a dramatic single-accent editorial feel.
- Folder: `gallery/beautiful-html-templates/templates/broadside`

### Capsule (`capsule`)

- Mood: playful, modern, warm, fresh, fun
- Tone: upbeat, graphic, approachable, cool
- Best for: Anything that should feel modular, modern, and a little Y2K: lifestyle brands, creator portfolios, DTC launches, beauty / wellness, agency credentials. Also fun for a playful tech demo or a research deck that wants pop-art clarity instead of gravitas.
- Folder: `gallery/beautiful-html-templates/templates/capsule`

### Cartesian (`cartesian`)

- Mood: quiet, considered, elegant, warm-minimal
- Tone: classical, literary, restrained, confident-quiet
- Best for: Anything that should feel quiet, considered, and grown-up: investment theses, white papers, advisory work, longform research, gallery / cultural decks. Also a strong choice for editorial features, founder reflections, or any deck where restraint is the message — including across tech and finance.
- Folder: `gallery/beautiful-html-templates/templates/cartesian`

### Cobalt Grid (`cobalt-grid`)

- Mood: editorial, design-research, studious, modernist, tech-print, monochrome
- Tone: considered, literary, studious, quietly-modern, editorial
- Best for: Anything that should feel like a quietly serious design / research bulletin, art publication, or curated trend report. Strong for studio annuals, agency capabilities decks, design-research publications, architecture / art / academic decks, and any deck wanting one strict accent colour and a printed-ledger calmness rather than corporate polish.
- Folder: `gallery/beautiful-html-templates/templates/cobalt-grid`

### Coral (`coral`)

- Mood: bold, warm, modern, confident
- Tone: graphic, punchy, magazine
- Best for: Anything that should feel warm-graphic and editorial: fashion, beauty, fitness, F&B, lifestyle brands, agency credentials. Just as strong for a creator portfolio, a manifesto, or a tech / research deck that wants warmth and a single bold accent instead of corporate cool.
- Folder: `gallery/beautiful-html-templates/templates/coral`

### Creative Mode (`creative-mode`)

- Mood: creative, confident, playful, design-led
- Tone: graphic, expressive, modern
- Best for: Anything that should feel design-led and confident: creative agency pitches, design studio decks, ad shop credentials, brand creative reviews, art-direction reviews. Also a great unexpected pick for a tech talk, research findings, or finance review when the speaker wants to lead with taste rather than convention.
- Folder: `gallery/beautiful-html-templates/templates/creative-mode`

### Daisy Days (`daisy-days`)

- Mood: cheerful, playful, warm, sunny, wholesome
- Tone: friendly, soft, encouraging, approachable, lighthearted
- Best for: Anything that should feel friendly, soft, and joyful: educational content, kids and family, wellness programs, community workshops, creator portfolios for craft / illustration. Also lovely for an unexpected playful internal kickoff, a wedding planning deck, or any moment where warmth is the message — including across tech or business contexts.
- Folder: `gallery/beautiful-html-templates/templates/daisy-days`

### Editorial Forest (`editorial-forest`)

- Mood: editorial, quiet, considered, warm, intentional
- Tone: literary, thoughtful, warm, low-pressure
- Best for: Anything that should feel like a considered editorial — quarterly reviews, internal readouts, studio updates, creative-agency presentations. Equally good for any deck that wants to feel warm and unhurried rather than corporate, including research recaps, book or program announcements, and team retrospectives.
- Folder: `gallery/beautiful-html-templates/templates/editorial-forest`

### Editorial Tri-Tone (`editorial-tri-tone`)

- Mood: editorial, warm, intentional, moody
- Tone: literary, warm, considered, stylish
- Best for: Anything that should feel like a fashion-magazine spread: editorial pitches, fashion brand decks, lifestyle media, art direction reviews. Equally good for any deck — including tech, research, or business — that wants tri-tone discipline and serif/sans contrast instead of the usual neutrals.
- Folder: `gallery/beautiful-html-templates/templates/editorial-tri-tone`

### Emerald Editorial (`emerald-editorial`)

- Mood: editorial, considered, confident, magazine-cover
- Tone: literary, authoritative, warm, designed
- Best for: Anything that should feel like the front of a serious magazine, including but not limited to leadership readouts, planning-office reviews, and strategy briefings. The double-rule masthead ornament gives it editorial gravitas without making it stiff — also a great unexpected pick for product launches or research recaps that want to feel considered rather than corporate.
- Folder: `gallery/beautiful-html-templates/templates/emerald-editorial`

### Grove (`grove`)

- Mood: organic, considered, warm, literary, natural
- Tone: classical, warm, considered, patient
- Best for: Anything that should feel organic, considered, and grown-up: sustainability and wellness brands, outdoor / nature products, wineries and restaurants, literary or arts decks, advisory deliverables, bilingual EN/CN reports. Also a calm, distinctive choice for tech, research, or business decks that want patience over urgency.
- Folder: `gallery/beautiful-html-templates/templates/grove`

### Long Table (`long-table`)

- Mood: warm, intimate, modern, friendly, small-batch, social, hospitality
- Tone: warm, playful, considered, social, magazine-friendly, modern-editorial
- Best for: Anything that should feel like a warm, intimate, modern hospitality / community brand: supper clubs, dinner series, small restaurants, creative-studio events, membership pitches, lifestyle and wine brands. Equally good for any deck wanting a single warm accent colour, mixed-weight typography, and a social-media-aware modern-editorial voice.
- Folder: `gallery/beautiful-html-templates/templates/long-table`

### Mat (`mat`)

- Mood: warm-modern, considered, tactile, mid-century
- Tone: warm, design-led, intentional, considered
- Best for: Anything that should feel mid-century, tactile, and intentional: design studio credentials, architecture / interior brands, ceramics / craft / furniture, advisory decks. Also a warm, distinctive choice for tech, research, or business decks that want a considered analog feel instead of digital-cool.
- Folder: `gallery/beautiful-html-templates/templates/mat`

### Monochrome (`monochrome`)

- Mood: restrained, literary, archival, ledger
- Tone: literary, considered, neutral, honest
- Best for: Anything that should feel like a hand-typeset ledger: user research synthesis, white papers, longform reports, academic and policy briefs, advisory deliverables, bilingual EN/CN reports. Equally good for tech, design, or brand decks that want their words to be the only thing on the page.
- Folder: `gallery/beautiful-html-templates/templates/monochrome`

### Neo-Grid Bold (`neo-grid-bold`)

- Mood: confident, punchy, editorial, modern
- Tone: bold, minimal, design-led, graphic
- Best for: Anything that should feel confident and editorial-graphic: design-led pitches, brand work, founder talks, conference keynotes. Excellent for stat-heavy slides, comparisons, and process flows. Just as strong for tech, research, or finance when the speaker wants to read as design-led rather than corporate.
- Folder: `gallery/beautiful-html-templates/templates/neo-grid-bold`

### People's Platform (Block & Bold) (`peoples-platform`)

- Mood: activist, loud, graphic, honest
- Tone: punchy, direct, expressive, warm-bold
- Best for: Anything that should feel honest, loud, and graphic: cultural commentary, manifestos, civic and community decks, design talks, campaign pitches. Excellent for founder-vision moments, mission statements, or any deck — including across industries — that wants protest-poster energy instead of corporate polish.
- Folder: `gallery/beautiful-html-templates/templates/peoples-platform`

### Pin & Paper (`pin-and-paper`)

- Mood: crafted, handmade, warm, thoughtful, literary
- Tone: literary, intimate, warm, grounded
- Best for: Anything that should feel hand-crafted, warm, and literary: qualitative research findings, founder reflections, longform brand stories, workshop debriefs. The signature safety-pin illustrations and paper-grain texture make it especially good for any deck — including tech or business — that wants personality and warmth over polish.
- Folder: `gallery/beautiful-html-templates/templates/pin-and-paper`

### Pink Script — After Hours (`pink-script`)

- Mood: nocturnal, moody, intentional, luxe, expressive
- Tone: literary, sultry, considered, magazine
- Best for: Anything that should feel nocturnal, intentional, and a little luxe: fashion brand decks, creator personal brands, after-hours / nightlife / spirits launches, luxury product reveals, editorial features. Also a striking unexpected pick for a tech keynote, research synthesis, or business pitch that wants to land with magnetic confidence.
- Folder: `gallery/beautiful-html-templates/templates/pink-script`

### Playful (`playful`)

- Mood: warm, approachable, indie, friendly
- Tone: upbeat, informal, welcoming
- Best for: Anything that should feel warm, indie, and approachable: creator portfolios, indie product launches, lifestyle brands, small-business pitches, newsletter / community decks. Also welcoming for any deck — including tech or research — that wants to feel friendly and human rather than corporate.
- Folder: `gallery/beautiful-html-templates/templates/playful`

### Raw Grid (`raw-grid`)

- Mood: raw, punchy, energetic, confident
- Tone: direct, modern, no-nonsense, graphic
- Best for: Anything that should feel direct and graphic-confident: founder pitches, accelerator demos, brand decks, indie launches, creator portfolios. Strong for stat slides, comparison tables, and process flows. Equally good for tech, research, or finance when the speaker wants the deck to feel scrappy-confident rather than buttoned-up.
- Folder: `gallery/beautiful-html-templates/templates/raw-grid`

### Retro Windows (`retro-windows`)

- Mood: nostalgic, retro, geeky, playful
- Tone: winking, nostalgic, geeky, fun
- Best for: Anything that should feel knowingly nostalgic: retro gaming, Y2K-aesthetic brands, creator portfolios with a 90s vibe, tech-history talks, deliberately tongue-in-cheek decks. A great choice anywhere a playful retro reference is the entire point.
- Folder: `gallery/beautiful-html-templates/templates/retro-windows`

### Retro Zine (`retro-zine`)

- Mood: crafted, lo-fi, underground, warm-retro
- Tone: scrappy, warm, intentional, DIY
- Best for: Anything that should feel printed, lo-fi, and crafted: indie zines and publications, music / arts brands, creator portfolios, small-batch craft launches, community decks. Also a great underdog choice for tech, research, or business decks that want a riso-print warmth instead of digital polish.
- Folder: `gallery/beautiful-html-templates/templates/retro-zine`

### Sakura Chroma (`sakura-chroma`)

- Mood: retro, playful, kawaii-tech, warm, tactile, product-catalogue
- Tone: playful, confident, warm, tactile, 80s-Japanese-tech
- Best for: Anything that should feel like a vintage Japanese cassette package or a TDK / Sony / Sakura Color product catalogue: indie hardware brand decks, music-label release schedules, analog studio retrospectives, zine and magazine pitches, kawaii-tech product launches, creative-studio annual reports. Equally good for any deck wanting bold colour, condensed display type, and a tactile printed-product personality.
- Folder: `gallery/beautiful-html-templates/templates/sakura-chroma`

### Scatterbrain (`scatterbrain`)

- Mood: playful, creative, warm, messy-on-purpose, workshop
- Tone: informal, warm, expressive, human
- Best for: Anything that should feel like a designer's whiteboard: brainstorms, workshops, creative-agency credentials, design-thinking sessions, ideation pitches, art-direction reviews. Equally fun for any deck — including tech, research, or business — that wants to read as in-progress thinking rather than polished conclusions.
- Folder: `gallery/beautiful-html-templates/templates/scatterbrain`

### Signal (`signal`)

- Mood: institutional, trustworthy, considered, weighty
- Tone: sober, polished, established, literary
- Best for: Anything that should feel weighty, considered, and credibly institutional: investor decks, board presentations, consulting deliverables, legal / policy briefs, advisory pitches. Also a strong choice for tech, research, or brand work that wants to read as quietly authoritative rather than loud.
- Folder: `gallery/beautiful-html-templates/templates/signal`

### Soft Editorial (`soft-editorial`)

- Mood: literary, elegant, quiet, warm-classical
- Tone: literary, considered, warm, magazine
- Best for: Anything that should feel literary, elegant, and unhurried: editorial features, longform brand stories, gallery / museum decks, advisory deliverables, wedding / lifestyle media, founder essays. Equally good for tech, research, or business decks that want a Sunday-supplement warmth instead of corporate polish.
- Folder: `gallery/beautiful-html-templates/templates/soft-editorial`

### Stencil & Tablet (`stencil-tablet`)

- Mood: archival, earthy, tactile, considered, graphic
- Tone: weighty, considered, tactile, literary
- Best for: Anything that should feel archival, tactile, and weighty-graphic: museum and cultural-institution decks, art / architecture brands, longform research, heritage and craft brands, manifestos. A great choice anytime — including across tech and business — when you want the deck to feel like a field manual rather than a slide deck.
- Folder: `gallery/beautiful-html-templates/templates/stencil-tablet`

### Studio (`studio`)

- Mood: electric, bold, graphic, design-led, high-contrast
- Tone: graphic, loud, modern, intentional
- Best for: Anything that should feel electric and design-led: studio credentials, creative agency pitches, brand showcases, art-direction reviews, fashion / sneaker brand work. Also a striking unexpected choice for tech, research, or business decks where the speaker wants the deck to *be* a brand statement.
- Folder: `gallery/beautiful-html-templates/templates/studio`

### Vellum (`vellum`)

- Mood: scholarly, literary, considered, quiet, intellectual
- Tone: literary, considered, patient, intelligent
- Best for: Anything that should feel scholarly, literary, and quietly intelligent: research synthesis, white papers, academic and policy briefs, advisory deliverables, longform editorial pieces, founder reflections. Equally strong for any deck — including tech, business, or creator work — that wants a calm, considered atmosphere instead of energetic visuals.
- Folder: `gallery/beautiful-html-templates/templates/vellum`
