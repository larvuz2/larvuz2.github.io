# Video Export

Only export video when requested.

Preferred helper:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/export_video.py deck.html exports/deck.mp4 --seconds-per-slide 5
```

## MVP behavior

- open HTML deck at 1920×1080
- count `.slide` elements
- show each slide using `window.deck.show(index)` or class toggling fallback
- screenshot each slide as PNG
- assemble MP4 with ffmpeg

## Verification

After export:

- MP4 exists
- size > 0
- `ffprobe` or `file` identifies video
- duration roughly equals slide count × seconds per slide

## Notes

Static slide video is acceptable as the default export. Animated capture can be added later, but must be tested because browser animation recording is more fragile.
