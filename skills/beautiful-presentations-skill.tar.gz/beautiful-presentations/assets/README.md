# Beautiful Presentations Assets

Put local project assets here only when packaging a reusable example.

For real client/project decks, create a project folder near the work product:

```txt
/project-name/
├── Project_Name_Deck.html
├── assets/
└── exports/
```

Generated decks should stay self-contained when practical. If image assets are required, use relative paths and keep them beside the HTML file.
