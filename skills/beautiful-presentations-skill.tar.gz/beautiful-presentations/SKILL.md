---
name: beautiful-presentations
description: Create stunning one-file HTML presentations with horizontal 16:9 slides, browser-first review, optional PDF export, optional video export, PPTX conversion, and high-design visual direction. Use for decks, pitches, proposals, product explainers, client presentations, investor decks, game bibles, film treatments, and project reviews.
version: 1.0.0
author: Larvuz / Hermes
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [presentations, slides, html, pdf, video, deck, design, pitch, frontend, client-review]
    related_skills: [claude-design, powerpoint, document-export-delivery]
---

# Beautiful Presentations

Use this skill whenever the user asks for a deck, slides, presentation, pitch deck, client proposal, visual explainer, HTML deck, PDF slides, or presentation video.

The default artifact is always a **single self-contained HTML file** for browser review.

Delivery rule: **never send or attach the raw HTML file unless the user explicitly asks for the file.** HTML attachments are bad for client review on chat platforms. Instead, publish/serve the HTML and send a preview URL.

PDF and video exports are optional. Create them only when the user asks.

This is Hermes-native. Do not assume Claude Code, Claude plugins, hosted artifacts, or special slash commands. It must work in any Hermes agent/profile/model with normal file, terminal, and browser tools.

## Core objective

Create beautiful, polished, zero-build presentations that run directly in the browser.

Default output:

```txt
project-name-deck.html
```

Optional outputs:

```txt
exports/project-name-deck.pdf
exports/project-name-deck.mp4
```

## Load order for linked files

Use only what the task needs:

- New HTML deck → read `templates/base-deck.html`, then `references/style-presets.md` and `references/slide-patterns.md`.
- User asks for styles, templates, examples, options, or a new design direction → read `references/enhanced-beautiful-html-templates-gallery.md` first, then inspect the selected template folder before generating final slides.
- User asks to improve, publish, or QA the public visual template gallery → read `references/visual-template-gallery.md`; use live HTML embeds by default, one visible label per card, and cache-busting verification after GitHub Pages pushes.
- User asks for the older bold/template gallery → read `references/bold-template-gallery.md`, then inspect the selected template folder before generating final slides.
- User asks specifically for Sakura Chroma, cassette-package, Japanese product-catalogue, or bold diagonal-ribbon style → read `references/sakura-chroma-source-analysis.md`, then inspect `gallery/beautiful-html-templates/templates/sakura-chroma/template.html` and `design.md` before generating final slides.
- HTML delivery → read `references/github-pages-preview-delivery.md` and `references/shared-presentations-repo.md`; use the single shared private presentations repo as the source of truth, with a public static preview mirror only when private GitHub Pages is unsupported; never attach raw HTML unless explicitly requested.
- Client-review preview/navigation expectations → read `references/client-review-preview-and-navigation.md`; live URL first, shared repo-backed preview, scroll wheel changes slides.
- Fallback non-GitHub delivery → use `scripts/publish_preview.py` only when GitHub is unavailable or the user asks for another host.
- Private-source/public-preview sync → use `scripts/sync_private_presentations_mirror.py` after pushing the private `presentations` source repo when GitHub Pages is unsupported for private repos.
- Any HTML deck motion/interactivity → read `references/subtle-slide-motion.md`; default decks need very subtle alive motion even when not animation-heavy.
- Animation-heavy deck → also read `references/animation-patterns.md`.
- PDF export → read `references/pdf-export.md`, use `scripts/export_pdf.py` if present.
- Video export → read `references/video-export.md`, use `scripts/export_video.py` if present.
- PPTX / PowerPoint export from HTML → read `references/pptx-export.md`, use `scripts/export_pptx.py` if present.
- PPTX conversion from an existing PowerPoint file → read `references/pptx-conversion.md`, use `scripts/extract_pptx.py` if present.
- Installing, packaging, or verifying the skill on another Hermes profile/VPS → read `references/installation-and-verification.md`; run `scripts/setup_presentations_repos.py` once if the shared private source repo / public preview mirror do not exist yet.
- Sharing the skill with another agent/user/VPS or answering “is it ready to paste?” → read `references/portable-sharing-checklist.md` and `references/agent-handoff-message-pattern.md`; keep the chat handoff extremely brief because the details belong in the public Markdown skill file.
- Adapting, refreshing, or enhancing an external presentation/design repo into this Hermes skill → read `references/repo-adaptation-and-portability.md` and `references/enhanced-template-gallery-maintenance.md`; duplicate the templates into the skill, inject subtle motion/runtime polish, patch wheel navigation where needed, and verify locally/publicly before claiming it is ready.
- Final portability test for a pasteable skill that any Hermes agent/model can run → read `references/portable-skill-paste-test.md`.
- Improving this skill or evaluating output quality → read `references/ramp-up-plan.md`.

## Non-negotiable format rules

Every generated HTML deck must use:

- one self-contained `.html` file
- preview URL delivery by default; raw HTML attachment only when explicitly requested
- inline CSS
- inline JavaScript
- fixed 16:9 horizontal slide stage
- authored slide size: `1920px × 1080px`
- uniform stage scaling to fit browser viewport
- no responsive reflow inside slides
- no slide scrolling
- keyboard navigation
- mouse wheel / trackpad scroll navigation: scrolling down advances one slide; scrolling up returns one slide
- touch/swipe navigation when practical
- visible slide counter or progress indicator outside the slide stage
- print CSS for one slide per PDF page
- controls hidden in print/export
- subtle default within-slide motion: quiet reveal, tiny motif drift/pulse, premium hover tactility
- `prefers-reduced-motion` handling for animated decks

Do not switch slides with `display: none` / `display: block`.

Use `visibility`, `opacity`, and `pointer-events` for slide state.

## Required base structure

Every generated deck should follow this structure:

```html
<div class="deck-viewport">
  <main class="deck-stage" id="deckStage">
    <section class="slide active visible" data-slide="1">
      <!-- slide content -->
    </section>
    <section class="slide" data-slide="2">
      <!-- slide content -->
    </section>
  </main>
</div>

<nav class="deck-controls" aria-label="Presentation controls">
  <button id="prevSlide">Prev</button>
  <span id="slideCounter">1 / 10</span>
  <button id="nextSlide">Next</button>
</nav>
```

Use `templates/base-deck.html` as the structural source of truth.

## Before designing

Detect the mode:

1. New deck
2. Redesign/enhancement of existing HTML deck
3. PPTX conversion
4. PDF export
5. Video export

Then identify:

- audience
- purpose
- density: live presentation or async reading
- slide count, if specified
- brand/project context
- visual posture
- export requirements

Do not ask too many questions. If the user gives enough context, proceed.

Useful single question when required:

```txt
Is this deck for live presenting or async reading?
```

If no answer is available, default to:

- async review / reading-first for client decks
- speaker-led for keynotes and cinematic pitches
- hybrid for investor decks

## Content discipline

Each slide needs one clear job.

Avoid filler. Do not invent fake metrics, fake client quotes, fake traction, fake logos, or unsupported claims.

If data is missing, use labeled placeholders:

```txt
[Metric placeholder]
[Client logo placeholder]
[Insert current traction]
```

If a slide is too dense, split it into two slides. Do not shrink text until it becomes ugly.

## Density modes

### Speaker-led deck

Use for keynotes, live pitches, cinematic proposals, and narrated presentations.

Rules:

- one idea per slide
- huge title type
- 1–3 bullets max
- strong visual rhythm
- more slides beats cramped slides

### Reading-first deck

Use for client async review, internal memos, reports, proposals, and handouts.

Rules:

- self-contained slides
- structured grids/cards allowed
- 4–8 bullets max if readable
- clear section labels
- still no cramped text

## Visual standards

The deck must feel custom.

Avoid:

- generic AI purple gradients
- default SaaS cards
- random icon grids
- overused Inter/Roboto-only typography
- weak centered layouts
- tiny text
- overfilled slides
- decorative stats
- meaningless dashboard visuals
- fake glassmorphism everywhere
- low contrast
- clutter

Prefer:

- strong type scale
- one dominant visual motif
- cinematic spacing
- elegant hierarchy
- precise grids
- custom palette
- abstract shapes
- editorial layouts
- atmospheric backgrounds
- tasteful animation
- real diagrams when useful
- strong opening and closing slides

## Style presets

Choose one style direction unless the user asks for options. See `references/style-presets.md`.

If the user asks for templates, visual examples, “show me styles,” or wants a new design direction, use the enhanced imported template foundation first:

- Read `references/enhanced-beautiful-html-templates-gallery.md`.
- Offer 3–6 relevant options by name, mood, and best use.
- If the user chooses one, inspect the corresponding folder under `gallery/beautiful-html-templates/templates/` before generating.
- Reuse the visual system, motion polish, layout grammar, colors, and template logic. Do not clone demo content.
- The older Bold Template Gallery remains available as secondary reference, but the enhanced `beautiful-html-templates` gallery is the primary design foundation.

Default families:

- Cinematic Dark
- Founder Pitch
- Editorial Light
- Technical Blueprint
- Product Demo
- Game / IP Bible
- Agency Proposal
- Luxury Minimal
- AI Control Room
- Imported Bold Template Gallery

## Slide structure patterns

Use `references/slide-patterns.md`. Prefer designed compositions over bullet slides.

Common patterns:

- title / promise
- problem contrast
- before → after
- big claim + proof
- 3-part system
- timeline
- process flow
- architecture map
- feature anatomy
- cinematic mood board
- offer/package slide
- roadmap
- decision slide
- final ask

## Animation rules

Use motion with discipline. See `references/subtle-slide-motion.md` for default alive motion and `references/animation-patterns.md` for heavier motion systems.

Default for every HTML deck:

- very subtle within-slide animation so the page feels alive and interactive
- quiet entry reveals for slide content
- slow motif drift/pulse on 1–3 decorative systems only
- tiny hover/tactile motion for cards/buttons/controls
- motion must feel premium, minimal, and easy to ignore while reading

Good:

- staggered reveals
- subtle scale/fade
- tiny background/motif drift
- diagram line reveal
- section transition
- slow atmospheric background motion
- counter animation if real data exists

Bad:

- chaotic motion everywhere
- slow animations that block reading
- random floating objects
- large body text moving continuously
- heavy effects that hurt export
- animation that hides weak layout

Always support reduced motion.

## Output workflow

### Step 1 — Create outline

Before writing HTML, create a concise working slide outline:

```txt
01 — Title / promise
02 — Problem
03 — Why now
04 — Solution
05 — How it works
06 — Product/workflow
07 — Proof/examples
08 — Business model/offer
09 — Roadmap/next steps
10 — Ask
```

Adapt to the user's actual topic.

### Step 2 — Choose visual system

Define:

- palette
- typography
- spacing
- motif
- motion
- density
- slide rhythm

### Step 3 — Write the HTML

Create a complete `.html` file.

Rules:

- no markdown-only deck
- no partial snippets
- no external build
- no missing CSS
- no missing JS
- no broken navigation
- no text too small for 1920×1080 slides
- wheel/trackpad navigation uses throttling/debouncing so a single scroll gesture does not skip multiple slides
- wheel navigation must call `preventDefault()` in the active deck viewport to avoid page rubber-banding or accidental browser scroll

### Step 4 — Verify

If tools are available, verify before final response.

Minimum:

- file exists
- file is non-empty
- HTML contains `.deck-stage`
- HTML contains `.slide`
- HTML contains print CSS
- HTML contains JS controller

Better:

- open in browser
- check console errors
- navigate slides
- inspect screenshot of every slide, especially high-design layouts
- verify controls do not cover important content in the preview screenshot
- fix visual overlap even if DOM overflow checks pass
- test print mode if exporting PDF

Use `scripts/qa_html_deck.py` when available.

Do not claim browser verification unless actually performed.

## Preview URL delivery

Default delivery is a URL, not an HTML attachment.

Hard rule: **do not create a new GitHub repository for every deck.** Use one shared **private** presentations repository for all HTML deck previews unless the user explicitly requests a separate repo.

Preferred shared repo:

```txt
https://github.com/larvuz2/presentations
https://larvuz2.github.io/presentations/<project-slug>/
```

If working on a different GitHub owner/profile, create or reuse one central **private** repo named `presentations` and publish each deck inside its own slug folder:

```txt
/<project-slug>/index.html
/<project-slug>/exports/<project-name>.pdf
/<project-slug>/exports/<project-name>.mp4
```

Keep any old per-deck repos as legacy unless the user explicitly confirms deletion.

Important: the repository should be private, but GitHub Pages previews may still be public depending on GitHub account/plan/settings. Treat the repo privacy as protection for source/version history; do not assume a Pages URL is access-controlled unless verified.

After creating and verifying the HTML file:

1. Clone or reuse the shared private source repo. If this is a new VPS/user, first run `scripts/setup_presentations_repos.py --owner <github-owner>` to create/check the private source repo and public preview mirror.
2. Create/update a clean folder for the deck slug in the private source repo, e.g. `gus-sakura-chroma/index.html`.
3. Commit and push the private source repo.
4. If GitHub Pages from the private repo is unsupported, sync the static files into the public preview mirror using `scripts/sync_private_presentations_mirror.py`.
5. Poll the live preview URL until it returns HTTP 200.
6. Browser-check the live preview URL.
7. Send the live preview URL first.
8. Mention repo privacy and local path only as backup/debug info.
9. Do **not** attach `MEDIA:/path/deck.html` unless the user explicitly asks for the raw file.

Preferred preview methods, in order:

1. Shared `presentations` GitHub Pages repo with one folder per deck.
2. Existing project GitHub Pages/static deployment pipeline.
3. Project/VPS public preview directory if GitHub is unavailable.
4. Temporary static server with a reachable public domain/tunnel.
5. If no public URL is available, say the preview URL is blocked and ask whether to configure GitHub Pages or another preview host; still keep the verified HTML locally.

Fallback helper if GitHub is unavailable:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/publish_preview.py deck.html --slug project-name
```

A good final response for HTML is:

```txt
Preview: https://preview-domain/path/Project_Name_Deck.html
Verified: 10 slides, navigation works, no console errors, no overflow.
Local backup: /absolute/path/Project_Name_Deck.html
```

Bad final response:

```txt
MEDIA:/absolute/path/Project_Name_Deck.html
```

## PDF export

Only export PDF when requested.

Preferred helper:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/export_pdf.py deck.html exports/deck.pdf
```

Verify:

- file exists
- file size > 0
- file begins with `%PDF`
- controls are hidden by print/export CSS

If Chromium/Playwright is unavailable, explain the blocker and keep the HTML ready for browser print export.

## Video export

Only export video when requested.

Preferred helper:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/export_video.py deck.html exports/deck.mp4 --seconds-per-slide 5
```

Preferred MVP:

1. Open deck at 1920×1080.
2. Capture one PNG per slide.
3. Use ffmpeg to assemble MP4.

Verify:

- MP4 exists
- file size > 0
- `ffprobe` or `file` identifies video
- duration roughly matches slide count × seconds per slide

If animated browser capture is available, use it. Otherwise, static slide video is acceptable as first export.

## PPTX / PowerPoint export

Only export `.pptx` when requested.

If the user asks for a PowerPoint file, `.pptx`, or downloadable PowerPoint version, do it.

Default to a pixel-faithful PPTX: render each approved HTML slide at `1920×1080` and place it full-bleed on a matching 16:9 PowerPoint slide. This is the correct default when the user expects the PowerPoint to look the same as the web/PDF deck after opening or importing into PowerPoint, Keynote, or Google Slides.

Preferred helper:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/export_pptx.py deck.html exports/deck.pptx
```

Verify:

- `.pptx` exists
- file size > 0
- zip package opens
- slide count matches the HTML deck
- image count matches slide count
- `ppt/presentation.xml` exists
- `ppt/slides/slide1.xml` exists

If the user explicitly asks for editable PowerPoint objects, explain the tradeoff: editable PPTX may not match exactly; pixel-faithful PPTX matches the design but flattens slide contents.

## PPTX conversion

Use this mode when the user provides an existing `.pptx` to convert, redesign, or improve.

Process:

1. Extract text, notes, and images.
2. Preserve slide order.
3. Identify hierarchy.
4. Redesign into HTML instead of cloning ugly PowerPoint layouts.
5. Keep important content accurate.
6. Mark uncertain extraction clearly.
7. Verify output against extracted outline.

Useful helper:

```bash
python ~/.hermes/skills/creative/beautiful-presentations/scripts/extract_pptx.py source.pptx extracted/
```

If extraction tooling is missing, try `python -m markitdown source.pptx` or ask the user for exported text/images.

## File naming

Use clean names:

```txt
Project_Name_Deck.html
Project_Name_Deck_v2.html
exports/Project_Name_Deck.pdf
exports/Project_Name_Deck.pptx
exports/Project_Name_Deck.mp4
```

For revisions, preserve prior versions unless the user asks to overwrite.

## Final response format

Keep final response short.

For HTML:

```txt
Preview: https://preview-domain/path/Project_Name_Deck.html
Verified: file exists, navigation works, no console errors, no overflow.
Local backup: /absolute/path/Project_Name_Deck.html
```

Never attach raw HTML with `MEDIA:` unless the user explicitly asks for the `.html` file.

For PDF:

```txt
Exported: /absolute/path/exports/Project_Name_Deck.pdf
Verified: PDF exists and is non-empty.
```

For PowerPoint:

```txt
Exported: /absolute/path/exports/Project_Name_Deck.pptx
Verified: PPTX exists, opens as a valid package, and slide/image count matches the HTML deck.
```

For video:

```txt
Exported: /absolute/path/exports/Project_Name_Deck.mp4
Verified: MP4 exists and is playable.
```

If delivering through Telegram or another gateway, attach exported files with:

```txt
MEDIA:/absolute/path/file.pdf
MEDIA:/absolute/path/file.pptx
MEDIA:/absolute/path/file.mp4
```

## Quality bar

The deck is not done if it looks like generic AI output.

The deck is done when:

- the first slide has impact
- the visual system is coherent
- each slide has one clear job
- the type scale is strong
- spacing is intentional
- text is readable
- navigation works
- export path is ready
- the file can be opened directly by the user/client
