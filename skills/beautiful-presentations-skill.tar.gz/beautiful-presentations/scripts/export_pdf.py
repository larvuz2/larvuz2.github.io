#!/usr/bin/env python3
"""Export a Beautiful Presentations HTML deck to PDF.

Usage:
    python export_pdf.py deck.html exports/deck.pdf
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path


def file_url(path: Path) -> str:
    return path.resolve().as_uri()


def verify_pdf(path: Path) -> None:
    if not path.exists():
        raise RuntimeError(f"PDF was not created: {path}")
    if path.stat().st_size <= 0:
        raise RuntimeError(f"PDF is empty: {path}")
    with path.open("rb") as handle:
        header = handle.read(4)
    if header != b"%PDF":
        raise RuntimeError(f"Output does not look like a PDF: {path}")


def export_with_playwright(html_path: Path, pdf_path: Path) -> bool:
    try:
        from playwright.sync_api import sync_playwright  # type: ignore
    except Exception:
        return False

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)
        page.goto(file_url(html_path), wait_until="networkidle")
        page.emulate_media(media="print")
        page.add_style_tag(content="""
          @page { size: 1920px 1080px; margin: 0; }
          html, body { width: 1920px !important; margin: 0 !important; padding: 0 !important; }
          .deck-controls, .review-tools, .export-tools { display: none !important; }
          .deck-viewport { position: static !important; width: 1920px !important; overflow: visible !important; }
          .deck-stage { position: static !important; transform: none !important; width: 1920px !important; height: auto !important; overflow: visible !important; }
          .slide { position: relative !important; display: block !important; visibility: visible !important; opacity: 1 !important; pointer-events: auto !important; width: 1920px !important; height: 1080px !important; overflow: hidden !important; break-after: page !important; page-break-after: always !important; }
          .slide:last-child { break-after: auto !important; page-break-after: auto !important; }
        """)
        page.pdf(
            path=str(pdf_path),
            print_background=True,
            landscape=True,
            width="1920px",
            height="1080px",
            margin={"top": "0", "right": "0", "bottom": "0", "left": "0"},
            prefer_css_page_size=False,
        )
        browser.close()
    verify_pdf(pdf_path)
    return True


def find_browser() -> str | None:
    candidates = [
        "chromium",
        "chromium-browser",
        "google-chrome",
        "google-chrome-stable",
        "microsoft-edge",
        "brave-browser",
    ]
    for name in candidates:
        found = shutil.which(name)
        if found:
            return found
    return None


def export_with_browser_binary(html_path: Path, pdf_path: Path) -> bool:
    browser = find_browser()
    if not browser:
        return False
    user_data_dir = pdf_path.parent / ".pdf-browser-profile"
    user_data_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        browser,
        "--headless=new",
        "--disable-gpu",
        "--no-sandbox",
        f"--user-data-dir={user_data_dir}",
        f"--print-to-pdf={pdf_path}",
        "--print-to-pdf-no-header",
        file_url(html_path),
    ]
    subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    verify_pdf(pdf_path)
    return True


def main() -> int:
    parser = argparse.ArgumentParser(description="Export a one-file HTML deck to PDF.")
    parser.add_argument("html", help="Input deck.html")
    parser.add_argument("pdf", help="Output deck.pdf")
    args = parser.parse_args()

    html_path = Path(args.html).expanduser().resolve()
    pdf_path = Path(args.pdf).expanduser().resolve()

    if not html_path.exists():
        print(f"ERROR: HTML file not found: {html_path}", file=sys.stderr)
        return 2
    if html_path.suffix.lower() not in {".html", ".htm"}:
        print(f"ERROR: input is not an HTML file: {html_path}", file=sys.stderr)
        return 2

    pdf_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        if export_with_playwright(html_path, pdf_path):
            print(f"Exported with Playwright: {pdf_path}")
            return 0
    except Exception as exc:
        print(f"Playwright export failed: {exc}", file=sys.stderr)

    try:
        if export_with_browser_binary(html_path, pdf_path):
            print(f"Exported with browser binary: {pdf_path}")
            return 0
    except Exception as exc:
        print(f"Browser binary export failed: {exc}", file=sys.stderr)

    print(
        "ERROR: PDF export needs Playwright Chromium or a local headless browser "
        "(chromium/google-chrome/etc.). HTML remains browser-printable.",
        file=sys.stderr,
    )
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
