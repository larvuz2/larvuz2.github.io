#!/usr/bin/env python3
"""Create/check the shared presentations repo structure for browser-first deck previews.

Default pattern:
- private source repo: <owner>/presentations
- public deploy mirror: <owner>/<owner>.github.io
- live URLs: https://<owner>.github.io/presentations/<project-slug>/

This script is intentionally model-neutral and uses only git + GitHub REST.
It reads auth from either GITHUB_TOKEN/GH_TOKEN or git credential fill.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import urllib.error
import urllib.request
from pathlib import Path


def run(cmd: list[str], cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess[str]:
    proc = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True)
    if check and proc.returncode != 0:
        raise SystemExit(
            f"Command failed: {' '.join(cmd)}\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
        )
    return proc


def get_token() -> str:
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if token:
        return token
    proc = subprocess.run(
        ["git", "credential", "fill"],
        input="protocol=https\nhost=github.com\n\n",
        text=True,
        capture_output=True,
    )
    if proc.returncode == 0:
        values = dict(line.split("=", 1) for line in proc.stdout.splitlines() if "=" in line)
        if values.get("password"):
            return values["password"]
    raise SystemExit("No GitHub token found. Set GITHUB_TOKEN/GH_TOKEN or configure git credentials for github.com.")


def api(token: str, method: str, path: str, data: dict | None = None) -> tuple[int, dict]:
    body = None if data is None else json.dumps(data).encode()
    req = urllib.request.Request(
        "https://api.github.com" + path,
        data=body,
        method=method,
        headers={
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github+json",
            "Content-Type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode() or "{}"
            return resp.status, json.loads(raw)
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode(errors="ignore")
        try:
            payload = json.loads(raw)
        except Exception:
            payload = {"raw": raw}
        return exc.code, payload


def ensure_repo(token: str, owner: str, repo: str, private: bool, description: str) -> dict:
    status, payload = api(token, "GET", f"/repos/{owner}/{repo}")
    if status == 404:
        status, payload = api(
            token,
            "POST",
            "/user/repos",
            {"name": repo, "private": private, "description": description, "auto_init": False},
        )
        if status not in (200, 201):
            raise SystemExit(f"Could not create {owner}/{repo}: {status} {payload}")
    elif status != 200:
        raise SystemExit(f"Could not inspect {owner}/{repo}: {status} {payload}")

    if bool(payload.get("private")) != private:
        status, payload = api(token, "PATCH", f"/repos/{owner}/{repo}", {"private": private})
        if status != 200:
            raise SystemExit(f"Could not set {owner}/{repo} private={private}: {status} {payload}")
    return payload


def ensure_clone(owner: str, repo: str, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        run(["git", "clone", f"https://github.com/{owner}/{repo}.git", str(path)], check=False)
    if not (path / ".git").exists():
        path.mkdir(parents=True, exist_ok=True)
        run(["git", "init"], cwd=path)
        run(["git", "checkout", "-B", "main"], cwd=path)
        run(["git", "remote", "remove", "origin"], cwd=path, check=False)
        run(["git", "remote", "add", "origin", f"https://github.com/{owner}/{repo}.git"], cwd=path)


def ensure_public_pages(token: str, owner: str, repo: str) -> None:
    status, payload = api(token, "GET", f"/repos/{owner}/{repo}/pages")
    if status == 200:
        return
    status, payload = api(token, "POST", f"/repos/{owner}/{repo}/pages", {"source": {"branch": "main", "path": "/"}})
    if status not in (200, 201, 204):
        print(f"Warning: could not enable Pages for {owner}/{repo}: {status} {payload}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--owner", required=True, help="GitHub owner/user/org, e.g. larvuz2")
    parser.add_argument("--source-repo", default="presentations")
    parser.add_argument("--deploy-repo", help="Default: <owner>.github.io")
    parser.add_argument("--source-path", default="~/presentations/shared-repo")
    parser.add_argument("--deploy-path", default="~/presentations/public-pages-deploy")
    args = parser.parse_args()

    owner = args.owner
    deploy_repo = args.deploy_repo or f"{owner}.github.io"
    token = get_token()

    source = ensure_repo(
        token,
        owner,
        args.source_repo,
        True,
        "Private source repo for shared browser-first HTML presentations.",
    )
    deploy = ensure_repo(
        token,
        owner,
        deploy_repo,
        False,
        "Public GitHub Pages deployment mirror for presentation review URLs.",
    )

    source_path = Path(args.source_path).expanduser().resolve()
    deploy_path = Path(args.deploy_path).expanduser().resolve()
    ensure_clone(owner, args.source_repo, source_path)
    ensure_clone(owner, deploy_repo, deploy_path)

    # If the public deploy repo is empty, make one initial commit so Pages can enable.
    if not any(p.name != ".git" for p in deploy_path.iterdir()):
        (deploy_path / "index.html").write_text(
            "<!doctype html><meta charset='utf-8'><title>Presentations</title><a href='/presentations/'>Presentations</a>\n"
        )
        run(["git", "add", "."], cwd=deploy_path)
        run(["git", "commit", "-m", "chore: initialize pages deploy repo"], cwd=deploy_path)
        run(["git", "push", "-u", "origin", "main"], cwd=deploy_path)

    ensure_public_pages(token, owner, deploy_repo)

    print(json.dumps({
        "source_repo": source.get("html_url"),
        "source_private": source.get("private"),
        "source_path": str(source_path),
        "deploy_repo": deploy.get("html_url"),
        "deploy_private": deploy.get("private"),
        "deploy_path": str(deploy_path),
        "pages_root": f"https://{owner}.github.io/presentations/",
        "deck_url_pattern": f"https://{owner}.github.io/presentations/<project-slug>/",
    }, indent=2))


if __name__ == "__main__":
    main()
