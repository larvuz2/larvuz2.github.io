#!/usr/bin/env python3
"""Sync a private presentations source repo into a public GitHub Pages deploy mirror.

Default Gus/Larvuz setup:
- private source: /root/presentations/shared-repo
- public mirror: /root/presentations/public-pages-deploy
- mirror path: public repo /presentations/

Use this when GitHub Pages cannot serve directly from a private source repo on the current plan.
The script copies static deck files only; it does not change repo privacy.
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path


def run(cmd: list[str], cwd: Path | None = None) -> str:
    proc = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True)
    if proc.returncode != 0:
        raise SystemExit(
            f"Command failed: {' '.join(cmd)}\nSTDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
        )
    return proc.stdout.strip()


def copy_tree_contents(source: Path, dest: Path) -> None:
    if not source.exists():
        raise SystemExit(f"Source repo not found: {source}")
    dest.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)

    for item in source.iterdir():
        if item.name == ".git":
            continue
        target = dest / item.name
        if item.is_dir():
            shutil.copytree(item, target)
        else:
            shutil.copy2(item, target)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", default="/root/presentations/shared-repo")
    parser.add_argument("--mirror", default="/root/presentations/public-pages-deploy")
    parser.add_argument("--mirror-subdir", default="presentations")
    parser.add_argument("--message", default="chore: sync presentations preview mirror")
    parser.add_argument("--no-push", action="store_true", help="Commit locally but do not push")
    args = parser.parse_args()

    source = Path(args.source).expanduser().resolve()
    mirror = Path(args.mirror).expanduser().resolve()
    mirror_subdir = mirror / args.mirror_subdir

    if not (source / ".git").exists():
        raise SystemExit(f"Source must be a git repo: {source}")
    if not (mirror / ".git").exists():
        raise SystemExit(f"Mirror must be a git repo: {mirror}")

    copy_tree_contents(source, mirror_subdir)

    run(["git", "add", args.mirror_subdir], cwd=mirror)
    status = run(["git", "status", "--short"], cwd=mirror)
    if not status:
        print("No mirror changes to commit.")
        return

    print(status)
    run(["git", "commit", "-m", args.message], cwd=mirror)
    if not args.no_push:
        run(["git", "push"], cwd=mirror)
    print(f"Synced {source} -> {mirror_subdir}")


if __name__ == "__main__":
    main()
