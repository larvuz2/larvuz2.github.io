#!/usr/bin/env python3
"""Publish/serve a Beautiful Presentations HTML deck for URL-based review.

This helper does not upload anywhere. It copies the deck into a preview directory and prints
an HTTP URL if a base URL is configured. If no public base URL is configured, it prints the
local path plus setup instructions.

Environment variables:
  HERMES_PRESENTATION_PREVIEW_ROOT=/var/www/presentations
  HERMES_PRESENTATION_PREVIEW_BASE_URL=https://deck-preview.example.com

Usage:
  python publish_preview.py deck.html --slug project-name
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
import time
from pathlib import Path
from urllib.parse import quote


def slugify(value: str) -> str:
    value = value.lower().strip()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    value = re.sub(r"-+", "-", value).strip("-")
    return value or "deck"


def main() -> int:
    parser = argparse.ArgumentParser(description="Publish an HTML deck into a preview directory and print its review URL.")
    parser.add_argument("html", help="Input deck.html")
    parser.add_argument("--slug", help="URL-safe project/deck slug")
    parser.add_argument("--root", help="Preview root directory. Defaults to HERMES_PRESENTATION_PREVIEW_ROOT or ~/.hermes/cache/presentation-previews")
    parser.add_argument("--base-url", help="Public base URL. Defaults to HERMES_PRESENTATION_PREVIEW_BASE_URL")
    args = parser.parse_args()

    html_path = Path(args.html).expanduser().resolve()
    if not html_path.exists() or html_path.suffix.lower() not in {".html", ".htm"}:
        print(f"ERROR: input must be an existing HTML file: {html_path}", file=sys.stderr)
        return 2

    import os
    root = Path(args.root or os.getenv("HERMES_PRESENTATION_PREVIEW_ROOT", "~/.hermes/cache/presentation-previews")).expanduser().resolve()
    base_url = (args.base_url or os.getenv("HERMES_PRESENTATION_PREVIEW_BASE_URL", "")).rstrip("/")

    slug = slugify(args.slug or html_path.stem)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    dest_dir = root / slug / stamp
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / "index.html"
    shutil.copy2(html_path, dest)

    print(f"published_path={dest}")
    if base_url:
        url = f"{base_url}/{quote(slug)}/{stamp}/"
        print(f"preview_url={url}")
    else:
        print("preview_url=")
        print("note=No public preview URL configured. Set HERMES_PRESENTATION_PREVIEW_ROOT and HERMES_PRESENTATION_PREVIEW_BASE_URL, or deploy this folder behind nginx/Caddy.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
