#!/usr/bin/env python3
"""Export a Beautiful Presentations HTML deck to a static MP4 slideshow.

Usage:
    python export_video.py deck.html exports/deck.mp4 --seconds-per-slide 5
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


def require_tool(name: str) -> str:
    found = shutil.which(name)
    if not found:
        raise RuntimeError(f"Missing required command: {name}")
    return found


def capture_frames(html_path: Path, frames_dir: Path) -> int:
    try:
        from playwright.sync_api import sync_playwright  # type: ignore
    except Exception as exc:
        raise RuntimeError(f"Playwright is required for frame capture: {exc}") from exc

    frames_dir.mkdir(parents=True, exist_ok=True)
    for old in frames_dir.glob("slide_*.png"):
        old.unlink()

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)
        page.goto(html_path.resolve().as_uri(), wait_until="networkidle")
        page.wait_for_timeout(250)
        slide_count = page.locator(".slide").count()
        if slide_count <= 0:
            raise RuntimeError("No .slide elements found")
        for index in range(slide_count):
            page.evaluate(
                """
                (i) => {
                  if (window.deck && typeof window.deck.show === 'function') window.deck.show(i);
                  else {
                    const slides = Array.from(document.querySelectorAll('.slide'));
                    slides.forEach((slide, idx) => {
                      slide.classList.toggle('active', idx === i);
                      slide.classList.toggle('visible', idx === i);
                    });
                  }
                }
                """,
                index,
            )
            page.wait_for_timeout(120)
            page.screenshot(path=str(frames_dir / f"slide_{index + 1:03d}.png"), full_page=True)
        browser.close()
    return slide_count


def build_video(frames_dir: Path, output_path: Path, seconds_per_slide: float) -> None:
    require_tool("ffmpeg")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fps_expr = f"1/{seconds_per_slide:g}"
    cmd = [
        "ffmpeg",
        "-y",
        "-framerate",
        fps_expr,
        "-i",
        str(frames_dir / "slide_%03d.png"),
        "-vf",
        "scale=1920:1080,format=yuv420p",
        "-c:v",
        "libx264",
        str(output_path),
    ]
    subprocess.run(cmd, check=True)
    if not output_path.exists() or output_path.stat().st_size <= 0:
        raise RuntimeError(f"Video was not created or is empty: {output_path}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Export an HTML deck to static MP4 slideshow.")
    parser.add_argument("html", help="Input deck.html")
    parser.add_argument("mp4", help="Output deck.mp4")
    parser.add_argument("--seconds-per-slide", type=float, default=5.0)
    parser.add_argument("--frames-dir", help="Optional frames output directory")
    args = parser.parse_args()

    html_path = Path(args.html).expanduser().resolve()
    output_path = Path(args.mp4).expanduser().resolve()
    frames_dir = Path(args.frames_dir).expanduser().resolve() if args.frames_dir else output_path.parent / "frames"

    if not html_path.exists():
        print(f"ERROR: HTML file not found: {html_path}", file=sys.stderr)
        return 2
    if args.seconds_per_slide <= 0:
        print("ERROR: --seconds-per-slide must be greater than 0", file=sys.stderr)
        return 2

    try:
        slide_count = capture_frames(html_path, frames_dir)
        build_video(frames_dir, output_path, args.seconds_per_slide)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    print(f"Exported {slide_count} slides to video: {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
