#!/usr/bin/env python3
"""QA a Beautiful Presentations HTML deck.

Usage:
    python qa_html_deck.py deck.html [--screenshots qa/screenshots]
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any


def static_checks(html_path: Path) -> dict[str, Any]:
    text = html_path.read_text(encoding="utf-8", errors="replace")
    checks = {
        "exists": html_path.exists(),
        "non_empty": html_path.stat().st_size > 0,
        "has_deck_stage": "deck-stage" in text,
        "has_slides": "class=\"slide" in text or "class='slide" in text or ".slide" in text,
        "has_print_css": "@media print" in text,
        "has_controller": "class SlideDeck" in text or "class SlidePresentation" in text or "window.deck" in text,
        "has_1920_1080": "1920" in text and "1080" in text,
    }
    slide_count = len(re.findall(r"<section[^>]+class=[\"'][^\"']*\bslide\b", text, flags=re.I))
    if slide_count == 0:
        slide_count = len(re.findall(r"data-slide=", text, flags=re.I))
    return {"checks": checks, "slide_count": slide_count}


def browser_checks(html_path: Path, screenshots_dir: Path | None) -> dict[str, Any]:
    try:
        from playwright.sync_api import sync_playwright  # type: ignore
    except Exception as exc:
        return {"available": False, "reason": f"Playwright unavailable: {exc}"}

    result: dict[str, Any] = {"available": True, "console_errors": [], "slides": []}
    if screenshots_dir:
        screenshots_dir.mkdir(parents=True, exist_ok=True)

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)

        page.on("console", lambda msg: result["console_errors"].append(msg.text) if msg.type == "error" else None)
        page.on("pageerror", lambda err: result["console_errors"].append(str(err)))

        page.goto(html_path.resolve().as_uri(), wait_until="networkidle")
        page.wait_for_timeout(250)

        slide_count = page.locator(".slide").count()
        result["slide_count"] = slide_count
        result["has_window_deck"] = page.evaluate("() => Boolean(window.deck)")
        result["stage_box"] = page.locator("#deckStage").bounding_box()

        for index in range(slide_count):
            page.evaluate(
                """
                (i) => {
                  if (window.deck && typeof window.deck.show === 'function') window.deck.show(i);
                  else {
                    const slides = Array.from(document.querySelectorAll('.slide'));
                    slides.forEach((slide, idx) => {
                      slide.classList.toggle('active', idx === i);
                      slide.classList.toggle('visible', idx === i);
                    });
                  }
                }
                """,
                index,
            )
            page.wait_for_timeout(700)
            overflow = page.evaluate(
                """
                () => Array.from(document.querySelectorAll('.slide.visible, .slide.active')).map(slide => ({
                  index: Number(slide.dataset.slide || 0),
                  scrollWidth: slide.scrollWidth,
                  clientWidth: slide.clientWidth,
                  scrollHeight: slide.scrollHeight,
                  clientHeight: slide.clientHeight,
                  overflowing: slide.scrollWidth > slide.clientWidth || slide.scrollHeight > slide.clientHeight
                }))
                """
            )
            shot_path = None
            if screenshots_dir:
                shot_path = screenshots_dir / f"slide_{index + 1:03d}.png"
                page.screenshot(path=str(shot_path), full_page=True)
            result["slides"].append({"index": index + 1, "overflow": overflow, "screenshot": str(shot_path) if shot_path else None})
        browser.close()

    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="QA a Beautiful Presentations HTML deck.")
    parser.add_argument("html", help="Input deck.html")
    parser.add_argument("--screenshots", help="Optional screenshot output directory")
    args = parser.parse_args()

    html_path = Path(args.html).expanduser().resolve()
    if not html_path.exists():
        print(json.dumps({"ok": False, "error": f"File not found: {html_path}"}, indent=2))
        return 2

    result: dict[str, Any] = {"html": str(html_path)}
    result.update(static_checks(html_path))
    screenshots_dir = Path(args.screenshots).expanduser().resolve() if args.screenshots else None
    result["browser"] = browser_checks(html_path, screenshots_dir)

    static_ok = all(result["checks"].values()) and result["slide_count"] > 0
    browser = result["browser"]
    browser_ok = True
    if browser.get("available"):
        browser_ok = not browser.get("console_errors") and browser.get("slide_count", 0) > 0
    result["ok"] = bool(static_ok and browser_ok)
    print(json.dumps(result, indent=2))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
