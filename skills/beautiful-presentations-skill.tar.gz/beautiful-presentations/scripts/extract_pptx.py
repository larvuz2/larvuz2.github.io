#!/usr/bin/env python3
"""Extract a PPTX into outline.md, manifest.json, and media files.

Usage:
    python extract_pptx.py source.pptx extracted/
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import zipfile
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}


def text_from_slide_xml(xml_bytes: bytes) -> list[str]:
    root = ET.fromstring(xml_bytes)
    texts: list[str] = []
    for t in root.findall(".//a:t", NS):
        if t.text and t.text.strip():
            texts.append(t.text.strip())
    return texts


def safe_extract_media(zf: zipfile.ZipFile, out_dir: Path) -> list[dict[str, Any]]:
    media_dir = out_dir / "media"
    media_dir.mkdir(parents=True, exist_ok=True)
    media: list[dict[str, Any]] = []
    for name in zf.namelist():
        if not name.startswith("ppt/media/") or name.endswith("/"):
            continue
        src_name = Path(name).name
        dest = media_dir / src_name
        with zf.open(name) as source, dest.open("wb") as target:
            shutil.copyfileobj(source, target)
        media.append({"source": name, "file": str(dest.relative_to(out_dir)), "bytes": dest.stat().st_size})
    return media


def extract_with_zip(source: Path, out_dir: Path) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    slides: list[dict[str, Any]] = []
    with zipfile.ZipFile(source) as zf:
        slide_names = sorted(
            [n for n in zf.namelist() if n.startswith("ppt/slides/slide") and n.endswith(".xml")],
            key=lambda n: int(Path(n).stem.replace("slide", "")) if Path(n).stem.replace("slide", "").isdigit() else 9999,
        )
        for index, slide_name in enumerate(slide_names, 1):
            text = text_from_slide_xml(zf.read(slide_name))
            slides.append({"index": index, "source": slide_name, "text": text})
        media = safe_extract_media(zf, out_dir)
    return {"source": str(source), "slide_count": len(slides), "slides": slides, "media": media}


def write_outputs(manifest: dict[str, Any], out_dir: Path) -> None:
    manifest_path = out_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    lines: list[str] = [f"# Extracted PPTX Outline", "", f"Source: `{manifest['source']}`", "", f"Slides: {manifest['slide_count']}", ""]
    for slide in manifest["slides"]:
        lines.append(f"## Slide {slide['index']}")
        lines.append("")
        if slide["text"]:
            for item in slide["text"]:
                lines.append(f"- {item}")
        else:
            lines.append("- [No text extracted]")
        lines.append("")
    if manifest.get("media"):
        lines.extend(["## Media", ""])
        for item in manifest["media"]:
            lines.append(f"- `{item['file']}` ({item['bytes']} bytes)")
        lines.append("")
    (out_dir / "outline.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract text and media from a PPTX file.")
    parser.add_argument("pptx", help="Input .pptx file")
    parser.add_argument("out_dir", help="Output directory")
    args = parser.parse_args()

    source = Path(args.pptx).expanduser().resolve()
    out_dir = Path(args.out_dir).expanduser().resolve()

    if not source.exists():
        print(f"ERROR: PPTX file not found: {source}", file=sys.stderr)
        return 2
    if source.suffix.lower() != ".pptx":
        print(f"ERROR: input is not a .pptx file: {source}", file=sys.stderr)
        return 2

    try:
        manifest = extract_with_zip(source, out_dir)
        write_outputs(manifest, out_dir)
    except Exception as exc:
        print(f"ERROR: failed to extract PPTX: {exc}", file=sys.stderr)
        return 1

    print(f"Extracted {manifest['slide_count']} slides to: {out_dir}")
    print(f"Outline: {out_dir / 'outline.md'}")
    print(f"Manifest: {out_dir / 'manifest.json'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
